﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine
{
    internal class AntiFlood
    {
        private vk Vk;
        private Cache Cache = new();
        private Database database;

        public AntiFlood(vk vks)
        {
            Vk = vks;
            database = new Database(Cache);
        }

        private enum Variant { секунд, секунду, секунды };

        private string Case(long seconds)
        {
            long result = (seconds % 100 > 20) ? seconds % 10 : seconds % 20;
            //Console.WriteLine("Результат: ");
            switch (result)
            {
                case 1: return seconds + " " + Variant.секунду.ToString();
                case 2:
                case 3:
                case 4: return seconds + " " + Variant.секунды.ToString();
                default: return seconds + " " + Variant.секунд.ToString();

            }
        }

        public bool checkCommand(long user_id, long peer_id, string command, long timeout = 5)
        {
            string key = "af_" + user_id.ToString() + "_" + peer_id.ToString();
            Dictionary<string, string>? cache_info = Cache.Get<Dictionary<string, string>>(key);
            long current_time = DateTimeOffset.Now.ToUnixTimeSeconds();
            string next_cmd = (current_time + timeout).ToString();
            //Console.WriteLine(next_cmd + " ||| " + current_time.ToString());

            if (cache_info == null)
            {
                cache_info = new Dictionary<string, string>()
                {
                    { command, next_cmd }
                };
                Cache.Set(key, cache_info);
                return true;
            }
            if (!cache_info.ContainsKey(command))
            {
                cache_info[command] = next_cmd;
                cache_info[command + "_send"] = "1";
                Cache.Set(key, cache_info);
                return true;
            }

            long cmd_time = long.Parse(cache_info[command]);
            if (cmd_time <= current_time)
            {
                //Console.WriteLine(cmd_time + " || " + current_time);
                cache_info.Remove(command);
                Cache.Set(key, cache_info);
                return true;
            }


            if (database.UserIsVip(user_id)) 
            {
                long cmd_timeVIP = long.Parse(cache_info[command]) / 2;
                if (cmd_timeVIP <= current_time)
                {
                    //Console.WriteLine(cmd_time + " || " + current_time);
                    cache_info.Remove(command);
                    Cache.Set(key, cache_info);
                    return true;
                }
            }


            if(!cache_info.ContainsKey(command+"_send"))
            {
                long cmd_wait = cmd_time - current_time;
                string text_wait = Case(cmd_wait);
                var nick = (Vk.m_from_id <= 0) ? $"[club{Vk.m_from_id.ToString().Substring(1)}|Вам]" : $"[id{Vk.m_from_id}|Вам]";
                Vk.MessagesSend(nick + " нельзя так часто использовать данную команду. Подождите " + text_wait);
                cache_info[command + "_send"] = "1";
                Cache.Set(key, cache_info);
                return false;
            }
            else
            {
                long trys = long.Parse(cache_info[command + "_send"]);
                if (trys <= 1)
                {
                    long cmd_wait = cmd_time - current_time;
                    string text_wait = Case(cmd_wait);
                    var nick = (Vk.m_from_id <= 0) ? $"[club{Vk.m_from_id.ToString().Substring(1)}|Вам]" : $"[id{Vk.m_from_id}|Вам]";
                    Vk.MessagesSend(nick + " нельзя так часто использовать данную команду. Подождите " + text_wait);
                    cache_info[command + "_send"] = (trys + 1).ToString();
                    Cache.Set(key, cache_info);
                    return false;
                }
            }

            return false;
        }
    }
}
