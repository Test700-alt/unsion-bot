﻿using Newtonsoft.Json;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API
{
    internal class Templane
    {
        private Cache cache = new();
        //public Database database = new();

        public AnswerTemplane result = new();
        private string Ahref = "https://grandmanager.ru/";//"https://grandmanager.ru/";//"http://127.0.0.1:100/api/";
        private string path = "/root/vk/";//"/root/vk/";

        public string getCacheTemplane(string templane, bool setup_menus = true, string menu_active = "profile", bool is_admin = false)
        {
            try
            {
                string date = cache.Get<string>("sitetemplane_" + templane + "_" + is_admin.ToString());
                if (date == null)
                {
                    if (System.IO.File.Exists(path + "templanes/" + templane))
                    {
                        try
                        {
                            using (FileStream fs = new FileStream(path + "templanes/" + templane, FileMode.Open, FileAccess.Read, FileShare.Read))
                            using (StreamReader reader = new StreamReader(fs, Encoding.UTF8)) // Использование StreamReader с кодировкой UTF-8
                            {
                                date = reader.ReadToEnd(); // Читаем весь файл в строку
                            }
                        }
                        catch
                        {
                            Console.WriteLine(" file error");
                            date = "";
                        }
                    }
                    else
                    {
                        Console.WriteLine("not file");
                        date = "";
                    }

                    
                    if (setup_menus)
                    {
                        var profileMenu = date.Split("<!-- START PROFILE MENU -->");
                        if (profileMenu.Length > 1)
                        {
                            profileMenu[1] = "";
                            profileMenu[1] = "<div class=\"dropdown-menu\">\r\n                    " +
                                //"<a href=\"#\" class=\"dropdown-item\">Настройки</a>\r\n                    " +
                                "<a href=\"logout\" class=\"dropdown-item\">Выйти</a>\r\n               " +
                                " </div>";
                        }
                        date = string.Join("", profileMenu);
                        /*<li class="active"><a href="#">Профиль</a></li>
                <li><a href="peers">Мои беседы</a></li>
                <li><a href="tickets">Мои обращения</a></li>*/

                        var mainMenu = date.Split("<!--START MAIN MENU-->");
                        if (mainMenu.Length > 1)
                        {
                            mainMenu[1] = "";
                            if (menu_active == "profile")
                            {
                                mainMenu[1] = $@"<li class=""active""><a href=""#"">Профиль</a></li>
                <li><a href=""peers"">Мои беседы</a></li>";
                //<li><a href=""tickets"">Мои обращения</a></li>";
                            }
                            else if (menu_active == "peers")
                            {
                                mainMenu[1] = $@"<li><a href=""profile"">Профиль</a></li>
                <li class=""active""><a href=""#"">Мои беседы</a></li>";
                            }
                            else if (menu_active == "admin")
                            {
                                mainMenu[1] = $@"<li><a href=""profile"">Профиль</a></li>
                <li><a href=""peers"">Мои беседы</a></li>
                <li class=""active""><a href=""#"">Панель агента</a></li>";

                            }

                            if (is_admin && menu_active != "admin")
                            {
                                mainMenu[1] += "<li><a href=\"admin\">Панель агента</a></li>";
                            }
                        }
                        date = string.Join("", mainMenu);

                    }

                    date = date.Replace("</title>", $"</title> <base href=\"{Ahref}\">");
                    cache.Set("sitetemplane_" + templane, date, 50);
                    return date;
                }


                return date;
            }
            catch (Exception e)
            {
                Console.WriteLine("get templane error - " + e.Message + " stacktrace " + e.StackTrace);
                return "";
            }

        }

        public string href(string path)
        {
            return $"<html>\r\n<head>\r\n    <meta charset=\"UTF-8\">\r\n    <meta http-equiv=\"refresh\" content=\"0; url={Ahref}{path}\">\r\n    <title>Перенаправление...</title>\r\n</head>";
        }

        public string GenerateSuccessfull(object? data = null)
        {
            //var utf8 = Encoding.UTF8;
            //byte[] utfBytes = utf8.GetBytes(message);
            //message = utf8.GetString(utfBytes, 0, utfBytes.Length);
            //byte[] windows1252Bytes = Encoding.GetEncoding(1252).GetBytes(message);
            //byte[] utf8Bytes = Encoding.Convert(Encoding.GetEncoding(1252), Encoding.UTF8, windows1252Bytes);

            // Convert UTF-8 byte array back to string
            //string utf8String = Encoding.UTF8.GetString(utf8Bytes);
            
            object response = new { response = data };
            return JsonConvert.SerializeObject(response);
        }

        public string GenerateError(object? data = null)
        {

            object response = new { error = data };
            return JsonConvert.SerializeObject(response);
        }

        public async Task<UserInfoSession?> getUserSessionAsync(Dictionary<string, string> Cookies, string ip = "127.0.0.1")
        {
            try
            {
                if (!Cookies.ContainsKey("session-id"))
                {
                    return null;
                }

                var session_id = Cookies["session-id"];
                if (session_id == null)
                {
                    return null;
                }

                if (session_id.Trim() == "")
                {
                    return null;
                }

                Database db = new(cache);
                var dbres = db.sessionGet(session_id);
                if (dbres == null)
                {
                    return null;
                }

                UserInfoSession res = new()
                {
                    user_id = long.Parse(dbres["user_id"]),
                    ipReg = dbres["ipReg"],
                    IpLast = ip,
                    DateReg = db.timeGetForMysql(dbres["dateReg"]),
                    DateLast = DateTimeOffset.Now,
                    SessionId = dbres["session_id"]
                };

                vk Vk = new(cache);
                Vk.m_from_id = long.Parse(dbres["user_id"]);
                botban banms = new(Vk, db, new settings());

                //Console.WriteLine(Vk.m_text);

                var target = await banms.checkBotBan();

                if (target)
                {
                    return null;
                }
                return res;
                /*if (SessionManager.ContainsSession(session_id))
                {
                    var session = SessionManager.GetSession(session_id);
                    session.IpLast = ip;
                    session.DateLast = DateTimeOffset.Now;
                    SessionManager.AddOrUpdateSession(session);
                    return session;
                }
                else
                {
                    return null;
                }*/
            }
            catch
            {
                return null;
            }
        }


        public async Task<UserInfoSession?> regUserSession(string session_id, long user_id, string ip)
        {
            try
            {
                if (session_id.Trim() == "")
                {
                    return null;
                }

                Database db = new(cache);
                var dbres = db.sessionGet(session_id);
                if (dbres != null)
                {
                    UserInfoSession res = new()
                    {
                        user_id = long.Parse(dbres["user_id"]),
                        ipReg = dbres["ipReg"],
                        IpLast = ip,
                        DateReg = db.timeGetForMysql(dbres["dateReg"]),
                        DateLast = DateTimeOffset.Now,
                        SessionId = dbres["session_id"]
                    };
                    vk Vk = new(cache);
                    Vk.m_from_id = long.Parse(dbres["user_id"]);
                    botban banms = new(Vk, db, new settings());

                    //Console.WriteLine(Vk.m_text);

                    var target = await banms.checkBotBan();

                    if (target)
                    {
                        return null;
                    }
                    db.sessionSetLast(session_id, ip);
                    return res;
                }
                else
                {
                    vk Vk = new(cache);
                    Vk.m_from_id = user_id;
                    botban banms = new(Vk, db, new settings());

                    //Console.WriteLine(Vk.m_text);

                    var target = await banms.checkBotBan();

                    if (target)
                    {
                        return null;
                    }
                    db.sessionAdd(user_id, session_id, ip);
                    UserInfoSession session = new()
                    {
                        SessionId = session_id,
                        user_id = user_id,
                        DateReg = DateTimeOffset.Now,
                        DateLast = DateTimeOffset.Now,
                        ipReg = ip,
                        IpLast = ip
                    };
                    return session;
                }
            }
            catch
            {
                return null;
            }
        }



        public string getRubsMoney(string money)
        {
            return getKKsMoney(money, "en-U") + "₽";
        }

        public string getDollMoney(string money)
        {
            return getKKsMoney(money, "en-US") + "$";
        }

        public string getEuroMoney(string money)
        {
            return getKKsMoney(money, "en-U") + "€";
        }
        /*
         * ru-RU - рубли
         * en-US - доллары
         * fr-FR - евро
         */
        public string getKKsMoney(string money, string country = "ru-RU")
        {
            System.Numerics.BigInteger temp = 0;
            try
            {
                temp = System.Numerics.BigInteger.Parse(money);
            }
            catch
            {

            }
            var counti = CultureInfo.CreateSpecificCulture(country);
            return temp.ToString("N0", counti);//temp.ToString("C2", counti);
        }

        public System.Numerics.BigInteger getUlongMoney(string money)
        {
            //decimal temp = 0;
            System.Numerics.BigInteger temp = 0;
            try
            {
                temp = System.Numerics.BigInteger.Parse(money);
            }
            catch
            {

            }
            return temp;
        }

    }

    public class UserInfoSession
    {
        public string SessionId;
        public long user_id;
        public DateTimeOffset DateReg;
        public DateTimeOffset DateLast;
        public string ipReg;
        public string IpLast;
    }

    public static class SessionManager
    {
        private static readonly ConcurrentDictionary<string, UserInfoSession> _sessions = new ConcurrentDictionary<string, UserInfoSession>();

        public static void AddOrUpdateSession(UserInfoSession session)
        {
            _sessions.AddOrUpdate(session.SessionId, session, (key, existingSession) =>
            {
                existingSession.DateLast = session.DateLast;
                existingSession.IpLast = session.IpLast;
                return existingSession;
            });
        }

        public static UserInfoSession GetSession(string sessionId)
        {
            _sessions.TryGetValue(sessionId, out var session);
            return session;
        }

        public static void RemoveSession(string sessionId)
        {
            _sessions.TryRemove(sessionId, out _);
        }

        public static ICollection<UserInfoSession> GetAllSessions()
        {
            return _sessions.Values;
        }

        public static bool ContainsSession(string sessionId)
        {
            return _sessions.ContainsKey(sessionId);
        }


    }
}
