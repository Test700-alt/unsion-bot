﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using System.Web;

namespace GrandManager.engine.API
{
    public static class InputSanitizer
    {
        public static string SanitizeHtml(string input)
        {
            if (string.IsNullOrEmpty(input))
                return input;
            return HtmlEncoder.Default.Encode(input);
        }

        public static string SanitizeUrl(string input)
        {
            if (string.IsNullOrEmpty(input))
                return input;
            return HttpUtility.UrlEncode(input);
        }

        public static string SanitizeJavaScript(string input)
        {
            if (string.IsNullOrEmpty(input))
                return input;
            return JavaScriptEncoder.Default.Encode(input);
        }

        public static Dictionary<string, string> SanitizeArgs(Dictionary<string, string> args)
        {
            Dictionary<string, string> sanitizedArgs = new Dictionary<string, string>();
            foreach (var arg in args)
            {
                sanitizedArgs[SanitizeHtml(arg.Key)] = SanitizeHtml(arg.Value);
            }
            return sanitizedArgs;
        }

        public static Dictionary<string, string> SanitizeCookies(Dictionary<string, string> cookies)
        {
            Dictionary<string, string> sanitizedCookies = new Dictionary<string, string>();
            foreach (var cookie in cookies)
            {
                sanitizedCookies[SanitizeHtml(cookie.Key)] = SanitizeHtml(cookie.Value);
            }
            return sanitizedCookies;
        }
    }
}
