﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API
{
    public class AnswerTemplane
    {
        public string htmlResponse = "";
        public Dictionary<string, string> Cookies = new Dictionary<string, string>();
        public Dictionary<string, string> RemoveCookies = new Dictionary<string, string>();
    }
}
