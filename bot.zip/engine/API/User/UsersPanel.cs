﻿using GrandManager.engine.DataBaseClass;
using GrandManager.engine.properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class UsersPanel : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "userspanel",

                nameOfClass = "GrandManager.engine.API.Method.UsersPanel",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public async Task<AnswerTemplane> work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            try
            {
                var session = await getUserSessionAsync(Cookies);

                if (session == null)
                {
                    result.htmlResponse = href("auth");
                    return result;
                }

                var userid = session.user_id;
                
                result.htmlResponse = getCacheTemplane("userspanel.html", true, "peers");
                if (settings.OWNER_IDS.ContainsKey(session.user_id) && settings.OWNER_IDS[session.user_id].admin != 1)
                {
                    result.htmlResponse = getCacheTemplane("userspanel.html", true, "peers", true);
                }

                if (!args.ContainsKey("id"))
                {
                    result.htmlResponse = href("peers");
                    return result;
                }

                long peer_id = 0;
                try
                {
                    peer_id = long.Parse(args["id"]);
                }
                catch
                {
                    peer_id = 0;
                }

                if (peer_id <= 0)
                {
                    result.htmlResponse = href("peers");
                    return result;
                }

                var peerInfo = Db.peersGetPeer(peer_id);
                if (peerInfo == null)
                {
                    result.htmlResponse = href("peers");
                    return result;
                }

                if (peerInfo["active"] == "0")
                {
                    result.htmlResponse = href("peers");
                    return result;
                }

                result.htmlResponse = result.htmlResponse.Replace("%peerid%", peer_id.ToString());

                
                var peerMember = Db.peersGetMember(peer_id, userid, false, false);
                if (peerMember == null)
                {
                    result.htmlResponse = href("peers");
                    return result;
                }

                if (long.Parse(peerMember["priority"]) < 80 && peerInfo["owner"] != userid.ToString())
                {
                    result.htmlResponse = href("peers");
                    return result;
                }

                
                //result.htmlResponse = result.htmlResponse.Replace("%peertitle%", peerInfo["title"]);

                vk Vk = new(cache);

                var rolesDb = Db.peerGetRoles(peer_id);

                if (rolesDb != null)
                {
                    
                    //roles = from entry in roles orderby entry.Value.priority ascending select entry;
                    //result.htmlResponse = result.htmlResponse.Replace("%peerCountRoles%", roles.Count.ToString());
                }
                else
                {
                    rolesDb = new();
                    //result.htmlResponse = result.htmlResponse.Replace("%peerCountRoles%", "—");
                }

                if (!rolesDb.ContainsKey("0"))
                {
                    rolesDb.Add("0", new NamesRoles() { name = "Пользователь", priority = 0, admin = 0 });
                }
                if (!rolesDb.ContainsKey("20"))
                {
                    rolesDb.Add("20", new NamesRoles() { name = "Помощник", priority = 20, admin = 0 });
                }
                if (!rolesDb.ContainsKey("40"))
                {
                    rolesDb.Add("40", new NamesRoles() { name = "Модератор", priority = 40, admin = 0 });
                }
                if (!rolesDb.ContainsKey("60"))
                {
                    rolesDb.Add("60", new NamesRoles() { name = "Администратор", priority = 60, admin = 0 });
                }
                if (!rolesDb.ContainsKey("80"))
                {
                    rolesDb.Add("80", new NamesRoles() { name = "Главный Администратор", priority = 80, admin = 0 });
                }
                if (!rolesDb.ContainsKey("100"))
                {
                    rolesDb.Add("100", new NamesRoles() { name = "Владелец", priority = 100, admin = 0 });
                }

                //Dictionary<string, usersNameVk> names = new();
                //var usersVk = await Vk.UsersGetVkInfo(new long[] { long.Parse(peerInfo["owner"]) });

                var roles = from entry in rolesDb orderby entry.Value.priority ascending select entry;

                //<!--ROLE_OPTIONS-->

                string rolesText = "";

                string filterRolesText = "";

                foreach (var roleInfo in roles)
                {
                    rolesText += $"<div class=\"role-option\" data-role-id=\"{roleInfo.Value.priority}\">{roleInfo.Value.name}</div>";
                    filterRolesText += $"<li>{roleInfo.Value.name} <span class=\"count\" data-role-id=\"{roleInfo.Value.priority}\"></span></li>";
                }

                result.htmlResponse = result.htmlResponse.Replace("<!--ROLE_OPTIONS-->", rolesText);
                result.htmlResponse = result.htmlResponse.Replace("<!--FILTERROLES-->", filterRolesText);

                var peerMembers = Db.peerGetAllNotLeaveMembers(peer_id, false, 500);

                if (peerMembers == null)
                {
                    return result;
                }

                List<long> userIds = new();
                foreach (var member in peerMembers)
                {
                    if (long.Parse(member["user_id"]) <= 0)
                    {
                        continue;
                    }
                    userIds.Add(long.Parse(member["user_id"]));
                }

                var UserInfoVk = await Vk.UsersGetName(userIds.ToArray());


                string membersText = "";
                foreach (var member in peerMembers)
                {

                    string roleName = "—";
                    if (rolesDb.ContainsKey(member["priority"]))
                    {
                        roleName = rolesDb[member["priority"]].name + $" ({member["priority"]})";
                    }
                    else
                    {
                        if (int.Parse(member["priority"]) <= 19)
                        {
                            roleName = "Пользователь (0)";
                        }
                        else if (int.Parse(member["priority"]) < 40)
                        {
                            roleName = $"Помощник ({member["priority"]})";
                        }
                        else if (int.Parse(member["priority"]) < 60)
                        {
                            roleName = $"Модератор ({member["priority"]})";
                        }
                        else if (int.Parse(member["priority"]) < 80)
                        {
                            roleName = $"Администратор ({member["priority"]})";
                        }
                        else if (int.Parse(member["priority"]) < 100)
                        {
                            roleName = $"Главный Администратор ({member["priority"]})";
                        }
                        else if (int.Parse(member["priority"]) == 100)
                        {
                            roleName = $"Владелец ({member["priority"]})";
                        }
                    }

                    string nameVk = "—";
                    if (long.Parse(member["user_id"]) <= 0 || member["leave_peer"] == "1")
                    {
                        continue;
                    }

                    if (UserInfoVk.ContainsKey("id" + member["user_id"]))
                    {
                        nameVk = $"{UserInfoVk[$"id{member["user_id"]}"].first_name} {UserInfoVk[$"id{member["user_id"]}"].last_name}";
                    }

                    membersText += $@"<div class=""user-item"" data-user-id=""{member["user_id"]}"" data-user-role-id=""{member["priority"]}"">
                    <div class=""user-avatar"">
                        <img src=""/images/logo.png"" alt=""Аватар пользователя"">
                    </div>
                    <div class=""user-info"">
                        <p class=""user-name"">{nameVk}</p>
                        <p class=""user-role"">Роль: {roleName}</p>
                    </div>
                    <div class=""user-actions"">
                        <button class=""change-role-button"" data-user-id=""{member["user_id"]}""><i class=""fas fa-user-tag""></i> Изменить роль</button>
                        <button class=""set-nickname-button"" data-user-id=""{member["user_id"]}"" data-user-nick=""{member["nick"]}""><i class=""fas fa-signature""></i> Установить ник</button>
                        
                    </div>
                </div>";
                    /*<button class=""ban-user-button"" data-user-id=""{member["user_id"]}""><i class=""fas fa-ban""></i> Забанить</button>
                        <button class=""kick-user-button"" data-user-id=""{member["user_id"]}""><i class=""fas fa-sign-out-alt""></i> Выгнать</button>*/

                }

                result.htmlResponse = result.htmlResponse.Replace("<!--USERLIST-->", membersText);

                return result;
            }
            catch (Exception e)
            {
                result.htmlResponse = "error - undefined " + e.Message + " " + e.StackTrace;
                return result;
            }
        }
    }
}
