﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace GrandManager.engine.API.Method
{
    internal class createticket : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "createticket",

                nameOfClass = "GrandManager.engine.API.Method.createticket",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public AnswerTemplane work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            if (!is_post)
            {
                result.htmlResponse = "403";
                return result;
            }

            if (!args.ContainsKey("title"))
            {
                result.htmlResponse = "403";
                return result;
            }
            //Console.WriteLine(args["title"]);
            //string decodedUrl = HttpUtility.UrlDecode(url);

            var peer1 = new { id = "1", title = args["title"], create_time = DateTimeOffset.Now.ToString("g") };
            var res = GenerateSuccessfull(new[] { peer1 });
            result.htmlResponse = res;

            return result;
        }
    }
}
