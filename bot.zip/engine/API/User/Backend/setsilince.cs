﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class setsilince : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "setsilince",

                nameOfClass = "GrandManager.engine.API.Method.setsilince",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public async Task<AnswerTemplane> work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            try
            {
                if (!is_post)
                {
                    result.htmlResponse = "403";
                    return result;
                }

                var session = await getUserSessionAsync(Cookies);

                if (session == null)
                {
                    result.htmlResponse = href("auth");
                    return result;
                }

                var userid = session.user_id;

                if (!args.ContainsKey("id") || !args.ContainsKey("type"))
                {
                    result.htmlResponse = GenerateError("no args passed");
                    return result;
                }

                long id = 0;
                try
                {
                    id = long.Parse(args["id"]);
                }
                catch
                {
                    id = 0;
                }

                if (id == 0)
                {
                    result.htmlResponse = GenerateError("no id passed");
                    return result;
                }

                var type = args["type"];
                if (type != "nou" && type != "delete" && type != "kick")
                {
                    result.htmlResponse = GenerateError("no type passed");
                    return result;
                }

                var peerInfo = Db.peersGetPeer(id);
                if (peerInfo == null)
                {
                    result.htmlResponse = GenerateError("peerInfo is NULL");
                    return result;
                }

                var peerMember = Db.peersGetMember(id, userid, false, false);
                if (peerMember == null)
                {
                    result.htmlResponse = GenerateError("403 forbidden");
                    return result;
                }

                if (int.Parse(peerMember["priority"]) < 80)
                {
                    result.htmlResponse = GenerateError("403 forbidden — role not 80");
                    return result;
                }

                vk Vk = new(cache);

                string text = "";
                int settype = 0;

                var userName = await Vk.UserGetNameUrls(new long[] { userid });

                if (type == "nou")
                {
                    text = userName[userid.ToString()] + " выключил режим тишины через панель управления.<br><br>" +
                        "🦠 Обычным пользователям теперь можно писать в чат.";
                }
                else if (type == "delete")
                {
                    text = "☠ " + userName[userid.ToString()] + " включил режим тишины через панель управления.<br><br>" +
                        "Сообщения обычных пользователей будут удалены при отправке!";
                    settype = 2;
                }
                else if (type == "kick")
                {
                    text = "☠ " + userName[userid.ToString()] + " включил режим тишины через панель управления.<br><br>" +
                        "Обычные участники будут исключены при отправке сообщений в чат!";
                    settype = 1;
                }

                Db.peersSetSilence(id, settype);
                Vk.MessagesSend(text, 0, id);

                var res = GenerateSuccessfull("ok");
                result.htmlResponse = res;

                return result;
            }
            catch
            {
                result.htmlResponse = GenerateError("undefined exception error");
                return result;
            }
        }
    }
}
