﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class getPeersMore : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "getPeersMore",

                nameOfClass = "GrandManager.engine.API.Method.getPeersMore",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public AnswerTemplane work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            if (!is_post)
            {
                result.htmlResponse = "403";
                return result;
            }
            //var peer1 = new { id = "1", title = "текстовая", creationDate = "23122", owner = "1444", participants = 34 };
            //var peer2 = new { id = "2", title = "текстоваыыыы ыыы ", creationDate = "23авв122", owner = "14аа44", participants = 3456 };
            var res = GenerateSuccessfull(null);
            result.htmlResponse = res;

            return result;
        }
    }
}
