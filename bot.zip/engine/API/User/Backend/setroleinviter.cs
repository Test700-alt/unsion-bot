﻿using GrandManager.engine.DataBaseClass;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class setroleinviter : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "setroleinviter",

                nameOfClass = "GrandManager.engine.API.Method.setroleinviter",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public async Task<AnswerTemplane> work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            try
            {
                if (!is_post)
                {
                    result.htmlResponse = "403";
                    return result;
                }

                var session = await getUserSessionAsync(Cookies);

                if (session == null)
                {
                    result.htmlResponse = href("auth");
                    return result;
                }

                var userid = session.user_id;

                if (!args.ContainsKey("id") || !args.ContainsKey("role"))
                {
                    result.htmlResponse = GenerateError("no args passed");
                    return result;
                }

                long id = 0;
                try
                {
                    id = long.Parse(args["id"]);
                }
                catch
                {
                    id = 0;
                }

                if (id == 0)
                {
                    result.htmlResponse = GenerateError("no id passed");
                    return result;
                }

                long role = -1;
                try
                {
                    role = long.Parse(args["role"]);
                }
                catch
                {
                    role = -1;
                }

                if (role < 0 || role > 100)
                {
                    result.htmlResponse = GenerateError("no role passed");
                    return result;
                }

                var peerInfo = Db.peersGetPeer(id);
                if (peerInfo == null)
                {
                    result.htmlResponse = GenerateError("peerInfo is NULL");
                    return result;
                }

                var peerMember = Db.peersGetMember(id, userid, false, false);
                if (peerMember == null)
                {
                    result.htmlResponse = GenerateError("403 forbidden");
                    return result;
                }

                if (int.Parse(peerMember["priority"]) < 80)
                {
                    result.htmlResponse = GenerateError("403 forbidden — role not 80");
                    return result;
                }

                vk Vk = new(cache);

                string text = "";

                var userName = await Vk.UserGetNameUrls(new long[] { userid });

                var roles = Db.peerGetRoles(id);
                if (roles == null)
                {
                    result.htmlResponse = GenerateError("500 — not roles in database");
                    return result;
                }

                if (!roles.ContainsKey("0"))
                {
                    roles.Add("0", new NamesRoles() { name = "Пользователь", priority = 0 });
                }
                if (!roles.ContainsKey("20"))
                {
                    roles.Add("20", new NamesRoles() { name = "Помощник", priority = 20 });
                }
                if (!roles.ContainsKey("40"))
                {
                    roles.Add("40", new NamesRoles() { name = "Модератор", priority = 40 });
                }
                if (!roles.ContainsKey("60"))
                {
                    roles.Add("60", new NamesRoles() { name = "Администратор", priority = 60 });
                }
                if (!roles.ContainsKey("80"))
                {
                    roles.Add("80", new NamesRoles() { name = "Главный Администратор", priority = 80 });
                }
                if (!roles.ContainsKey("100"))
                {
                    roles.Add("100", new NamesRoles() { name = "Владелец", priority = 100 });
                }

                string targetRoleName = $"Пользователь ({role})";
                if (!roles.ContainsKey(role.ToString()))
                {
                    if (role < 40)
                    {
                        targetRoleName = $"Помощник ({role})";
                    }
                    else if (role < 60)
                    {
                        targetRoleName = $"Модератор ({role})";
                    }
                    else if (role < 80)
                    {
                        targetRoleName = $"Администратор ({role})";
                    }
                    else if (role < 100)
                    {
                        targetRoleName = $"Главный Администратор ({role})";
                    }
                    else
                    {
                        targetRoleName = $"Неизвестно ({role})";
                    }
                }
                else
                {
                    targetRoleName = roles[role.ToString()].name + $" ({role})";
                }

                text = userName[userid.ToString()] + " через панель управления установил необходимую роль для добавления участников в беседу: " + targetRoleName;

                Vk.MessagesSend(text, 0, id);
                Db.peersSetRoleInviter(id, role);

                var res = GenerateSuccessfull("ok");
                result.htmlResponse = res;

                return result;
            }
            catch
            {
                result.htmlResponse = GenerateError("undefined exception error");
                return result;
            }
        }
    }
}
