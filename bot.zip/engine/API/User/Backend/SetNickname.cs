﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class SetNickname : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "setnickname",

                nameOfClass = "GrandManager.engine.API.Method.SetNickname",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public async Task<AnswerTemplane> work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            try
            {
                if (!is_post)
                {
                    result.htmlResponse = "403";
                    return result;
                }

                var session = await getUserSessionAsync(Cookies);

                if (session == null)
                {
                    result.htmlResponse = href("auth");
                    return result;
                }

                var userid = session.user_id;

                if (!args.ContainsKey("id") || !args.ContainsKey("userid") || !args.ContainsKey("newnick"))
                {
                    result.htmlResponse = GenerateError("no args passed");
                    return result;
                }

                long peer_id = 0;
                try
                {
                    peer_id = long.Parse(args["id"]);
                }
                catch
                {
                    peer_id = 0;
                }

                if (peer_id == 0)
                {
                    result.htmlResponse = GenerateError("no peerid passed");
                    return result;
                }

                long target_user_id = 0;
                try
                {
                    target_user_id = long.Parse(args["userid"]);
                }
                catch
                {
                    target_user_id = 0;
                }

                if (target_user_id == 0)
                {
                    result.htmlResponse = GenerateError("no target_user_id passed");
                    return result;
                }

                string newnick = args["newnick"];
                if (newnick == null)
                {
                    result.htmlResponse = GenerateError("no newnick passed");
                    return result;
                }


                var peerInfo = Db.peersGetPeer(peer_id);
                if (peerInfo == null)
                {
                    result.htmlResponse = GenerateError("peerInfo is NULL");
                    return result;
                }

                var peerMember = Db.peersGetMember(peer_id, userid, false, false);
                if (peerMember == null)
                {
                    result.htmlResponse = GenerateError("403 forbidden");
                    return result;
                }

                var Target_User = Db.peersGetMember(peer_id, target_user_id);
                if (long.Parse(Target_User["priority"]) != 0)
                {
                    if (long.Parse(peerMember["priority"]) <= long.Parse(Target_User["priority"]) && peerInfo["owner"] != userid.ToString())
                    {
                        result.htmlResponse = GenerateError("Вы не можете изменять группу человека, роль которого выше или равна вашей.");
                        return result;
                    }
                    if (Target_User["nick"] == newnick)
                    {
                        result.htmlResponse = GenerateError("Пользователь уже имеет этот никнейм.");
                        return result;
                    }
                }

                vk Vk = new(cache);

                string text = "";

                var userNames = await Vk.UserGetNameUrls(new long[] { userid, target_user_id });

                text = $"{userNames[userid.ToString()]} через панель управления установил никнейм {userNames[target_user_id.ToString()]}.<br><br>" +
                    $"Новый никнейм: {newnick}";

                if (newnick == "")
                {
                    Db.peersMemberSetNickName(peer_id, target_user_id, null);
                    text = $"{userNames[userid.ToString()]} через панель управления удалил никнейм {userNames[target_user_id.ToString()]}.";
                }
                else
                {
                    Db.peersMemberSetNickName(peer_id, target_user_id, newnick);
                }
                Vk.MessagesSend(text, 0, peer_id);

                var res = GenerateSuccessfull("ok");
                result.htmlResponse = res;

                return result;
            }
            catch
            {
                result.htmlResponse = GenerateError("undefined exception error");
                return result;
            }
        }
    }
}
