﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class deleterole : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "deleterole",

                nameOfClass = "GrandManager.engine.API.Method.deleterole",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public async Task<AnswerTemplane> work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            if (!is_post)
            {
                result.htmlResponse = "403";
                return result;
            }

            var session = await getUserSessionAsync(Cookies);

            if (session == null)
            {
                result.htmlResponse = GenerateError("Not session");
                return result;
            }

            if (!args.ContainsKey("id"))
            {
                result.htmlResponse = GenerateError("Not PEERID");
                return result;
            }

            long peer_id = 0;
            try { peer_id = long.Parse(args["id"]); } catch { peer_id = 0; }

            if (peer_id == 0)
            {
                result.htmlResponse = GenerateError("Not PEERID 2");
                return result;
            }

            if (!args.ContainsKey("role"))
            {
                result.htmlResponse = GenerateError("Not role");
                return result;
            }

            long role_id = 0;
            try { role_id = long.Parse(args["role"]); } catch { peer_id = 0; }

            if (role_id < 0 || role_id > 100)
            {
                result.htmlResponse = GenerateError("Вы не можете удалить эту роль.");
                return result;
            }

            var peerInfo = Db.peersGetPeer(peer_id);
            if (peerInfo == null)
            {
                result.htmlResponse = GenerateError("peerInfo is NULL");
                return result;
            }

            var peerMember = Db.peersGetMember(peer_id, session.user_id, false, false);
            if (peerMember == null)
            {
                result.htmlResponse = GenerateError("403 forbidden");
                return result;
            }

            if (int.Parse(peerMember["priority"]) < 80 || int.Parse(peerMember["priority"]) < role_id)
            {
                result.htmlResponse = GenerateError("Ваша роль либо не равна 80, либо меньше, чем удаляемая.");
                return result;
            }

            vk Vk = new vk(cache);

            var nicknameUser = await Vk.UserGetNameUrls(new long[] { session.user_id });

            var roles = Db.peerGetRoles(peer_id, true);
            string oldName = "";

            if (roles.ContainsKey(role_id.ToString()))
            {
                oldName = "Предыдущее название: " + roles[role_id.ToString()].name + "<br>";
            }

            if (!roles.ContainsKey(role_id.ToString()))
            {
                result.htmlResponse = GenerateError("Стандартная роль не может быть удалена");

                return result;
            }

            string text = $"{nicknameUser[session.user_id.ToString()]} через панель управления удалил роль с приоритетом '{role_id}'.<br>{oldName}";

            Vk.MessagesSend(text, 0, peer_id);

            Db.rolesDelName(peer_id, role_id);



            result.htmlResponse = GenerateSuccessfull("ok");

            return result;
        }
    }
}
