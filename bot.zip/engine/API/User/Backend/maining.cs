﻿using Google.Protobuf.WellKnownTypes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class maining : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "maining",

                nameOfClass = "GrandManager.engine.API.Method.maining",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public async Task<AnswerTemplane> work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            try
            {
                
                result.htmlResponse = "403";
                return result;

                var session = await getUserSessionAsync(Cookies);

                if (session == null)
                {
                    result.htmlResponse = href("auth");
                    return result;
                }

                var userid = session.user_id;

                double microtimeInSeconds = DateTimeOffset.UtcNow.Subtract(DateTimeOffset.UnixEpoch).TotalSeconds;
                var lastRes = cache.Get<string?>($"maining_{userid}");
                if (lastRes == null)
                {
                    cache.Set($"maining_{userid}", microtimeInSeconds.ToString(), 5);
                }
                else
                {
                    try
                    {
                        double parsedDouble = double.Parse(lastRes);
                        if (microtimeInSeconds - parsedDouble < 0.2 && settings.ENABLE_TIMEOUT_CLICK)
                        {
                            result.htmlResponse = GenerateError("The request timeout has not passed yet");
                            Console.WriteLine($"[MAINING] {userid} is timeout not passed = {microtimeInSeconds - parsedDouble}");
                            return result;
                        }    
                    }
                    catch
                    {
                        
                    }
                }

                if (!args.ContainsKey("userid"))
                {
                    result.htmlResponse = GenerateError("no args passed");
                    Console.WriteLine($"[MAINING] {userid} is userid not passed");
                    return result;
                }

                long id = 0;
                try
                {
                    id = long.Parse(args["userid"]);
                }
                catch
                {
                    id = 0;
                }

                if (id == 0)
                {
                    result.htmlResponse = GenerateError("no id passed");
                    Console.WriteLine($"[MAINING] {userid} is userid = 0");
                    return result;
                }

                if (userid != id)
                {
                    result.htmlResponse = GenerateError("no id passed");
                    Console.WriteLine($"[MAINING] {userid} is userid not userid. Userid Param = {id}");
                    return result;
                }



                var account = Db.usersGetUser(userid);
                if (account == null)
                {
                    result.htmlResponse = GenerateError("no account");
                    Console.WriteLine($"[MAINING] {userid} is no account");
                    return result;
                }

                var targetPlus = 2000;
                bool is_vip = false;
                if (settings.OWNER_IDS.ContainsKey(userid))
                {
                    if (settings.OWNER_IDS[userid].admin == 1)
                    {
                        targetPlus = 10000;
                        is_vip = true;
                    }
                }

                var targetnewRubs = getUlongMoney(account["rubs"]) + targetPlus;
                Db.gameSetUserRub(userid, targetnewRubs.ToString());

                var res = GenerateSuccessfull(new { newrub=getRubsMoney(targetnewRubs.ToString()) });
                result.htmlResponse = res;

                var lastCount = cache.Get<string?>($"maining_count_{userid}");
                if (lastCount != null)
                {
                    long context = 0;
                    try
                    {
                        context = long.Parse(lastCount);
                    }
                    catch
                    {

                    }

                    if (context >= 100)
                    {
                        if (is_vip)
                        {
                            Db.logsAddLog(0, Database.logsId.USER_MAINING, userid, 0, "получил миллион рублей за майнинг (DONUT)", context.ToString(), targetnewRubs.ToString());
                        }
                        else
                        {
                            Db.logsAddLog(0, Database.logsId.USER_MAINING, userid, 0, "получил 200 тысяч рублей за майнинг", context.ToString(), targetnewRubs.ToString());
                        }
                        cache.Delete($"maining_count_{userid}");
                    }
                    else
                    {
                        if (context == 20)
                        {
                            Console.WriteLine($"[MAINING] {userid} is 20 click target. Is vip: {is_vip.ToString()}");
                        }
                        cache.Set($"maining_count_{userid}", (context + 1).ToString(), 10);
                    }
                }
                else
                {
                    cache.Set($"maining_count_{userid}", "1", 10);
                }

                return result;
            }
            catch
            {
                result.htmlResponse = GenerateError("undefined exception error");
                return result;
            }
        }
    }
}
