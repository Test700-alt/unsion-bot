﻿using GrandManager.engine.DataBaseClass;
using GrandManager.engine.properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class InfoPeer : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "infopeer",

                nameOfClass = "GrandManager.engine.API.Method.InfoPeer",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public async Task<AnswerTemplane> work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            try
            {
                var session = await getUserSessionAsync(Cookies);

                if (session == null)
                {
                    result.htmlResponse = href("auth");
                    return result;
                }

                var userid = session.user_id;
                
                result.htmlResponse = getCacheTemplane("peerinfo.html", true, "peers");
                if (settings.OWNER_IDS.ContainsKey(session.user_id) && settings.OWNER_IDS[session.user_id].admin != 1)
                {
                    result.htmlResponse = getCacheTemplane("peerinfo.html", true, "peers", true);
                }

                if (!args.ContainsKey("id"))
                {
                    result.htmlResponse = href("peers");
                    return result;
                }

                long peer_id = 0;
                try
                {
                    peer_id = long.Parse(args["id"]);
                }
                catch
                {
                    peer_id = 0;
                }

                if (peer_id <= 0)
                {
                    result.htmlResponse = href("peers");
                    return result;
                }

                var peerInfo = Db.peersGetPeer(peer_id);
                if (peerInfo == null)
                {
                    result.htmlResponse = href("peers");
                    return result;
                }

                if (peerInfo["active"] == "0")
                {
                    result.htmlResponse = href("peers");
                    return result;
                }

                var peerMember = Db.peersGetMember(peer_id, userid, false, false);
                if (peerMember == null)
                {
                    result.htmlResponse = href("peers");
                    return result;
                }

                if (long.Parse(peerMember["priority"]) < 80 && peerInfo["owner"] != userid.ToString())
                {
                    result.htmlResponse = href("peers");
                    return result;
                }

                result.htmlResponse = result.htmlResponse.Replace("%peerid%", peer_id.ToString());
                result.htmlResponse = result.htmlResponse.Replace("%peertitle%", peerInfo["title"]);

                vk Vk = new(cache);

                var usersVk = await Vk.UsersGetVkInfo(new long[] { long.Parse(peerInfo["owner"]) } );

                var UserNameV = "неизвестно";
                var linkVk = "https://vk.com/";
                if (long.Parse(peerInfo["owner"]) < 0)
                {
                    UserNameV = "Сообщество";
                    linkVk += "club" + peerInfo["owner"].Substring(1);
                }
                else
                {
                    if (peerInfo["owner"] == "0")
                    {

                        linkVk = "https://vk.com/";
                        UserNameV = "Не определено";
                    }
                    else
                    {
                        if (usersVk != null)
                        {
                            if (usersVk.ContainsKey("id" + peerInfo["owner"]))
                            {
                                UserNameV = usersVk["id" + peerInfo["owner"]].first_name + " " + usersVk["id" + peerInfo["owner"]].last_name;
                            }
                        }
                        linkVk += "id" + peerInfo["owner"];
                    }
                }

                result.htmlResponse = result.htmlResponse.Replace("%peerowner%", $@"<a href=""{linkVk}"">{UserNameV}</a>");
                result.htmlResponse = result.htmlResponse.Replace("%memberscount%", peerInfo["current_members"]);
                result.htmlResponse = result.htmlResponse.Replace("%date_reg%", Db.timeGetForMysql(peerInfo["date_reg"]).ToString("g"));
                var roles = Db.peerGetRoles(peer_id);
                if (roles != null)
                {
                    if (!roles.ContainsKey("0"))
                    {
                        roles.Add("0", new NamesRoles() { name = "Пользователь", priority = 0 });
                    }
                    if (!roles.ContainsKey("20"))
                    {
                        roles.Add("20", new NamesRoles() { name = "Помощник", priority = 20 });
                    }
                    if (!roles.ContainsKey("40"))
                    {
                        roles.Add("40", new NamesRoles() { name = "Модератор", priority = 40 });
                    }
                    if (!roles.ContainsKey("60"))
                    {
                        roles.Add("60", new NamesRoles() { name = "Администратор", priority = 60 });
                    }
                    if (!roles.ContainsKey("80"))
                    {
                        roles.Add("80", new NamesRoles() { name = "Главный Администратор", priority = 80 });
                    }
                    if (!roles.ContainsKey("100"))
                    {
                        roles.Add("100", new NamesRoles() { name = "Владелец", priority = 100 });
                    }
                    //roles = from entry in roles orderby entry.Value.priority ascending select entry;
                    result.htmlResponse = result.htmlResponse.Replace("%peerCountRoles%", roles.Count.ToString());
                }
                else
                {
                    result.htmlResponse = result.htmlResponse.Replace("%peerCountRoles%", "—");
                }

                if (peerInfo["logo"] != "")
                {
                    result.htmlResponse = result.htmlResponse.Replace("%peer_avatar%", peerInfo["logo"]);
                }
                else
                {
                    result.htmlResponse = result.htmlResponse.Replace("%peer_avatar%", "/images/logo.png");
                }

                //peerCountRoles
                //<a href="https://vk.com/ivan">Иван Фамилия</a>

                if (peerInfo["silence"] == "2")
                {
                    result.htmlResponse = result.htmlResponse.Replace("%datastatus_silence%", "delete");
                    result.htmlResponse = result.htmlResponse.Replace("%text_selince%", "удалять сообщения");
                }
                else if (peerInfo["silence"] == "1")
                {
                    result.htmlResponse = result.htmlResponse.Replace("%datastatus_silence%", "kick");
                    result.htmlResponse = result.htmlResponse.Replace("%text_selince%", "исключать пользователя");
                }
                else
                {
                    result.htmlResponse = result.htmlResponse.Replace("%datastatus_silence%", "nou");
                    result.htmlResponse = result.htmlResponse.Replace("%text_selince%", "ничего не делать");
                }

                if (peerInfo["set_kickexit"] == "1")
                {
                    result.htmlResponse = result.htmlResponse.Replace("%datestatus_set_kickexit%", "true");
                    result.htmlResponse = result.htmlResponse.Replace("%text_set_kickexit%", "включено");
                }
                else
                {
                    result.htmlResponse = result.htmlResponse.Replace("%datestatus_set_kickexit%", "false");
                    result.htmlResponse = result.htmlResponse.Replace("%text_set_kickexit%", "выключено");
                }

                if (peerInfo["set_kickexitrole"] == "1")
                {
                    result.htmlResponse = result.htmlResponse.Replace("%datestatus_set_kickexitrole%", "true");
                    result.htmlResponse = result.htmlResponse.Replace("%text_set_kickexitrole%", "включено");
                }
                else
                {
                    result.htmlResponse = result.htmlResponse.Replace("%datestatus_set_kickexitrole%", "false");
                    result.htmlResponse = result.htmlResponse.Replace("%text_set_kickexitrole%", "выключено");
                }
                


                if (peerInfo["set_kickinviter"] == "1")
                {
                    result.htmlResponse = result.htmlResponse.Replace("%datestatus_set_kickinviter%", "true");
                    result.htmlResponse = result.htmlResponse.Replace("%text_set_kickinviter%", "включено");
                }
                else
                {
                    result.htmlResponse = result.htmlResponse.Replace("%datestatus_set_kickinviter%", "false");
                    result.htmlResponse = result.htmlResponse.Replace("%text_set_kickinviter%", "выключено");
                }

                if (peerInfo["set_exitremovenick"] == "1")
                {
                    result.htmlResponse = result.htmlResponse.Replace("%datestatus_set_exitremovenick%", "del");
                    result.htmlResponse = result.htmlResponse.Replace("%text_set_exitremovenick%", "удалять ник");
                }
                else
                {
                    result.htmlResponse = result.htmlResponse.Replace("%datestatus_set_exitremovenick%", "nou");
                    result.htmlResponse = result.htmlResponse.Replace("%text_set_exitremovenick%", "не удалять ник");
                }
                //var Vk = new vk(cache); set_exitremovenick

                string rolesInvite = "";
                var rolesparse = from entry in roles orderby entry.Value.priority ascending select entry;
                foreach (var item in rolesparse)
                {
                    rolesInvite += @$"<button class=""role-item"" data-role-id=""{item.Value.priority}"">{item.Value.name} ({item.Value.priority})</button>" + "\n";
                }
                result.htmlResponse = result.htmlResponse.Replace("<!--ROLESINVITE-->", rolesInvite);

                var role = long.Parse(peerInfo["set_inviterrole"]);
                string targetRoleName = $"Пользователь ({role})";
                if (!roles.ContainsKey(role.ToString()))
                {
                    if (role < 40)
                    {
                        targetRoleName = $"Помощник ({role})";
                    }
                    else if (role < 60)
                    {
                        targetRoleName = $"Модератор ({role})";
                    }
                    else if (role < 80)
                    {
                        targetRoleName = $"Администратор ({role})";
                    }
                    else if (role < 100)
                    {
                        targetRoleName = $"Главный Администратор ({role})";
                    }
                    else
                    {
                        targetRoleName = $"Неизвестно ({role})";
                    }
                }
                else
                {
                    targetRoleName = roles[role.ToString()].name + $" ({role})";
                }

                result.htmlResponse = result.htmlResponse.Replace("%inviterrole%", targetRoleName);
                return result;
            }
            catch (Exception e)
            {
                result.htmlResponse = "error - undefined " + e.Message + " " + e.StackTrace;
                return result;
            }
        }
    }
}
