﻿using GrandManager.engine.properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class Admin : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "admin",

                nameOfClass = "GrandManager.engine.API.Method.Admin",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public async Task<AnswerTemplane> work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            try
            {
                var session = await getUserSessionAsync(Cookies);

                if (session == null)
                {
                    result.htmlResponse = href("auth");
                    return result;
                }

                if (settings.OWNER_IDS.ContainsKey(session.user_id) && settings.OWNER_IDS[session.user_id].admin != 1)
                {
                    result.htmlResponse = getCacheTemplane("admin_panel.html", true, "admin", true);
                }
                else
                {
                    result.htmlResponse = href("auth");
                }

                return result;
            }
            catch (Exception e)
            {
                result.htmlResponse = "error - undefined " + e.Message + " " + e.StackTrace;
                return result;
            }
        }
    }
}
