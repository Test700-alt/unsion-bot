﻿using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;
using SixLabors.ImageSharp.Drawing.Processing;
using SixLabors.Fonts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
using SixLabors.ImageSharp.PixelFormats;

namespace GrandManager.engine.ImageCringe
{
    internal class ImageCringe
    {
        public static async Task<string> DistortImageAsync(string imageUrl, string saveDirectory, double distortionStrength = 1.0)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    var response = await client.GetAsync(imageUrl);
                    response.EnsureSuccessStatusCode();
                    using (var imageStream = await response.Content.ReadAsStreamAsync())
                    {
                        using (var image = SixLabors.ImageSharp.Image.Load<Rgba32>(imageStream))
                        {
                            var savePath = GenerateRandomFileName(saveDirectory, ".png");
                            DistortImage(image, distortionStrength);
                            await image.SaveAsync(savePath);
                            return savePath;
                        }
                    }
                }
            }
            catch (HttpRequestException ex)
            {
                Console.WriteLine($"Ошибка при загрузке изображения: {ex.Message}");
                return null;
            }
            catch (ImageProcessingException ex)
            {
                Console.WriteLine($"Ошибка при обработке изображения: {ex.Message}");
                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Произошла ошибка: {ex.Message}");
                return null;
            }

        }

        private static void DistortImage(Image<Rgba32> image, double distortionStrength)
        {
            try
            {
                int width = image.Width;
                int height = image.Height;
                double centerX = width / 2.0;

                // Случайный коэффициент сжатия для всего изображения
                Random random = new Random();
                double compressionFactor = 0.6 + random.NextDouble() * 0.3 * distortionStrength;


                // Создаем новое изображение, куда будем записывать результат
                using (SixLabors.ImageSharp.Image<Rgba32> distortedImage = new SixLabors.ImageSharp.Image<Rgba32>(width, height))
                {
                    Parallel.For(0, height, y =>
                    {
                        for (int x = 0; x < width; x++)
                        {
                            // Сжатие к центру
                            double normalizedX = (x - centerX) / centerX;
                            double compressedX = centerX + normalizedX * centerX * (1 - Math.Abs(normalizedX) * compressionFactor);


                            int sourceX = (int)Math.Round(Math.Clamp(compressedX, 0, width - 1));


                            distortedImage[x, y] = image[sourceX, y];
                        }
                    });

                    // Копируем измененное изображение на исходное
                    image.Mutate(ctx => ctx.DrawImage(distortedImage, Point.Empty, 1f));
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("xuir " + e.Message + " e " + e.StackTrace);
            }
        }

        private static string GenerateRandomFileName(string directory, string extension)
        {
            string fileName = $"{Guid.NewGuid()}{extension}";
            return "/root/vk/" + directory + "/" + "" + fileName;
            //return directory + "\\" + fileName;
        }
    }
}
