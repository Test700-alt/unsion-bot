﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Sockets;
using System.Threading.Tasks;
using System.Collections.Generic;

public static class SystemInfoProvider
{
    /// <summary>
    /// Асинхронно получает информацию о системе: локальный IP, публичный IP и имя пользователя.
    /// </summary>
    /// <returns>
    /// Кортеж (Tuple) со строками: (string localIp, string publicIp, string userName).
    /// В случае ошибки получения какого-либо значения, в соответствующем поле будет сообщение об ошибке.
    /// </returns>
    public static async Task<(string localIp, string publicIp, string userName)> GetSystemInfoAsync()
    {
        // 1. Получение имени пользователя (кроссплатформенно)
        string userName = "Unknown";
        try
        {
            userName = Environment.UserName;
        }
        catch (Exception ex)
        {
            userName = $"Error getting user: {ex.Message}";
        }

        // 2. Получение локального IP-адреса (прямой способ)
        string localIp = "Not Found";
        try
        {
            using (Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, 0))
            {
                // Этот трюк не устанавливает реальное соединение, но позволяет ОС определить
                // какой локальный интерфейс будет использован для выхода в интернет.
                socket.Connect("8.8.8.8", 65530);
                IPEndPoint? endPoint = socket.LocalEndPoint as IPEndPoint;
                localIp = endPoint?.Address.ToString() ?? "Not Found";
            }
        }
        catch (Exception)
        {
            // Резервный метод, если первый не сработал
            try
            {
                var hostEntry = Dns.GetHostEntry(Dns.GetHostName());
                localIp = hostEntry.AddressList
                                   .FirstOrDefault(ip => ip.AddressFamily == AddressFamily.InterNetwork)?
                                   .ToString() ?? "Not Found";
            }
            catch (Exception ex)
            {
                localIp = $"Error getting local IP: {ex.Message}";
            }
        }

        // 3. Получение публичного IP-адреса (через API с резервированием)
        string publicIp = "Not Found";
        // Список надежных сервисов
        var apiUrls = new List<string> { "https://api.ipify.org", "https://icanhazip.com", "https://checkip.amazonaws.com" };

        using (var httpClient = new HttpClient())
        {
            // Установим небольшой таймаут, чтобы не ждать долго ответа от неработающего сервиса
            httpClient.Timeout = TimeSpan.FromSeconds(5);

            foreach (var url in apiUrls)
            {
                try
                {
                    string ip = await httpClient.GetStringAsync(url);
                    if (!string.IsNullOrWhiteSpace(ip))
                    {
                        publicIp = ip.Trim();
                        break; // Успех, выходим из цикла
                    }
                }
                catch (Exception)
                {
                    // Ошибка, просто переходим к следующему сервису в списке
                    continue;
                }
            }
        }
        if (publicIp == "Not Found")
        {
            publicIp = "Error: Could not contact any external IP service.";
        }


        return (localIp, publicIp, userName);
    }
}