﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine
{
    internal class MenuList
    {
        public enum ListMenu
        {
            MENU_NIL,
            SETUP_MAIN,
            SETUP_STEP2,
            SETUP_STEP3,

            MENU_EDITUNITY_SETNAME,
            MENU_EDITUNITY_SETDESCRIPTION,

            MENU_EDITCMD,
            MENU_GEDITCMD,

            GAME_MARRY_INVITE,

            ADMIN_ANSWER_REPORT
        }

        private Cache Cache;

        public MenuList(Cache cach)
        {
            Cache = cach;
        }

        public long getMenuSelect(long userid)
        {
            Dictionary<string, string> listMenu = Cache.Get<Dictionary<string, string>>("menu_" + userid);
            if (listMenu == null)
            {
                listMenu = new Dictionary<string, string>();
                listMenu["menu"] = "0";
                Cache.Set("menu_" + userid, listMenu, 20);
                return 0;
            }
            else
            {
                if (listMenu.ContainsKey("menu"))
                {
                    return long.Parse(listMenu["menu"]);
                }
                else
                {
                    listMenu = new Dictionary<string, string>();
                    listMenu["menu"] = "0";
                    Cache.Set("menu_" + userid, listMenu, 20);
                    return 0;
                }
            }
        }

        public void setMenuSelect(long userid, long menu)
        {
            Dictionary<string, string> listMenu = new() { { "menu", menu.ToString() } };
            Cache.Set("menu_" + userid, listMenu, 20);
        }
    }
}
