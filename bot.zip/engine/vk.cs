﻿using GrandManager.engine.DataBaseClass;
using Microsoft.AspNetCore.WebUtilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Org.BouncyCastle.Bcpg;
using Org.BouncyCastle.Utilities;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Numerics;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;

namespace GrandManager.engine
{
    internal class vk
    {

        /* 
         * Переменные от ВК
         * СООБЩЕНИЕ
         */
        public long m_date;
        public long m_from_id;
        public long m_chat_id;
        public long m_id;
        public long m_out;
        public JToken? m_attachments;
        public long m_conversation_message_id;
        public JToken? m_fwd_messages;
        public JToken? m_reply_message;
        public long m_important;
        public long m_is_hidden;
        public long m_peer_id;
        public long m_random_id;
        public string? m_text;
        public string? m_text_origin;
        public JToken? format_data;
        public m_actionc? m_action;
        public JToken? m_payload;
        /* 
         * Переменные от ВК
         * ДАННЫЕ О КЛИЕНТЕ
         */
        public long c_button_actions;
        public long c_keyboard;
        public long c_inline_keyboard;
        public long c_carousel;
        public long c_lang_id;
        public string? event_id;
        public bool is_callbackButton = false;

        public string BUTTON_GREEN = "positive";
        public string BUTTON_BLUE = "primary";
        public string BUTTON_WHITE = "secondary";
        public string BUTTON_RED = "negative";

        private static HttpClient client = new HttpClient();

        private static object lock_tokens = new();

        public static ConcurrentDictionary<string, string> messagesForDelete = new();
        public static ConcurrentDictionary<string, Dictionary<string, string>> waitMethods = new();

        public static ConcurrentDictionary<string, Dictionary<string, string>> mafios = new();

        public static ConcurrentDictionary<string, JObject> waitResult = new();

        private Cache? Cache = null;

        public vk(Cache Cach)
        {
            Cache = Cach;
            //client = null;
        }

        public void LoadParams(JToken object_data)
        {
            try
            {
                
                if (object_data["message"] == null && object_data["text"] == null)
                {
                    if (object_data["event_id"] == null)
                    {
                        return;
                    }
                    is_callbackButton = true;
                    event_id = object_data["event_id"].ToString();
                    m_peer_id = (long)object_data["peer_id"];
                    m_from_id = (long)object_data["user_id"];
                    if (object_data["conversation_message_id"] != null)
                    {
                        m_conversation_message_id = (long)object_data["conversation_message_id"];
                    }

                    Console.WriteLine("[CALLBACK] Payload: " + object_data["payload"]?.ToString());

                    if (object_data["payload"] != null)
                    {
                        JObject vrem = JObject.Parse(object_data["payload"].ToString());
                        m_payload = vrem;
                        Console.WriteLine("[CALLBACK] Payload loaded: " + m_payload.ToString());
                    }
                    else
                    {
                        m_payload = null;
                    }
                    return;
                }

                JToken? message;
                if (object_data["from_id"] != null && object_data["text"] != null)
                {
                    message = object_data;
                }
                else
                {
                    message = object_data["message"];
                }
                m_id = (long)message["id"];
                m_date = (long)message["date"];
                m_peer_id = (long)message["peer_id"];
                if (m_peer_id < settings.PEERS_CHATID)
                {
                    m_chat_id = m_peer_id;
                }
                else
                {
                    m_chat_id = m_peer_id - settings.PEERS_CHATID;
                }
                m_from_id = (long)message["from_id"];
                m_text = message["text"].ToString();
                if (message["attachments"] != null)
                {
                    m_attachments = message["attachments"];
                }

                if (message["format_data"] != null)
                {
                    JObject vrem = JObject.Parse(message["format_data"].ToString());
                    format_data = vrem;
                }
                else
                {
                    format_data = null;
                }

                if (message["payload"] != null)
                {
                    JObject vrem = JObject.Parse(message["payload"].ToString());
                    m_payload = vrem;
                }
                else
                {
                    m_payload = null;
                }
                if (message["fwd_messages"] != null)
                {
                    m_fwd_messages = message["fwd_messages"];
                }

                if (message["reply_message"] != null)
                {
                    m_reply_message = message["reply_message"];
                }
                if (message["action"] != null)
                {
                    m_action = new m_actionc();
                    m_action.type = message["action"]["type"].ToString();
                    if (message["action"]["member_id"] != null)
                    {
                        m_action.member_id = (long)message["action"]["member_id"];
                    }
                    if (message["action"]["text"] != null)
                    {
                        m_action.text = message["action"]["text"].ToString();
                    }
                    if (message["action"]["email"] != null)
                    {
                        m_action.email = message["action"]["email"].ToString();
                    }
                }
                m_conversation_message_id = (long)message["conversation_message_id"];

                //Console.WriteLine(object_data);
                return;
            }
            catch
            {
                return;
            }
        }

        public string GenerateKeyboard(string[] names, string[] commands, string[] colors, int[]? lines = null, bool one_time = false, bool inline = true, bool callback = true)
        {
            keyboard keys = new() { inline = inline, one_time = one_time};
            List<List<button>> buts = new List<List<button>>();
            button[,] butt = new button[names.Count(), 1];
            

            int[] linesd = new int[] { 0 };
            long standart_offset = 0;
            long offset_line = 0;
            long current_line = 0;
            //buts.Add(new List<List<button>>());
            for (int i = 0; i < names.Count(); i++)
            {
                string saxzd = i.ToString();
                if(lines != null)
                {

                    if (buts.Count <= lines[i])
                    {
                        buts.Add(new List<button>());
                    }

                    if (lines[i] != current_line)
                    {
                        current_line = lines[i];
                        offset_line = 0;
                        //buts.Add(new List<List<button>>());
                    }
                    //if (buts[i].Count < offset_line)
                    //{
                        //buts.Add(new List<List<button>>());
                   // }
                    if (callback)
                    {
                        buts[lines[i]].Add(new button()
                        {
                            action = new action_button()
                            {
                                type = "callback",
                                label = names[i],
                                payload = JsonConvert.SerializeObject(new Dictionary<string, string>() { { "execute", commands[i] } }),
                            },
                            color = colors[i]
                        });
                        offset_line++;
                    }
                    else
                    {
                        buts[lines[i]].Add(new button()
                        {
                            action = new action_button()
                            {
                                label = names[i],
                                payload = JsonConvert.SerializeObject(new Dictionary<string, string>() { { "execute", commands[i] } }),
                            },
                            color = colors[i]
                        });
                        offset_line++;
                    }
                }
                else
                {
                    if (buts.Count <= standart_offset)
                    {
                        buts.Add(new List<button>());
                    }
                    if (callback)
                    {
                        buts[i].Add(new button()
                        {
                            action = new action_button()
                            {
                                type = "callback",
                                label = names[i],
                                payload = JsonConvert.SerializeObject(new Dictionary<string, string>() { { "execute", commands[i] } }),

                            },
                            color = colors[i]
                        });
                    }
                    else
                    {
                        buts[i].Add(new button()
                        {
                            action = new action_button()
                            {
                                label = names[i],
                                payload = JsonConvert.SerializeObject(new Dictionary<string, string>() { { "execute", commands[i] } }),

                            },
                            color = colors[i]
                        });
                    }
                }
                standart_offset++;
            }
            
            //butt[0,0].action.color = "primary";
            keys.buttons = buts;
            //Console.WriteLine(JsonConvert.SerializeObject(keys));
            return JsonConvert.SerializeObject(keys);
        }

        public async Task<long> MessagesSend(string text, long reply = 1, long peer_id = 0, string keyboard = "", bool disable_mentions = true, string attachments = "", string format_data = "")
        {

            if(text.Length >= 4000)
            {
                
                var words = text.Split("<br>");
                var maxLengthString = 3000;
                long wordIndex = 0;
                var spaceLetter = "<br>";
                var currentLine = new StringBuilder();

                var listMess = new List<string>();

                while (wordIndex < words.Length)
                {
                    string currentWord = words[wordIndex];

                    // Если currentLine пуст и текущее слово само по себе слишком длинное
                    if (currentLine.Length == 0 && currentWord.Length > maxLengthString)
                    {
                        // Разбиваем слишком длинное слово на части
                        string wordPartToProcess = currentWord;
                        while (wordPartToProcess.Length > 0)
                        {
                            int takeLength = Math.Min(wordPartToProcess.Length, maxLengthString);
                            listMess.Add(wordPartToProcess.Substring(0, takeLength));
                            wordPartToProcess = wordPartToProcess.Substring(takeLength);
                        }
                        wordIndex++;
                        continue; // Переходим к следующему слову
                    }

                    // Если добавление текущего слова (с разделителем) превысит лимит
                    // (проверяем currentLine.Length > 0, чтобы не добавлять spaceLetter к пустому сообщению)
                    int lengthWithNextWord = currentLine.Length +
                                             (currentLine.Length > 0 ? spaceLetter.Length : 0) +
                                             currentWord.Length;

                    if (lengthWithNextWord > maxLengthString && currentLine.Length > 0)
                    {
                        // Завершаем текущую строку и добавляем в список
                        listMess.Add(currentLine.ToString());
                        currentLine.Clear();
                        // wordIndex не увеличиваем, т.к. currentWord еще не добавлен и будет обработан на следующей итерации для новой строки
                    }
                    else if (lengthWithNextWord <= maxLengthString) // Слово помещается (либо currentLine был пуст и слово помещается)
                    {
                        if (currentLine.Length > 0)
                        {
                            currentLine.Append(spaceLetter);
                        }
                        currentLine.Append(currentWord);
                        wordIndex++;
                    }
                    else // Сюда мы не должны попасть, если currentLine пуст и слово не помещается (обработано выше)
                    {
                        // Это может произойти, если currentLine пуст, но currentWord + spaceLetter > maxLengthString,
                        // а сам currentWord <= maxLengthString. В этом случае добавляем слово без spaceLetter.
                        // Или если currentWord настолько длинный, что даже один он не помещается (это уже должно было быть обработано выше).
                        // На всякий случай, если слово само по себе помещается, а с разделителем нет, и строка пуста, то добавляем слово
                        if (currentWord.Length <= maxLengthString)
                        {
                            listMess.Add(currentWord);
                            wordIndex++;
                            // currentLine остается пустым
                        }
                        else
                        {
                            // Это аварийный случай, если логика выше не сработала для очень длинного слова
                            // по идее, это не должно произойти из-за первой проверки if (currentLine.Length == 0 && currentWord.Length > maxLengthString)
                            // Но для безопасности, если слово все же слишком длинное и не обработалось
                            string emergencyPart = currentWord.Substring(0, Math.Min(currentWord.Length, maxLengthString));
                            listMess.Add(emergencyPart);
                            // Потенциальная проблема: остаток слова теряется. Логика выше должна была это разбить.
                            // Чтобы избежать потери, нужно было бы здесь рекурсивно или в цикле обрабатывать остаток currentWord.
                            // Но для простоты исправления, предположим, что первый блок для "слишком длинных слов" это покрывает.
                            wordIndex++;
                        }
                    }
                }

                // Добавляем остаток, если он есть
                if (currentLine.Length > 0)
                {
                    listMess.Add(currentLine.ToString());
                }

                foreach (var item in listMess)
                {
                    var temp_text = item;
                    Dictionary<string, string> paramess = new Dictionary<string, string>();
                    if (attachments != "" &&  wordIndex == words.Length )
                    {
                        paramess["attachment"] = attachments;
                    }
                    if (peer_id == 0)
                    {
                        peer_id = m_peer_id;
                    }
                    if (reply == 1 && wordIndex == 1)
                    {
                        m_forward fowrad = new m_forward(peer_id, 1, m_conversation_message_id);
                        paramess["forward"] = JsonConvert.SerializeObject(fowrad);
                    }
                    if (keyboard != "")
                    {
                        paramess["keyboard"] = keyboard;
                    }
                    else
                    {
                        paramess["keyboard"] = GenerateKeyboard(new string[] { }, new string[] { }, new string[] { }, new int[] { }, true, false);
                    }
                    if (disable_mentions)
                    {
                        paramess["disable_mentions"] = "1";
                    }
                    else
                    {
                        paramess["disable_mentions"] = "0";
                    }
                    paramess["message"] = temp_text;
                    paramess["peer_id"] = peer_id.ToString();
                    //Random? rdnd = new Random();
                    paramess["random_id"] = "0"; //rdnd.Next().ToString();
                    //rdnd = null;
                    AdminInfo.send_vksendmessage++;
#pragma warning disable CS4014
                    _ = await VkAPI("messages.send", paramess);
#pragma warning restore CS4014
                }

                return 0;
            }

            Dictionary<string, string> parames = new Dictionary<string, string>();
            if (attachments != "")
            {
                parames["attachment"] = attachments;
            }
            if(peer_id == 0)
            {
                peer_id = m_peer_id;
            }
            if (reply == 1)
            {
                if (m_conversation_message_id != null && m_conversation_message_id != 0)
                {
                    m_forward fowrad = new m_forward(peer_id, 1, m_conversation_message_id);
                    parames["forward"] = JsonConvert.SerializeObject(fowrad);
                }
            }
            if (keyboard != "")
            {
                parames["keyboard"] = keyboard;
            }
            else
            {
                parames["keyboard"] = GenerateKeyboard(new string[] { }, new string[] { }, new string[] { }, new int[] { }, true, false);
            }

            if (format_data != "")
            {
                parames["format_data"] = format_data;
            }

            if (disable_mentions)
            {
                parames["disable_mentions"] = "1";
            }
            else
            {
                parames["disable_mentions"] = "0";
            }
            parames["message"] = text;
            parames["peer_id"] = peer_id.ToString();
            Random rnd = new Random();
            parames["random_id"] = "0"; rnd.Next().ToString();
            rnd = null;
            AdminInfo.send_vksendmessage++;
            var res = await VkAPI("messages.send", parames);
            if (res.ContainsKey("response"))
            {
                if (res["response"].ToString().ToLower() == "false")
                {
                    if (settings.isUserChat(peer_id))
                    {
                        Database db = new(Cache);
                        db.gameSetAcceptLs(peer_id, 0);
                    }
                    return 0;
                }
                else
                {
                    return 1;
                }
            }

            if (res.ContainsKey("error"))
            {
                if (settings.isUserChat(peer_id))
                {
                    Database db = new(Cache);
                    db.gameSetAcceptLs(peer_id, 0);
                }
                return 0;
            }
            return 1;
        }

        public async Task<long> MessagesSendMassive(string text, List<long> peer_id, string keyboard = "", bool disable_mentions = true, string attachments = "")
        {

            if (text.Length >= 4000)
            {
                var words = text.Split("<br>");
                var maxLengthString = 4000;
                long wordIndex = 0;
                var spaceLetter = "<br>";
                var currentLine = new StringBuilder();

                var listMess = new List<string>();

                while (wordIndex < words.Length)
                {
                    string currentWord = words[wordIndex];

                    // Если currentLine пуст и текущее слово само по себе слишком длинное
                    if (currentLine.Length == 0 && currentWord.Length > maxLengthString)
                    {
                        // Разбиваем слишком длинное слово на части
                        string wordPartToProcess = currentWord;
                        while (wordPartToProcess.Length > 0)
                        {
                            int takeLength = Math.Min(wordPartToProcess.Length, maxLengthString);
                            listMess.Add(wordPartToProcess.Substring(0, takeLength));
                            wordPartToProcess = wordPartToProcess.Substring(takeLength);
                        }
                        wordIndex++;
                        continue; // Переходим к следующему слову
                    }

                    // Если добавление текущего слова (с разделителем) превысит лимит
                    // (проверяем currentLine.Length > 0, чтобы не добавлять spaceLetter к пустому сообщению)
                    int lengthWithNextWord = currentLine.Length +
                                             (currentLine.Length > 0 ? spaceLetter.Length : 0) +
                                             currentWord.Length;

                    if (lengthWithNextWord > maxLengthString && currentLine.Length > 0)
                    {
                        // Завершаем текущую строку и добавляем в список
                        listMess.Add(currentLine.ToString());
                        currentLine.Clear();
                        // wordIndex не увеличиваем, т.к. currentWord еще не добавлен и будет обработан на следующей итерации для новой строки
                    }
                    else if (lengthWithNextWord <= maxLengthString) // Слово помещается (либо currentLine был пуст и слово помещается)
                    {
                        if (currentLine.Length > 0)
                        {
                            currentLine.Append(spaceLetter);
                        }
                        currentLine.Append(currentWord);
                        wordIndex++;
                    }
                    else // Сюда мы не должны попасть, если currentLine пуст и слово не помещается (обработано выше)
                    {
                        // Это может произойти, если currentLine пуст, но currentWord + spaceLetter > maxLengthString,
                        // а сам currentWord <= maxLengthString. В этом случае добавляем слово без spaceLetter.
                        // Или если currentWord настолько длинный, что даже один он не помещается (это уже должно было быть обработано выше).
                        // На всякий случай, если слово само по себе помещается, а с разделителем нет, и строка пуста, то добавляем слово
                        if (currentWord.Length <= maxLengthString)
                        {
                            listMess.Add(currentWord);
                            wordIndex++;
                            // currentLine остается пустым
                        }
                        else
                        {
                            // Это аварийный случай, если логика выше не сработала для очень длинного слова
                            // по идее, это не должно произойти из-за первой проверки if (currentLine.Length == 0 && currentWord.Length > maxLengthString)
                            // Но для безопасности, если слово все же слишком длинное и не обработалось
                            string emergencyPart = currentWord.Substring(0, Math.Min(currentWord.Length, maxLengthString));
                            listMess.Add(emergencyPart);
                            // Потенциальная проблема: остаток слова теряется. Логика выше должна была это разбить.
                            // Чтобы избежать потери, нужно было бы здесь рекурсивно или в цикле обрабатывать остаток currentWord.
                            // Но для простоты исправления, предположим, что первый блок для "слишком длинных слов" это покрывает.
                            wordIndex++;
                        }
                    }
                }

                // Добавляем остаток, если он есть
                if (currentLine.Length > 0)
                {
                    listMess.Add(currentLine.ToString());
                }

                foreach (var item in listMess)
                {
                    var temp_text = item;
                    Dictionary<string, string> paramess = new Dictionary<string, string>();
                    if (attachments != "" && wordIndex == words.Length)
                    {
                        paramess["attachment"] = attachments;
                    }
                    if (keyboard != "")
                    {
                        paramess["keyboard"] = keyboard;
                    }
                    else
                    {
                        paramess["keyboard"] = GenerateKeyboard(new string[] { }, new string[] { }, new string[] { }, new int[] { }, true, false);
                    }
                    if (disable_mentions)
                    {
                        paramess["disable_mentions"] = "1";
                    }
                    paramess["message"] = temp_text;
                    paramess["peer_ids"] = string.Join(",", peer_id);
                    Random rdnd = new Random();
                    paramess["random_id"] = rdnd.Next().ToString();
                    rdnd = null;
                    AdminInfo.send_vksendmessage++;
#pragma warning disable CS4014
                    _ = await VkAPI("messages.send", paramess);
#pragma warning restore CS4014
                }

                return 1;
            }

            Dictionary<string, string> parames = new Dictionary<string, string>();
            if (attachments != "")
            {
                parames["attachment"] = attachments;
            }
            if (keyboard != "")
            {
                parames["keyboard"] = keyboard;
            }
            else
            {
                parames["keyboard"] = GenerateKeyboard(new string[] { }, new string[] { }, new string[] { }, new int[] { }, true, false);
            }
            if (disable_mentions)
            {
                parames["disable_mentions"] = "1";
            }
            parames["message"] = text;
            if (peer_id.Count >= 2)
            {
                parames["peer_ids"] = String.Join(",", peer_id);
            }
            else if (peer_id.Count == 1)
            {
                parames["peer_ids"] = peer_id[0].ToString();
            }
            else
            {
                return 0;
            }
            Random rnd = new Random();
            parames["random_id"] = rnd.Next().ToString();
            rnd = null;
            AdminInfo.send_vksendmessage++;
            var result = await VkAPI("messages.send", parames);

            if (result.ContainsKey("response"))
            {
                if (result["response"].ToString().ToLower() == "false")
                {
                    return 0;
                }
                else
                {
                    var respons = result["response"];
                    if (respons.Count() >= 1)
                    {
                        if (respons[0]["conversation_message_id"] != null)
                        {
                            return long.Parse(respons[0]["conversation_message_id"].ToString());
                        }
                        else
                        {
                            return 1;
                        }
                    }
                    return 1;
                }
            }
            return 1;
        }

        public async Task<long> MessagesEdit(string text, long peer_id, string keyboard = "", bool disable_mentions = true, string attachments = "", long mID = 0)
        {
            Dictionary<string, string> parames = new Dictionary<string, string>();
            if (attachments != "")
            {
                parames["attachment"] = attachments;
            }
            if (keyboard != "")
            {
                parames["keyboard"] = keyboard;
            }
            else
            {
                parames["keyboard"] = GenerateKeyboard(new string[] { }, new string[] { }, new string[] { }, new int[] { }, true, false);
            }
            if (disable_mentions)
            {
                parames["disable_mentions"] = "1";
            }
            parames["message"] = text;

            parames["peer_id"] = peer_id.ToString();
            parames["conversation_message_id"] = mID.ToString();
            Random rnd = new Random();
            parames["random_id"] = "0";//rnd.Next().ToString();
            rnd = null;
            AdminInfo.send_vksendmessage++;
            var result = await VkAPI("messages.edit", parames);

            if (result.ContainsKey("response"))
            {
                if (result["response"].ToString().ToLower() == "false")
                {
                    return 0;
                }
                else
                {
                    return 1;
                }
            }
            return 1;
        }

        public async Task MessagesSendEventAnswer(string event_id, long user_id, long peer_id, string event_data)
        {
            var method = "messages.sendMessageEventAnswer";
            var parames = new Dictionary<string, string>()
            {
                { "event_id", event_id },
                { "user_id", user_id.ToString() },
                { "peer_id", peer_id.ToString() },
                { "event_data", event_data }
            };
            var res = await VkAPI(method, parames);
            //Console.WriteLine(res.ToString());
        }

        public string GenerateEventData(string text, string type = "show_snackbar")
        {
            return JsonConvert.SerializeObject(new Dictionary<string, string> () { { "type", type }, { "text", text } });
        }

        public async Task<string> GetUrlName(long userid, string name_case = "nom")
        {
            Dictionary<string, usersNameVk> userinfo = await UsersGetName(new long[] { userid }, false, name_case);
            if (userinfo.ContainsKey("id" + userid))
            {
                return "[id" + userid + "|" + userinfo["id" + userid].first_name + " " + userinfo["id" + userid].last_name + "]";
            }
            else
            {
                return null;
            }
        }


        public async Task<Dictionary<string, usersNameVk>> UsersGetName(long[] userid, bool update_cache = false, string name_case = "nom")
        {
            var temp_info = await UsersGetVkInfo(userid, update_cache, name_case);

            return temp_info;
        }

        public async Task<Dictionary<string, string>> UserGetNameUrls(long[] userid, bool update_cache = false, string name_case = "nom")
        {
            try
            {
                var vkInfo = await UsersGetVkInfo(userid, update_cache, name_case);

                var Result = new Dictionary<string, string>();

                foreach (var item in userid)
                {
                    string url = $"[id{item}|Пользователь]";
                    if (vkInfo.ContainsKey("id" + item.ToString()))
                    {
                        url = "[id" + item.ToString() + "|" + vkInfo["id" + item.ToString()].first_name + " " +
                        vkInfo["id" + item.ToString()].last_name + "]";
                    }
                    else
                    {
                        if (item < 0)
                        {
                            url = "[club" + item.ToString().Substring(1) + "|Сообщество]";
                        }
                    }

                    Result.Add(item.ToString(), url);
                }
                return Result;
            }
            catch
            {
                var Result = new Dictionary<string, string>();
                foreach (var item in userid)
                {
                    string url = $"[id{item.ToString()}|Пользователь]";
                    if (item < 0)
                    {
                        url = "[club" + item.ToString().Substring(1) + "|Сообщество]";
                    }
                    if (!Result.ContainsKey(item.ToString()))
                    {
                        Result.Add(item.ToString(), url);
                    }
                }
                return Result;
            }
        }

        public async Task<Dictionary<string, usersNameVk>> UsersGetVkInfo(long[] userid, bool update_cache = false, string name_case = "nom", bool online = false)
        /**
         *
            именительный – nom,
            родительный – gen,
            дательный – dat,
            винительный – acc,
            творительный – ins,
            предложный – abl.
            По умолчанию nom.
         */
        {
            //Dictionary<string, usersNameVk>? result = (Dictionary<string, usersNameVk>?)Cache.GetObject("vk_name_" + );
            if (userid.Length == 1 && !update_cache)
            {
                Dictionary<string, usersNameVk>? res_cache = Cache.Get<Dictionary<string, usersNameVk>>("vk_name_" + userid[0] + "_" + name_case);
                if (res_cache != null)
                {
                    return res_cache;
                }
            }

            Dictionary<string, usersNameVk> result = new Dictionary<string, usersNameVk>();

            List<long> usersForeGet = new();

            foreach (var item in userid)
            {
                if (item <= 0)
                {
                    continue;
                }
                else
                {
                    if (usersForeGet.Contains(item))
                    {
                        continue;
                    }
                    usersForeGet.Add(item);
                }
            }

            if (usersForeGet.Count() <= 0)
            {
                return result;
            }
            string massive = string.Join(",", usersForeGet);

            var requestUsersGet = new List<long>();

            if (!update_cache)
            {
                foreach (var item in userid)
                {
                    Dictionary<string, usersNameVk>? res_cache = Cache.Get<Dictionary<string, usersNameVk>>("vk_name_" + item + "_" + name_case);
                    if (res_cache != null && item >= 1)
                    {
                        if (!result.ContainsKey("id" + item))
                        {
                            result.Add("id" + item, res_cache["id" + item]);
                        }
                    }
                    else
                    {
                        requestUsersGet.Add(item);
                    }
                }

                if (result.Count() >= 1 && requestUsersGet.Count() <= 0)
                {
                    return result;
                }
                massive = String.Join(",", requestUsersGet);
            }
            else
            {
                requestUsersGet = usersForeGet;
            }

            string method = "users.get";
            
            Dictionary<string, string> parames = new()
            {
                { "user_ids", massive },
                { "name_case", name_case },
                { "fields", "sex" }
            };
            if (online)
            {
                parames["fields"] = "sex,online";
            }
            JObject resultApi = await VkAPI(method, parames);

            if (resultApi.ContainsKey("response") && resultApi["response"].Count() >= 1)
            {
                foreach (var upd in resultApi["response"])
                {
                    var sex = "1";
                    if (upd["sex"] != null)
                    {
                        sex = upd["sex"].ToString();
                    }
                    var tempValue = new usersNameVk()
                    {
                        id = (int)upd["id"],
                        first_name = upd["first_name"].ToString(),
                        last_name = upd["last_name"].ToString(),
                        sex = sex
                    };

                    if (upd["online"] != null)
                    {
                        tempValue.online = upd["online"].ToString();
                    }

                    var tempDictionary = new Dictionary<string, usersNameVk>()
                    {
                        { "id" + upd["id"].ToString(), tempValue }
                    };

                    Cache.Set("vk_name_" + upd["id"] + "_" + name_case, tempDictionary, 360);
                    result.Add("id" + upd["id"].ToString(), tempValue);
                }
            }
            return result;
        }

        public async Task<JObject> MessagesSendOneGame(string text, long reply = 1, long peer_id = 0, string keyboard = "", bool disable_mentions = true, string attachments = "")
        {
            Dictionary<string, string> parames = new Dictionary<string, string>();
            if (attachments != "")
            {
                parames["attachment"] = attachments;
            }
            if (peer_id == 0)
            {
                peer_id = m_peer_id;
            }
            if (reply == 1)
            {
                m_forward fowrad = new m_forward(peer_id, 1, m_conversation_message_id);
                parames["forward"] = JsonConvert.SerializeObject(fowrad);
            }
            if (keyboard != "")
            {
                parames["keyboard"] = keyboard;
            }
            if (disable_mentions)
            {
                parames["disable_mentions"] = "1";
            }
            parames["message"] = text;
            parames["peer_id"] = peer_id.ToString();
            Random rnd = new Random();
            parames["random_id"] = rnd.Next().ToString();
            rnd = null;
            AdminInfo.send_vksendmessage++;
            var result = await VkAPI("messages.send", parames);
            return result;
        }

        /*public static async Task<JObject> VkAPI(string method, Dictionary<string, string> parames, long tryning = 0)
        {
            try
            {
                Random rand = new();
                string number_exp = rand.Next().ToString();
                string name_task = "n_" + number_exp;
                parames["method"] = method;
                waitMethods.TryAdd(name_task, parames);

                DateTimeOffset current = DateTimeOffset.Now;

                JObject result = new();

                while (true)
                {
                    if (current.ToUnixTimeSeconds() < DateTimeOffset.Now.ToUnixTimeSeconds() - 5)
                    {
                        result.Add("error", "code1");
                        break;
                    }
                    if (waitResult.ContainsKey(name_task))
                    {
                        if (waitResult[name_task]["response"] != null && (waitResult[name_task]["response"].ToString().ToLower() == "false" || waitResult[name_task]["response"].ToString() == ""))
                        {
                            result.Add("error", "codeFalse");
                            result.Remove("response");
                        }
                        else
                        {
                            result = waitResult[name_task];
                        }
                        //Console.WriteLine(result);
                        waitResult.TryRemove(name_task, out result);
                        break;
                    }
                }
                return result;
            }
            catch
            {
                return null;
            }
            
        }*/


        public async Task<JObject> WallCreateComment(long owner_id, long post_id, long from_group, string message, long reply_to_comment)
        {
            string method = "wall.createComment";
            Dictionary<string, string> parames = new()
            {
                { "owner_id", owner_id.ToString() },
                { "post_id", post_id.ToString() },
                { "from_group", from_group.ToString() },
                { "message", message.ToString() },
                { "reply_to_comment", reply_to_comment.ToString() }
            };
            var result = await VkAPI(method, parames);

            return result;
        }

        public async Task<JObject?> VkAPI(string method, Dictionary<string, string> parames, long tryning = 0)
        {
            try
            {
                long min = -1;
                string? access_token = null;
                if (parames.ContainsKey("access_token"))
                {
                    access_token = parames["access_token"];
                }
                else
                {
                    foreach (var token in settings.a_tokens)
                    {
                        if (min == -1 || min > token.Value)
                        {
                            access_token = token.Key;
                            min = token.Value;
                        }
                    }
                }

                if (access_token == null)
                {
                    return null;
                }

                parames["access_token"] = access_token;
                parames["v"] = "5.199";
                if (!parames.ContainsKey("access_token"))
                {
                    lock (lock_tokens)
                    {
                        settings.a_tokens[access_token]++;
                    }
                }

                // ------------- ЗАПРОС

                string url = "https://api.vk.com/method/" + method;
                parames["access_token"] = access_token;
                var newUrl = new Uri(QueryHelpers.AddQueryString(url, parames));
                var result = await this.Get(newUrl.ToString());

                if (!parames.ContainsKey("access_token"))
                {
                    lock (lock_tokens)
                    {
                        settings.a_tokens[access_token]--;
                    }
                }
                Interlocked.Increment(ref AdminInfo.send_vkapi);

                if (result == null || result == "")
                {
                    return null;
                }

                JObject result_ok = JObject.Parse(result);
                if (result_ok["error"] != null && !parames.ContainsKey("access_token"))
                {
                    Interlocked.Increment(ref AdminInfo.errors);
                    //Console.WriteLine(result_ok["error"]);
                    addError((int)result_ok["error"]["error_code"], result_ok["error"]["error_msg"].ToString(), result_ok["error"].ToString(), tryning);
                    if (tryning != 1 && result_ok["error"]["error_code"].ToString() == "9")
                    {
                        Thread.Sleep(500);
                        VkAPI(method, parames, 1);
                    }
                }
                //Console.WriteLine(result_ok);
                return result_ok;
            }
            catch
            {
                return null;
            }
            

            // -------------

        }

        public async Task<JObject> VkAPIs(string method, Dictionary<string, string> parames, long tryning = 0)
        {
            long min = -1;
            string? access_token = null;
            if (parames.ContainsKey("access_token"))
            {
                access_token = parames["access_token"];
            }
            else
            {
                foreach (var token in settings.a_tokens)
                {
                    if (min == -1 || min > token.Value)
                    {
                        access_token = token.Key;
                        min = token.Value;
                    }
                }
            }

            if (access_token == null)
            {
                return null;
            }

            parames["access_token"] = access_token;
            parames["v"] = "5.150";
            if (!parames.ContainsKey("access_token"))
            {
                lock (lock_tokens)
                {
                    settings.a_tokens[access_token]++;
                }
            }
            
            // ------------- ЗАПРОС

            string url = "https://api.vk.com/method/" + method;
            var newUrl = new Uri(QueryHelpers.AddQueryString(url, parames));
            //var result = await Get(newUrl.ToString());
            var result = await this.Get(url + "?access_token=" + access_token, parames);

            if (!parames.ContainsKey("access_token"))
            {
                lock (lock_tokens)
                {
                    settings.a_tokens[access_token]--;
                }
            }
            Interlocked.Increment(ref AdminInfo.send_vkapi);

            if(result == null || result == "")
            {
                return null;
            }

            JObject result_ok = JObject.Parse(result);
            if (result_ok["error"] != null && !parames.ContainsKey("access_token"))
            {
                Interlocked.Increment(ref AdminInfo.errors);
                //Console.WriteLine(result_ok["error"]);
                addError((int)result_ok["error"]["error_code"], result_ok["error"]["error_msg"].ToString(), result_ok["error"].ToString(), tryning);
                if (tryning != 1 && result_ok["error"]["error_code"].ToString() == "9")
                {
                    Thread.Sleep(500);
                    VkAPI(method, parames, 1);
                }
            }
            //Console.WriteLine(result_ok);
            return result_ok;

            // -------------
            
        }

        public async Task<JObject> KickUser(long peerid, long userid)
        {
            //Dictionary<string, string> parames = new() { { "chat_id", (peerid - settings.PEERS_CHATID).ToString() }, { "member_id", userid.ToString() } };
            //string vkCode = "var a = API.messages.removeChatUser(" + JsonConvert.SerializeObject(parames) + "); return a;";
            //return await Vk.VkAPIs("execute", new Dictionary<string, string>()
            //{
                //{ "code", vkCode }
            //});

            Dictionary<string, string> parames = new() { { "chat_id", (peerid - settings.PEERS_CHATID).ToString() }, { "member_id", userid.ToString() } };
            return await this.VkAPI("messages.removeChatUser", parames);
        }

        public static async void DeleteMessage(long peerid, string messid)
        {
            //Dictionary<long, long> temp = new() { { peerid, long.Parse(messid) } };
            if (messagesForDelete.ContainsKey(peerid.ToString()))
            {
                messagesForDelete[peerid.ToString()] = messagesForDelete[peerid.ToString()] + "," + messid;
            }
            else
            {
                messagesForDelete[peerid.ToString()] = messid;
            }
            /*Dictionary<string, string> parames = new() { { "peer_id", peerid.ToString() }, { "cmids", messid }, { "delete_for_all", "1" } };
            string vkCode = "var a = API.messages.delete(" + JsonConvert.SerializeObject(parames) + "); return a;";
            await Vk.VkAPI("execute", new Dictionary<string, string>()
            {
                { "code", vkCode }
            });*/
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="member_ban">ID пользователя</param>
        /// <param name="dateunban">Дата разблокировки в unix seconds</param>
        /// <param name="comment">Комментарий</param>
        /// <param name="comment_visible">Видимость комментария (1 или 0)</param>
        public async void GroupBan(long member_ban, string comment = "", string comment_visible = "1", string dateunban = "")
        {
            //group_id
            Dictionary<string, string> parames = new() {
                { "group_id", settings.GROUP_ID.ToString() }, 
                { "owner_id", member_ban.ToString() },
                { "reason", "0" },
                { "comment", comment },
                { "comment_visible", comment_visible }
            };
            if (dateunban != "")
            {
                parames.Add("end_date", dateunban);
            }
            this.VkAPI("groups.ban", parames);
            return;
            //groups.ban
        }

        public UriBuilder? IsUrlValid(string url)
        {
            try
            {
                if (url.Contains("http"))
                {
                    url = url.Replace("https://", "");
                    url = url.Replace("http://", "");
                }

                if (url.Contains(' '))
                {
                    var words = url.Split(' ');
                    foreach (var item in words)
                    {
                        if (!item.Contains('.'))
                        {
                            continue;
                        }
                        try
                        {
                            UriBuilder build = new UriBuilder(item);
                            return build;
                        }
                        catch
                        {
                            continue;
                        }
                    }
                }
                else
                {
                    if (!url.Contains('.'))
                    {
                        return null;
                    }
                    var pos = url.IndexOf('.');
                    if (pos == url.Length)
                    {
                        return null;
                    }
                    UriBuilder builder = new UriBuilder(url);
                    return builder;
                }
                

                //string pattern = @"(?<Protocol>\w+):\/\/(?<Domain>[\w@][\w.:@]+)\/?[\w\.?=%&=\-@/$,]*";
                //string pattern = @"(http|https|ftp|)\://|[a-zA-Z0-9\-\.]+\.[a-zA-Z](:[a-zA-Z0-9]*)?/?([a-zA-Z0-9\-\._\?\,\'/\\\+&amp;%\$#\=~])*[^\.\,\)\(\s]";
                //Regex reg = new Regex(pattern, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                //bool result = reg.IsMatch(url);
                return null;
            }
            catch
            {
                return null;
            }
        }

        public async void GroupUnBan(long member_ban)
        {
            //group_id
            Dictionary<string, string> parames = new() {
                { "group_id", settings.GROUP_ID.ToString() },
                { "owner_id", member_ban.ToString() }
            };
            this.VkAPI("groups.unban", parames);
            return;
            //groups.ban
        }

        public async void Execute()
        {
            string vkCode = "var a = API.messages.send(); return a;";
            await this.VkAPI("execute", new Dictionary<string, string>()
            {
                { "code", vkCode }
            });
        }

        public async Task<string> Get(string url, Dictionary<string, string>? data = null)
        {
            //HttpClient client = new HttpClient();
            
            //var r = new HttpContent(url);
            Interlocked.Increment(ref AdminInfo.send_get);
            
            //X-Owner: long
            if (data != null && data.Count > 0)
            {
                // Добавляем параметры к URL
                var query = string.Join("&", data.Select(kvp => $"{kvp.Key}={Uri.EscapeDataString(kvp.Value)}"));
                if (url.Contains("?"))
                    url += "&" + query;
                else
                    url += "?" + query;
            }

            if (url.Length > 200 && data != null)
            {
                var datas = new FormUrlEncodedContent(data);
                
                HttpResponseMessage result;
                try
                {
                    //var ss = new FormUrlEncodedContent()
                    result = await client.PostAsync(url, datas);
                }
                catch (System.Net.Http.HttpRequestException ex)
                {
                    Console.WriteLine("Ошибка исключение GET " + ex.Message + "    "  + url);
                    result = null;
                }
                if (result != null)
                {
                    return await result.Content.ReadAsStringAsync();
                }
                else
                {
                    return "";
                }
            }
            else
            {
                string result;
                try
                {
                    result = await client.GetStringAsync(url);

                }
                catch (Exception ex)
                {
                    Console.WriteLine("ERROR GET " + ex.Message + "   -  " + url);
                    result = null;
                }
                return result;
            }
            
        }

        public async Task<Dictionary<string, string>>? PostPhotoForPeer(long peerid, string file_path, string filename)
        {

            string method = "photos.getMessagesUploadServer";
            Dictionary<string, string> parames = new()
            {
                { "peer_id", peerid.ToString() }
            };
            var res = await this.VkAPI(method, parames);
            FileStream fs = File.OpenRead(file_path);
            if (res["response"] == null || res["response"].ToString() == "")
            {
                Console.WriteLine("getmessagesuploadserver error");
                return null;
            }
            //Console.WriteLine(res);
            string url = res["response"]["upload_url"].ToString();
            string album_id = res["response"]["album_id"].ToString();
            string user_id = res["response"]["user_id"].ToString();
            string group_id = res["response"]["group_id"].ToString();

            Dictionary<string, string> data = new()
            {
                { "album_id", album_id },
                //{ "user_id", user_id },
                { "upload_url", url }
            };
            using var client = new HttpClient();
            var datas = new FormUrlEncodedContent(data);
            HttpResponseMessage result;
            HttpContent fileStreamContent = new StreamContent(fs);
            try
            {
                //var ss = new FormUrlEncodedContent()
                using (var formData = new MultipartFormDataContent())
                {
                    //formData.Add(datas);
                    formData.Add(fileStreamContent, "photo", filename);
                    result = await client.PostAsync(url, formData);
                }

            }
            catch
            {
                Console.WriteLine("Ошибка исключение GET " + url);
                result = null;
            }

            if (result == null)
            {
                return null;
            }
            var result_two = await result.Content.ReadAsStringAsync();

            JObject sdsds = JObject.Parse(result_two);
            if (sdsds["photo"] == null)
            {
                return null;
            }

            var server = sdsds["server"].ToString();
            var hash = sdsds["hash"].ToString();
            var photo = sdsds["photo"].ToString();

            method = "photos.saveMessagesPhoto";
            
            parames = new()
            {
                { "photo", photo },
                { "server", server },
                { "hash", hash }
            };
            var result_upload = await this.VkAPI(method, parames);
            if (result_upload == null || result_upload["response"] == null || result_upload["error"] != null)
            {
                Console.WriteLine("result upload nyull");
                return null;
            }
            //Console.WriteLine(result_upload);
            Dictionary<string, string> result_res = new()
            {
                { "album_id", result_upload["response"][0]["album_id"].ToString() },
                { "id", result_upload["response"][0]["id"].ToString() },
                { "owner_id", result_upload["response"][0]["owner_id"].ToString() },
                { "access_key", result_upload["response"][0]["access_key"].ToString() },
            };
            return result_res;
        }

        public static long EmojiCount(string text)
        {
            //Regex rgx = new Regex(@"(\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff])");
            Regex rgx = new Regex(@"\p{Cs}");
            return rgx.Matches(text).Count;

            /*long fancyCount(string str)
            {
                var sd = System.Text.RegularExpressions.Regex.Split(str, @"[\ufe00-\ufe0f]");
                var s = string.Join("", sd);
                return sd.Count();
            }
            //var output = input.replace(/ ([\uE000-\uF8FF] |\uD83C[\uDC00-\uDFFF] |\uD83D[\uDC00-\uDFFF]|[\u2694-\u2697] |\uD83E[\uDD10-\uDD5D])/ g, "");
            var output = Regex.Replace(text, @"(\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff])", "");
            return (fancyCount(text) - fancyCount(output));*/

        }

        public static string EmojiClear(string text)
        {
            //Regex rgx = new Regex(@"(\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff])");
            return Regex.Replace(text, @"\p{Cs}", "");

            /*long fancyCount(string str)
            {
                var sd = System.Text.RegularExpressions.Regex.Split(str, @"[\ufe00-\ufe0f]");
                var s = string.Join("", sd);
                return sd.Count();
            }
            //var output = input.replace(/ ([\uE000-\uF8FF] |\uD83C[\uDC00-\uDFFF] |\uD83D[\uDC00-\uDFFF]|[\u2694-\u2697] |\uD83E[\uDD10-\uDD5D])/ g, "");
            var output = Regex.Replace(text, @"(\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff])", "");
            return (fancyCount(text) - fancyCount(output));*/

        }


        public static async void addError(long code, string message, string data = "", long tryning = 0)
        {
            long seconds = DateTime.Now.Ticks / 10 / 1000000;
            /*DateTime secondss = DateTime.UtcNow;
            long seco = secondss.Ticks / 10 / 1000000;*/
            if(code == 9 && tryning != 1)
            {
                return;
            }
            if (code == 935)
            {
                return;
            }
            string path = "errors/[CODE" + code +"] "+ seconds.ToString() + ".txt";

            string originalText = "Дата ошибки — " + seconds.ToString() + "\n" + 
                "\nКод ошибки: " + code + "\nПовторный вызов? "+ tryning + "\n Сообщение: " + message + "\nDATA: " + data;
            // запись строки
            try
            {
                File.WriteAllTextAsync(path, originalText);
            }
            catch
            {

            }
        }

    }

    class usersNameVk
    {
        public long id;
        public string first_name;
        public string last_name;
        public string sex;
        public string online;
    }

    class m_actionc
    {
        public string type { get; set; }

        public string TYPE_CHAT_PHOTO_UPDATE = "chat_photo_update";
        public string TYPE_CHAT_PHOTO_REMOVE = "chat_photo_remove";
        public string TYPE_CHAT_CREATE = "chat_create";
        public string TYPE_CHAT_TITLE_UPDATE = "chat_title_update";
        public string TYPE_CHAT_INVITE_USER = "chat_invite_user";
        public string TYPE_CHAT_KICK_USER = "chat_kick_user";
        public string TYPE_CHAT_PIN_MESSAGE = "chat_pin_message";
        public string TYPE_CHAT_UNPIN_MESSAGE = "chat_unpin_message";
        public string TYPE_CHAT_INVITE_BY_LINK = "chat_invite_user_by_link";

        public long member_id { get; set; }
        public string text { get; set; }
        public string email { get; set; }


    }

    class m_forward
    {
        public long peer_id { get; set; }
        public long is_reply { get; set; }
        public long[] conversation_message_ids = new long[1];

        public m_forward(long peer_ids, long is_replys, long conv_mes_ids)
        {
            peer_id = peer_ids;
            is_reply = is_replys;
            conversation_message_ids[0] = conv_mes_ids;
        }
    }

    class keyboard
    {
        public bool one_time = false;
        public bool inline = true;
        public List<List<button>> buttons;
    }

    class button
    {
        public action_button action;
        public string color = "secondary";
    }

    class action_button
    {
        public string type = "text";
        public string label;
        public string payload;
    }
}
