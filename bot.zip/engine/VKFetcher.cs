﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

namespace GrandManager.engine
{
    public class VKFetcher
    {
        // HttpClient должен быть статическим и переиспользоваться во всем приложении.
        private static readonly HttpClient httpClient = new HttpClient();

        /// <summary>
        /// Получает дату регистрации пользователя VK по его ID, выполняя все операции в одном методе.
        /// </summary>
        /// <param name="userId">ID пользователя VK.</param>
        /// <returns>Дата регистрации в формате Unix time или null, если получить дату не удалось.</returns>
        public static async Task<long?> GetDateCreatedAsync(long userId)
        {
            string restoreSessionId = null;
            long? unauthId = null;

            // --- Этап 1: Вызов restore.getSettings для получения сессии ---
            try
            {
                var getSettingsParams = new Dictionary<string, string>
            {
                { "type", "restore" },
                { "vkui", "1" },
                { "platform", "vkcom" },
                { "access_token", "" },
                { "v", "5.83" }
            };

                using var settingsContent = new FormUrlEncodedContent(getSettingsParams);
                using var settingsResponseMessage = await httpClient.PostAsync("https://api.vk.com/method/restore.getSettings", settingsContent);

                if (settingsResponseMessage.IsSuccessStatusCode)
                {
                    var settingsJson = await settingsResponseMessage.Content.ReadAsStringAsync();

                    // Используем JsonNode для парсинга JSON без строгих классов
                    JsonNode settingsNode = JsonNode.Parse(settingsJson);

                    // Безопасно извлекаем данные с помощью оператора '?'
                    restoreSessionId = settingsNode?["response"]?["restore_session_id"]?.GetValue<string>();
                    unauthId = settingsNode?["response"]?["unauth_id"]?.GetValue<long?>();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при получении настроек восстановления: {ex.Message}");
                // Продолжаем выполнение, так как эти параметры не являются абсолютно обязательными
            }

            // --- Этап 2: Вызов restore.init для получения данных пользователя ---
            try
            {
                var restoreInitParams = new Dictionary<string, string>
            {
                { "uid", userId.ToString() },
                { "access_token", "" },
                { "v", "5.223" }
            };

                if (!string.IsNullOrEmpty(restoreSessionId))
                {
                    restoreInitParams.Add("restore_session_id", restoreSessionId);
                }
                if (unauthId.HasValue)
                {
                    restoreInitParams.Add("unauth_id", unauthId.Value.ToString());
                }

                using var initContent = new FormUrlEncodedContent(restoreInitParams);
                using var initResponseMessage = await httpClient.PostAsync("https://api.vk.com/method/restore.init", initContent);

                if (initResponseMessage.IsSuccessStatusCode)
                {
                    var initJson = await initResponseMessage.Content.ReadAsStringAsync();
                    JsonNode initNode = JsonNode.Parse(initJson);

                    // Ответ restore.init - это массив. Проверяем его наличие и структуру.
                    JsonArray responseArray = initNode?["response"] as JsonArray;

                    // Нам нужен второй элемент массива (индекс 1)
                    if (responseArray != null && responseArray.Count > 1)
                    {
                        // Безопасно извлекаем и возвращаем 'date_created'
                        return responseArray[1]?["user"]?["date_created"]?.GetValue<long?>();
                    }

                    // Проверяем наличие ошибки от API
                    var apiError = initNode?["error"]?["error_msg"]?.GetValue<string>();
                    if (apiError != null)
                    {
                        Console.WriteLine($"Ошибка API VK: {apiError}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при получении данных пользователя: {ex.Message}");
            }

            // Возвращаем null, если ничего не найдено или произошла ошибка
            return null;
        }
    }
}
