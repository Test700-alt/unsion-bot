﻿using MySql.Data.MySqlClient;
using System;
using System.Buffers;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.properties
{
    internal class admins
    {
        public static bool load(Database dbh)
        {
            var res = dbh.loadAdmins();
            if (res != null)
            {
                settings.OWNER_IDS = res;
                return true;
            }
            return false;
        }
    }
}
