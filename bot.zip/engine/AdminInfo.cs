﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine
{
    internal class AdminInfo
    {
        public static long requests = 0;
        public static long clear_updates = 0;
        public static long send_get = 0;
        public static long send_vkapi = 0;
        public static long send_vksendmessage = 0;
        public static long errors = 0;
        public static long threads = 0;

        public static object lock_avg = new();

        public static object lock_avgCmd = new();

        public static object lock_pingaverage = new();

        public static List<decimal> average_request = new List<decimal>(20);
        public static List<decimal> average_command = new List<decimal>(20);

        public static ConcurrentDictionary<long, long> request_per_seconds = new();
        public static long rps_max = 0;
        public static string rps_max_date = "не определено";

        public static List<Dictionary<string, string>> errors_list = new();
        //public static ConcurrentList<Dictionary<string, string>> errors_list = new();

        public static List<Dictionary<long, long>> requests_ping = new();

        private static Process proc = Process.GetCurrentProcess();

        public static string ram_count = "";
        
        public static string all_ram = "";

        public static string last_string = "";

        public static bool is_windows = false;
        public static string target_cpu = "";


        private static int maxErrorCount = 1000;

        public static void addRequestPing(long time, long timeout)
        {
            /*lock (lock_pingaverage)
            {
                if (requests_ping.Count >= 200)
                {
                    var target_time = DateTimeOffset.Now.ToUnixTimeSeconds();
                    foreach (var targetin in requests_ping)
                    {
                        foreach (KeyValuePair<long, long> item in targetin)
                        {
                            if (item.Key < target_time - 120)
                            {
                                requests_ping.Remove(targetin);
                                break;
                            }
                            //if (item.Key < target_time - 120)
                            //{
                            //continue;
                            //}
                            //requests_pingtext.Add(item.Value);
                        }
                    }
                }
                requests_ping.Add(new Dictionary<long, long>() { { time, timeout } });
            }
            */
        }

        public static void addRequest(bool is_cmd)
        {
            if (is_cmd)
            {

            }
            else
            {
                //Interlocked.Increment(ref AdminInfo.requests);
            }
        }

        public static void addAvergCommand(decimal interval)
        {

            lock (lock_avgCmd)
            {
                if (average_command.Count >= 200)
                {
                    //average_command.RemoveAt(0);
                }
                //average_command.Add(interval);
            }
        }

        public static void addAvergRequest(decimal interval)
        {
            lock (lock_avg)
            {
                if (average_request.Count >= 200)
                {
                    //average_request.RemoveAt(0);
                }
                //average_request.Add(interval);
            }
        }

        public static void ConsoleDeb()
        {
            
            //Console.Clear();

            //a_tokens
            while (true)
            {
                /*ConsoleKeyInfo key = Console.ReadKey();
                if (key.Key == ConsoleKey.Q)
                {
                    Console.Clear();
                    Console.WriteLine("выход");
                    return;
                }*/
                //Console.SetCursorPosition(0, 0);
                //Console.Write("0. STATS BOT\n\n");
                //Console.WriteLine($"2. REQUESTS:\t\tCLEAR UPDATES:\n");
                //Console.WriteLine($"4. SEND GET:\t\tSEND VKAPI:\t\tSEND VKMSend:\n");
                //Console.WriteLine($"6. Threads:\n");
                //Console.WriteLine($"8. Errors:\n");
                //Console.WriteLine($"10. Tokens:\n");
                //Console.WriteLine($"\n13. Average requests offset: \tAverage commands offset:\n");

                long req_per_s = 0;

                if (request_per_seconds.Count() >= 1)
                {
                    var target_time = DateTimeOffset.Now.ToUnixTimeSeconds();
                    foreach (var item in request_per_seconds)
                    {
                        if (item.Key < target_time - 1)
                        {
                            request_per_seconds.TryRemove(item);
                            continue;
                        }
                        req_per_s += item.Value;
                    }
                }

                List<long> requests_pingtext = new();

                if (requests_ping.Count() >= 1)
                {
                    var target_time = DateTimeOffset.Now.ToUnixTimeSeconds();
                    var datas = requests_ping;
                    
                    try
                    {
                        foreach (var targetin in datas)
                        {
                            foreach (KeyValuePair<long, long> item in targetin)
                            {
                                //if (item.Key < target_time - 120)
                                //{
                                //continue;
                                //}
                                requests_pingtext.Add(item.Value);
                            }
                        }
                    }
                    catch
                    {

                    }
                    
                }

                if (rps_max < req_per_s)
                {
                    rps_max = req_per_s;
                    rps_max_date = DateTimeOffset.Now.ToString("G");
                }

                //GetRam();

                //Console.SetCursorPosition(0, 3);
                //Console.Write(requests + "\t\t\t" + clear_updates);
                
                
                
                //Console.SetCursorPosition(0, 5);
                //Console.Write(send_get + "\t\t\t" + send_vkapi + "\t\t\t\t" + send_vksendmessage);

                //Console.SetCursorPosition(0, 7);
                //Console.Write(threads);
 
                //Console.SetCursorPosition(0, 9);
                //Console.Write(errors);

                //Console.SetCursorPosition(0, 11);
                string toknes = "";
                foreach (var token in settings.a_tokens)
                {
                    toknes = toknes + token.Value + " | ";
                }
                //Console.Write(toknes + "\n");

                //Console.SetCursorPosition(0, 14);
                if(average_request != null && average_request.Count >= 1)
                {
                    //Console.Write(Math.Round(average_request.Average(), 5).ToString() + " s.        ");
                }
                else
                {
                    //Console.Write("0" + " s.                  ");
                }

                //Console.SetCursorPosition(0, 17);
                if (average_command != null && average_command.Count >= 1)
                {
                    //Console.Write(Math.Round(average_command.Average(), 5).ToString() + " s.                              \n");
                }
                else
                {
                    //Console.Write("0" + " s.                                   \n");
                }
                //Console.WriteLine("RPS: " + req_per_s);
                //Console.WriteLine("RPS MAX: " + rps_max);
                //Console.WriteLine("RPS MAX DATE: " + rps_max_date);
                string req_ping_text = "0";
                if (requests_pingtext.Count >= 1)
                {
                    req_ping_text = requests_pingtext.Average().ToString();
                }
                //Console.WriteLine("Average timeout requests: " + req_ping_text + " s.");
                //Console.Write("RAM: " + ram_count + " MB\n");
                //onsole.Write(all_ram + "\n");
                //Console.WriteLine(last_string);
                if (!is_windows)
                {
                    //var target_CPPU = getCPU();
                    //if (target_CPPU == "")
                    //{
                        //is_windows = true;
                    //}
                    //else
                    //{

                    //}
                }
                
                Thread.Sleep(2000);
                //Console.Clear();
                //Console.Clear();
            }
        }

        public static void ErrorAddCommand(Exception ex, vk Vk)
        {
            AddErrorList("Ошибка обработки команды в COMMANDS", "Дата: " + DateTimeOffset.Now.ToString("G") + "<br>" +
                    "Vk TEXT: " + Vk.m_text + " <br>Error: " + ex.Message + "<br>HelpLink:" + ex.HelpLink + "" +
                    "<br>StackTrace" + ex.StackTrace + "<br>Source: " + ex.Source + "<br>InnerException: " + ex.InnerException + "<br>" +
                    "Data: " + ex.Data);
            return;
        }

        public static void AddErrorList(string name, string info)
        {
            Console.WriteLine("[ERROR ] " + name + " = " + info);

            errors_list.Add(new Dictionary<string, string> { { "name", name }, { "info", info } });

            // Очистка списка, если он превысил максимальный размер
            if (errors_list.Count > maxErrorCount)
            {
                errors_list.RemoveRange(0, errors_list.Count - maxErrorCount);
            }
        }

        private static void GetRam()
        {
            proc = Process.GetCurrentProcess();
            ram_count = ((proc.WorkingSet64 / (1024 * 1024))/2).ToString();
            try
            {
                all_ram = Bash("free -h");
            }
            catch
            {

            }
        }


        public static string Bash(string cmd)
        {
            var escapedArgs = cmd.Replace("\"", "\\\"");

            var process = new Process()
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "/bin/bash",
                    Arguments = $"-c \"{escapedArgs}\"",
                    RedirectStandardOutput = true,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                }
            };
            process.Start();
            string result = process.StandardOutput.ReadToEnd();
            process.WaitForExit();
            return result;
        }

        public static DateTime? _previousCpuStartTime = null;
        public static TimeSpan? _previousTotalProcessorTime = null;

        public static string getCPU()
        {
            //proc = Process.GetCurrentProcess();
            //ram_count = ((proc.WorkingSet64 / (1024 * 1024)) / 2).ToString();
            string proc = "";
            try
            {
                proc = Bash("cat /proc/loadavg");
            }
            catch
            {

            }

            if (proc != "")
            {
                var loads = proc.Split(" ");
                if (loads != null & loads.Length >= 1)
                {
                    target_cpu = (double.Parse(loads[0]) * 100).ToString();
                    return target_cpu;
                }
            }
            return proc;
        }

        public static string getRamString()
        {
            var process = Process.GetCurrentProcess();
            var workingSet64 = process.WorkingSet64;
            var privateMemorySize64 = process.PrivateMemorySize64;
            var virtualMemorySize64 = process.VirtualMemorySize64;
            return "";
        }
    }
}
