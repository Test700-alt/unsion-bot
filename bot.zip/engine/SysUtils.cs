﻿using Org.BouncyCastle.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine
{
    internal class SysUtils
    {
        public static async Task<T?> CallCmd<T>(string myclass, string mymethod, Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post = false, string ip = "127.0.0.1")
        {
            // Get a type from the string
            Type? type = Type.GetType(myclass);
            if (type == null)
            {
                Console.WriteLine($"Ошибка: Тип '{myclass}' не найден.");
                return default(T);
            }


            // Create an instance of that type
            object? obj = null;
            try
            {
                obj = Activator.CreateInstance(type);
                if (obj == null)
                {
                    Console.WriteLine($"Ошибка: Не удалось создать экземпляр типа '{myclass}'.");
                    return default(T);
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: Не удалось создать экземпляр типа '{myclass}': {ex.Message}");
                return default(T);
            }



            // Retrieve the method you are looking for
            MethodInfo? methodInfo = type.GetMethod(mymethod);
            if (methodInfo == null)
            {
                Console.WriteLine($"Ошибка: Метод '{mymethod}' не найден в типе '{myclass}'.");
                return default(T);
            }

            ParameterInfo[] parameters = methodInfo.GetParameters();

            if (parameters.Length != 6)
            {
                Console.WriteLine($"Ошибка: Ожидается {parameters.Length} параметров, передано 6.");
                return default(T); // Или выбросьте исключение
            }


            object[] paramsArray = new object[] { cache, Db, args, Cookies, is_post, ip };
            for (int i = 0; i < parameters.Length; i++)
            {
                if (paramsArray[i] != null && !parameters[i].ParameterType.IsInstanceOfType(paramsArray[i]))
                {
                    Console.WriteLine($"Ошибка: Тип параметра {i} не соответствует. Ожидается {parameters[i].ParameterType}, передано {paramsArray[i].GetType()}");
                    return default(T); // Или выбросьте исключение
                }
            }

            try
            {
                var taskResult = methodInfo.Invoke(obj, paramsArray);

                if (taskResult is Task<T> awaitedTask)
                {
                    return await awaitedTask;
                }

                if (taskResult is Task)
                {
                    await (Task)taskResult;
                    return default(T);
                }

                if (taskResult is T result)
                {
                    return result;
                }

                return default(T);


            }
            catch (TargetInvocationException ex)
            {
                Console.WriteLine($"Ошибка при вызове метода: {ex.InnerException}");
                return default(T);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Непредвиденная ошибка при вызове метода: {ex}");
                return default(T);
            }
        }

        private static readonly byte[] EncryptionKey = Encoding.UTF8.GetBytes("m8rnzrodXGCO7gve9RrKjqTBdUm3FGBs"); // 32 байта

      

        public static string EncryptString(string plainText)
        {
            if (string.IsNullOrEmpty(plainText)) return null;

            byte[] nonce = new byte[12];
            RandomNumberGenerator.Fill(nonce);

            byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
            byte[] cipherBytes = new byte[plainBytes.Length];
            byte[] tag = new byte[16]; // Tag size must be 16 bytes for AesGcm


            using (AesGcm aesGcm = new AesGcm(EncryptionKey))
            {
                aesGcm.Encrypt(nonce, plainBytes, cipherBytes, tag); // Correct Encrypt with tag
            }

            // Concatenate nonce, cipher text, and tag for storage
            byte[] result = new byte[nonce.Length + cipherBytes.Length + tag.Length];
            Buffer.BlockCopy(nonce, 0, result, 0, nonce.Length);
            Buffer.BlockCopy(cipherBytes, 0, result, nonce.Length, cipherBytes.Length);
            Buffer.BlockCopy(tag, 0, result, nonce.Length + cipherBytes.Length, tag.Length);


            return Base64UrlEncode(result);
        }


        public static string DecryptString(string encryptedText)
        {
            if (string.IsNullOrEmpty(encryptedText)) return null;
            try
            {
                byte[] encryptedBytes = Base64UrlDecode(encryptedText);

                if (encryptedBytes.Length < 12 + 16)
                {
                    Console.WriteLine($"Ошибка:  Длина зашифрованной строки меньше минимальной для дешифровки.");
                    return null;
                }

                byte[] nonce = new byte[12];
                Buffer.BlockCopy(encryptedBytes, 0, nonce, 0, nonce.Length);

                byte[] tag = new byte[16]; // tag size is 16 bytes
                Buffer.BlockCopy(encryptedBytes, encryptedBytes.Length - tag.Length, tag, 0, tag.Length);


                byte[] cipherBytes = new byte[encryptedBytes.Length - nonce.Length - tag.Length];
                Buffer.BlockCopy(encryptedBytes, nonce.Length, cipherBytes, 0, cipherBytes.Length);

                byte[] plainBytes = new byte[cipherBytes.Length];

                using (AesGcm aesGcm = new AesGcm(EncryptionKey))
                {
                    aesGcm.Decrypt(nonce, cipherBytes, tag, plainBytes); // Correct Decrypt with tag
                }

                return Encoding.UTF8.GetString(plainBytes);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при дешифровке:{ex.Message}");
                return null;
            }
        }


        private static string Base64UrlEncode(byte[] input)
        {
            string base64 = Convert.ToBase64String(input);
            base64 = base64.Replace('+', '-').Replace('/', '_').Replace("=", "");
            return base64;
        }

        // Base64Url Decoding
        private static byte[] Base64UrlDecode(string input)
        {
            string base64 = input.Replace('-', '+').Replace('_', '/');
            switch (base64.Length % 4)
            {
                case 2:
                    base64 += "==";
                    break;
                case 3:
                    base64 += "=";
                    break;
            }
            return Convert.FromBase64String(base64);
        }
    }
}
