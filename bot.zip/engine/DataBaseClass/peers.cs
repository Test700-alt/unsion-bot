﻿using MySqlX.XDevAPI.Relational;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.DataBaseClass
{
    public class peers
    {
        public bool? active { get; set; }
        public int? peer_id { get; set; }
        public int? owner { get; set; }
        public int? inviter { get; set; }
        public int? silence { get; set; }
        public int? antiflood { get; set; }
        public int? group { get; set; }
        public int? in_pool { get; set; }
        public int? protect { get; set; }
        public int? set_kickexit { get; set; }
        public int? set_kickexitrole { get; set; }
        public int? set_kickinviter { get; set; }
        public int? set_inviterrole { get; set; }
        public int? set_kickphotos { get; set; }
        public int? set_kickposts { get; set; }
        public int? set_kicklinks { get; set; }
        public int? set_mentions { get; set; }
        public int? set_games { get; set; }
        public int? set_systemhelp { get; set; }
        public string title { get; set; } = "";
        public string welcome_text { get; set; } = "";

        public long current_members { get; set; }
    }

}
