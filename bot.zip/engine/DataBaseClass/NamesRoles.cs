﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.DataBaseClass
{
    internal class NamesRoles
    {
        public long peer_id { get; set; }
        public int priority { get; set; }
        public string name { get; set; } = "";
        public string date_create { get; set; } = "";
        public long admin { get; set; }
    }
}
