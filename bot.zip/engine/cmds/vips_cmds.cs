﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace GrandManager.engine.cmds
{
    class vips_cmds
    {
        public vk Vk;
        public settings settings;
        public Database db;
        private AntiFlood antiflood;
        private check_for_cmd cmdChecker;

        public vips_cmds(vk vks, Database dbs, settings set)
        {
            Vk = vks;
            settings = set;
            db = dbs;
            antiflood = new(vks);
            cmdChecker = new(db, vks);
        }

        public async void command_emoji()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 0, "emoji"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "emoji", 5))
                {
                    return;
                }

                if (!db.UserIsVip(Vk.m_from_id))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == "" || args[0] == null)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["emoji"]);
                    return;
                }



                if (vk.EmojiCount(args[0]) >= 1)
                {
                    //var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                }
                else
                {
                    Vk.MessagesSend("Вставьте в сообщение одно или более эмодзи, которое вы хотите установить себе в ник.");
                    return;
                }

                string AdminNick = "Undefined";

                if (UserInfo["nick"] != "")
                {
                    UserInfo["nick"] = vk.EmojiClear(UserInfo["nick"]);
                    if (Vk.m_from_id < 0)
                    {
                        AdminNick = "[club" + Vk.m_from_id.ToString().Substring(1) + "|" + UserInfo["nick"] + "]";
                    }
                    else
                    {
                        AdminNick = "[id" + Vk.m_from_id + "|" + UserInfo["nick"] + "]";
                    }
                }
                else
                {
                    if (Vk.m_from_id < 0)
                    {
                        AdminNick = "[club" + Vk.m_from_id.ToString().Substring(1) + "|Сообщество]";
                    }
                    else
                    {
                        AdminNick = await Vk.GetUrlName(Vk.m_from_id);
                    }
                }

                string text;
                if (UserInfo["nick"] == "")
                {
                    text = AdminNick + " установил себе в никнейм эмодзи.<br><br>" +
                        "Новый никнейм: " + args[0];
                    db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_SETNICK, Vk.m_from_id, Vk.m_from_id, "установил никнейм", args[0]);
                }
                else
                {
                    
                    text = AdminNick + " установил себе в никнейм эмодзи.<br><br>" +
                        UserInfo["nick"] + " >> " + args[0] + " " + UserInfo["nick"];
                    db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_SETNICK, Vk.m_from_id, Vk.m_from_id, "установил никнейм", args[0] + UserInfo["nick"], UserInfo["nick"]);
                }

                db.peersMemberSetNickName(Vk.m_peer_id, Vk.m_from_id, args[0] + " " + UserInfo["nick"]);

                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }


        public async void command_enick()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "enick"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "enick", 5))
                {
                    return;
                }

                if (!db.UserIsVip(Vk.m_from_id))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });
                if (args[0] == "" || args[0] == null || args[1] == "" || args[1] == null)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["enick"]);
                    return;
                }

                Dictionary<string, string>? TargetUser = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]));

                if (TargetUser == null)
                {
                    Vk.MessagesSend("Пользователь не найден в базе данных.");
                    return;
                }


                if (vk.EmojiCount(args[1]) <= 0)
                {
                    Vk.MessagesSend("Необходимо указать эмодзи для пользователя.");
                    return;
                }

                string AdminNick = "Undefined";

                if (UserInfo["nick"] != "")
                {
                    if (Vk.m_from_id < 0)
                    {
                        AdminNick = "[club" + Vk.m_from_id.ToString().Substring(1) + "|" + UserInfo["nick"] + "]";
                    }
                    else
                    {
                        AdminNick = "[id" + Vk.m_from_id + "|" + UserInfo["nick"] + "]";
                    }
                }
                else
                {
                    if (Vk.m_from_id < 0)
                    {
                        AdminNick = "[club" + Vk.m_from_id.ToString().Substring(1) + "|Сообщество]";
                    }
                    else
                    {
                        AdminNick = await Vk.GetUrlName(Vk.m_from_id);
                    }
                }

                string text;
                if (TargetUser["nick"] == "")
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        text = AdminNick + " установил эмодзи в никнейм [club" + args[0].Substring(1) + "|сообществу].<br><br>" +
                            "Новый никнейм: " + args[1];
                    }
                    else
                    {
                        text = AdminNick + " установил эмодзи в никнейм [id" + args[0] + "|пользователю].<br><br>" +
                            "Новый никнейм: " + args[1];
                    }
                    db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_SETNICK, Vk.m_from_id, long.Parse(args[0]), "установил никнейм", args[1]);
                }
                else
                {
                    TargetUser["nick"] = vk.EmojiClear(TargetUser["nick"]);
                    if (long.Parse(args[0]) < 0)
                    {
                        text = AdminNick + " добавил эмодзи в никнейм [club" + args[0].Substring(1) + "|сообществу].<br><br>" +
                            TargetUser["nick"] + " >> " + args[1] + " " + TargetUser["nick"];
                    }
                    else
                    {
                        text = AdminNick + " добавил эмодзи в никнейм [id" + args[0] + "|пользователю].<br><br>" +
                            TargetUser["nick"] + " >> " + args[1] + " " + TargetUser["nick"];
                    }
                    db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_SETNICK, Vk.m_from_id, long.Parse(args[0]), "установил никнейм", args[1], TargetUser["nick"]);
                }

                db.peersMemberSetNickName(Vk.m_peer_id, long.Parse(args[0]), args[1] + " " + TargetUser["nick"]);
                
                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }
    }
}
