using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading.Tasks;
using GrandManager.engine.xenforo;

namespace GrandManager.engine.cmds
{
    internal class ForumCmds
    {
        private static readonly ConcurrentDictionary<long, ForumSession> _sessions = new();
        private static long _lastCmid = 0;

        private class ForumSession
        {
            public string Step { get; set; } = "";
            public Dictionary<string, string> Data { get; set; } = new();
            public long ExpiresAt { get; set; }
        }

        private static long NowMs() => DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

        private static ForumSession GetSession(long userId)
        {
            if (_sessions.TryGetValue(userId, out var s) && s.ExpiresAt > NowMs())
                return s;
            _sessions.TryRemove(userId, out _);
            return null;
        }

        private static void SetSession(long userId, string step, Dictionary<string, string> data)
        {
            _sessions[userId] = new ForumSession
            {
                Step = step,
                Data = data,
                ExpiresAt = NowMs() + 300_000
            };
        }

        public static bool HasActiveSession(long userId) => GetSession(userId) != null;

        private static XenForoDbClient CreateDbClient(Dictionary<string, string> conn)
        {
            string host = conn["db_host"];
            int port = int.Parse(conn["db_port"]);
            string user = conn["db_user"];
            string pass = conn["db_pass"];
            string dbName = conn["db_name"];
            string prefix = conn.ContainsKey("table_prefix") ? conn["table_prefix"] : "xf_";
            return new XenForoDbClient(host, port, user, pass, dbName, prefix);
        }

        public static async Task<bool> HandleForumSetup(vk Vk, Database db, long peerId, long userId, string text)
        {
            var session = GetSession(userId);
            if (session == null) return false;

            if (Vk.m_conversation_message_id != 0 && Vk.m_conversation_message_id == _lastCmid)
                return true;
            _lastCmid = Vk.m_conversation_message_id;

            var data = session.Data;

            switch (session.Step)
            {
                case "enter_host":
                    {
                        text = text.Trim();
                        if (text.Length < 3)
                        {
                            Vk.MessagesSend("⚠️ Введите хост БД (например localhost):", 0, peerId);
                            return true;
                        }
                        data["db_host"] = text;
                        SetSession(userId, "enter_port", data);
                        Vk.MessagesSend("✅ Хост принят.\n\n🔌 Введите порт MySQL (по умолчанию 3306):", 0, peerId);
                        return true;
                    }

                case "enter_port":
                    {
                        text = text.Trim();
                        if (string.IsNullOrEmpty(text)) text = "3306";
                        if (!int.TryParse(text, out int port) || port < 1 || port > 65535)
                        {
                            Vk.MessagesSend("⚠️ Некорректный порт. Введите число от 1 до 65535:", 0, peerId);
                            return true;
                        }
                        data["db_port"] = port.ToString();
                        SetSession(userId, "enter_dbname", data);
                        Vk.MessagesSend("✅ Порт принят.\n\n📂 Введите имя базы данных XenForo:", 0, peerId);
                        return true;
                    }

                case "enter_dbname":
                    {
                        text = text.Trim();
                        if (text.Length < 1)
                        {
                            Vk.MessagesSend("⚠️ Введите имя базы данных:", 0, peerId);
                            return true;
                        }
                        data["db_name"] = text;
                        SetSession(userId, "enter_user", data);
                        Vk.MessagesSend("✅ БД принята.\n\n👤 Введите пользователя MySQL:", 0, peerId);
                        return true;
                    }

                case "enter_user":
                    {
                        text = text.Trim();
                        if (text.Length < 1)
                        {
                            Vk.MessagesSend("⚠️ Введите пользователя:", 0, peerId);
                            return true;
                        }
                        data["db_user"] = text;
                        SetSession(userId, "enter_pass", data);
                        Vk.MessagesSend("✅ Пользователь принят.\n\n🔑 Введите пароль MySQL:", 0, peerId);
                        return true;
                    }

                case "enter_pass":
                    {
                        data["db_pass"] = text;
                        SetSession(userId, "enter_prefix", data);
                        Vk.MessagesSend("✅ Пароль принят.\n\n📋 Введите префикс таблиц (по умолчанию xf_):", 0, peerId);
                        return true;
                    }

                case "enter_prefix":
                    {
                        text = text.Trim();
                        if (string.IsNullOrEmpty(text)) text = "xf_";
                        data["table_prefix"] = text;
                        SetSession(userId, "confirm", data);

                        Vk.MessagesSend(
                            "📋 Проверьте данные:\n\n" +
                            $"🔹 Хост: {data["db_host"]}\n" +
                            $"🔹 Порт: {data["db_port"]}\n" +
                            $"🔹 БД: {data["db_name"]}\n" +
                            $"🔹 Пользователь: {data["db_user"]}\n" +
                            $"🔹 Префикс: {data["table_prefix"]}\n\n" +
                            "Напишите «да» для подтверждения:", 0, peerId);
                        return true;
                    }

                case "confirm":
                    {
                        string norm = text.Trim().ToLower();
                        if (norm != "да" && norm != "yes")
                        {
                            Vk.MessagesSend("⚠️ Напишите «да»:", 0, peerId);
                            return true;
                        }

                        try
                        {
                            using var xf = CreateDbClient(data);
                            bool ok = await xf.TestConnection();

                            if (!ok)
                            {
                                Vk.MessagesSend("❌ Не удалось подключиться к БД. Проверьте данные.", 0, peerId);
                                _sessions.TryRemove(userId, out _);
                                return true;
                            }

                            db.executeQuery(
                                "INSERT INTO forum_connections (peer_id, api_url, api_key, admin_user_id) VALUES (?, ?, ?, ?) " +
                                "ON DUPLICATE KEY UPDATE api_url=?, api_key=?, admin_user_id=?",
                                peerId,
                                $"{data["db_host"]}:{data["db_port"]}",
                                $"{data["db_user"]}:{data["db_pass"]}:{data["db_name"]}:{data["table_prefix"]}",
                                0,
                                $"{data["db_host"]}:{data["db_port"]}",
                                $"{data["db_user"]}:{data["db_pass"]}:{data["db_name"]}:{data["table_prefix"]}",
                                0);

                            _sessions.TryRemove(userId, out _);
                            Vk.MessagesSend(
                                "✅ XenForo БД подключена!\n\n" +
                                "Команды:\n" +
                                "!связать [ник] — привязать аккаунт\n" +
                                "!кто [ник/ID] — профиль\n" +
                                "!фсвязать [приоритет] [group_id]\n" +
                                "!фвыдать [ник] [приоритет]\n" +
                                "!фзабрать [ник] [приоритет]\n" +
                                "!фстатус", 0, peerId);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"[FORUM] Setup error: {ex.Message}");
                            Vk.MessagesSend($"❌ Ошибка подключения: {ex.Message}", 0, peerId);
                            _sessions.TryRemove(userId, out _);
                        }
                        return true;
                    }
            }
            return false;
        }

        public static async Task<bool> HandleForumCommand(vk Vk, Database db, long peerId, long userId, string text, bool isChatAdmin)
        {
            var conn = GetConnection(db, peerId);
            if (conn == null) return false;

            string[] parts = text.Split(" ");
            string cmd = parts.Length > 0 ? parts[0].ToLower() : "";
            if (cmd.Length > 0 && (cmd[0] == '!' || cmd[0] == '/' || cmd[0] == '+' || cmd[0] == '-'))
                cmd = cmd.Substring(1);
            string arg1 = parts.Length > 1 ? parts[1] : "";
            string arg2 = parts.Length > 2 ? parts[2] : "";

            try
            {
                using var xf = CreateDbClient(conn);

                switch (cmd)
                {
                    case "link":
                    case "связать":
                        return await HandleLink(Vk, db, peerId, userId, xf, arg1);

                    case "whois":
                    case "кто":
                        return await HandleWhois(Vk, peerId, xf, arg1);

                    case "фвыдать":
                    case "выдать":
                    case "give":
                        if (!isChatAdmin) return false;
                        return await HandleGiveRole(Vk, db, peerId, userId, xf, arg1, arg2);

                    case "фзабрать":
                    case "забрать":
                    case "take":
                        if (!isChatAdmin) return false;
                        return await HandleTakeRole(Vk, db, peerId, userId, xf, arg1, arg2);

                    case "фсвязать":
                    case "связатьроль":
                        if (!isChatAdmin) return false;
                        return await HandleBindRole(Vk, db, peerId, arg1, arg2);

                    case "фудалить":
                    case "удалитьроль":
                        if (!isChatAdmin) return false;
                        return await HandleUnbindRole(Vk, db, peerId, arg1);

                    case "фконфиг":
                    case "конфиг":
                        return await HandleConfig(Vk, db, peerId);

                    case "фстатус":
                    case "forumstatus":
                        return await HandleStatus(Vk, db, peerId, xf);

                    default:
                        return false;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[FORUM] Command error: {ex.Message}");
                return false;
            }
        }

        private static async Task<bool> HandleLink(vk Vk, Database db, long peerId, long userId, XenForoDbClient xf, string nickname)
        {
            if (string.IsNullOrEmpty(nickname))
            {
                Vk.MessagesSend("⚠️ Использование: !связать [никнейм]", 0, peerId);
                return true;
            }

            var user = await xf.GetUserByName(nickname);
            if (user == null)
            {
                Vk.MessagesSend($"❌ Пользователь '{nickname}' не найден.", 0, peerId);
                return true;
            }

            long forumId = (long)user["user_id"];
            string forumNick = (string)user["username"];

            db.executeQuery(
                "INSERT INTO forum_links (peer_id, vk_id, forum_user_id, forum_username) VALUES (?, ?, ?, ?) " +
                "ON DUPLICATE KEY UPDATE forum_user_id=?, forum_username=?",
                peerId, userId, forumId, forumNick, forumId, forumNick);

            Vk.MessagesSend(
                $"✅ Привязано: {forumNick} (ID: {forumId})\n" +
                "Теперь админы могут выдавать права по упоминанию.", 0, peerId);
            return true;
        }

        private static async Task<bool> HandleWhois(vk Vk, long peerId, XenForoDbClient xf, string target)
        {
            if (string.IsNullOrEmpty(target))
            {
                Vk.MessagesSend("⚠️ Использование: !кто [ник/ID]", 0, peerId);
                return true;
            }

            Dictionary<string, object> user = null;

            if (long.TryParse(target, out long uid))
                user = await xf.GetUserById(uid);
            else
                user = await xf.GetUserByName(target);

            if (user == null)
            {
                Vk.MessagesSend("❌ Не найден.", 0, peerId);
                return true;
            }

            int msgCount = (int)user["message_count"];
            int reactionScore = (int)user["reaction_score"];
            string title = (string)user["user_title"];
            int groupId = (int)user["user_group_id"];
            long registerDate = (long)user["register_date"];
            string regDateStr = DateTimeOffset.FromUnixTimeSeconds(registerDate).ToString("dd.MM.yyyy");

            Vk.MessagesSend(
                $"👤 {user["username"]} (ID: {user["user_id"]})\n\n" +
                $"📊 Сообщений: {msgCount}\n" +
                $"⭐ Реакций: {reactionScore}\n" +
                $"🏷 Титул: {title}\n" +
                $"👥 Группа: {groupId}\n" +
                $"📅 Регистрация: {regDateStr}", 0, peerId);
            return true;
        }

        private static async Task<bool> HandleGiveRole(vk Vk, Database db, long peerId, long userId, XenForoDbClient xf, string nick, string priorityStr)
        {
            if (string.IsNullOrEmpty(nick) || string.IsNullOrEmpty(priorityStr))
            {
                Vk.MessagesSend("⚠️ Использование: !фвыдать [ник] [приоритет]", 0, peerId);
                return true;
            }

            var role = GetRole(db, peerId, priorityStr);
            if (role == null)
            {
                Vk.MessagesSend("❌ Роль не привязана. Используйте !фсвязать", 0, peerId);
                return true;
            }

            Dictionary<string, object> user = null;
            if (nick.StartsWith("[id"))
            {
                int idx = nick.IndexOf("|");
                if (idx > 0 && long.TryParse(nick.Substring(3, idx - 3), out long vkId))
                {
                    var link = GetLink(db, peerId, vkId);
                    if (link != null)
                        user = await xf.GetUserById(long.Parse(link["forum_user_id"]));
                }
            }
            else
            {
                user = await xf.GetUserByName(nick);
            }

            if (user == null)
            {
                Vk.MessagesSend("❌ Пользователь не найден на форуме.", 0, peerId);
                return true;
            }

            int groupId = int.Parse(role["group_id"]);
            long forumId = (long)user["user_id"];
            string result = await xf.AddGroup(forumId, groupId);

            switch (result)
            {
                case "OK":
                    Vk.MessagesSend($"✅ Группа {groupId} выдана {user["username"]}.", 0, peerId);
                    break;
                case "ALREADY_PRIMARY":
                    Vk.MessagesSend("⚠️ Уже основная группа.", 0, peerId);
                    break;
                case "ALREADY_EXISTS":
                    Vk.MessagesSend("⚠️ Уже в группе.", 0, peerId);
                    break;
                case "USER_NOT_FOUND":
                    Vk.MessagesSend("❌ Пользователь не найден в БД.", 0, peerId);
                    break;
                default:
                    Vk.MessagesSend("❌ Ошибка.", 0, peerId);
                    break;
            }
            return true;
        }

        private static async Task<bool> HandleTakeRole(vk Vk, Database db, long peerId, long userId, XenForoDbClient xf, string nick, string priorityStr)
        {
            if (string.IsNullOrEmpty(nick) || string.IsNullOrEmpty(priorityStr))
            {
                Vk.MessagesSend("⚠️ Использование: !фзабрать [ник] [приоритет]", 0, peerId);
                return true;
            }

            var role = GetRole(db, peerId, priorityStr);
            if (role == null)
            {
                Vk.MessagesSend("❌ Роль не привязана.", 0, peerId);
                return true;
            }

            Dictionary<string, object> user = null;
            if (nick.StartsWith("[id"))
            {
                int idx = nick.IndexOf("|");
                if (idx > 0 && long.TryParse(nick.Substring(3, idx - 3), out long vkId))
                {
                    var link = GetLink(db, peerId, vkId);
                    if (link != null)
                        user = await xf.GetUserById(long.Parse(link["forum_user_id"]));
                }
            }
            else
            {
                user = await xf.GetUserByName(nick);
            }

            if (user == null)
            {
                Vk.MessagesSend("❌ Пользователь не найден.", 0, peerId);
                return true;
            }

            int groupId = int.Parse(role["group_id"]);
            long forumId = (long)user["user_id"];
            string result = await xf.RemoveGroup(forumId, groupId);

            switch (result)
            {
                case "OK":
                    Vk.MessagesSend($"✅ Группа {groupId} забрана у {user["username"]}.", 0, peerId);
                    break;
                case "IS_PRIMARY":
                    Vk.MessagesSend("⚠️ Это основная группа.", 0, peerId);
                    break;
                case "NOT_IN_GROUP":
                    Vk.MessagesSend("⚠️ Не в этой группе.", 0, peerId);
                    break;
                default:
                    Vk.MessagesSend("❌ Ошибка.", 0, peerId);
                    break;
            }
            return true;
        }

        private static async Task<bool> HandleBindRole(vk Vk, Database db, long peerId, string priority, string groupIdStr)
        {
            if (string.IsNullOrEmpty(priority) || string.IsNullOrEmpty(groupIdStr) || !int.TryParse(groupIdStr, out int gid))
            {
                Vk.MessagesSend("⚠️ Использование: !фсвязать [приоритет] [group_id]", 0, peerId);
                return true;
            }

            db.executeQuery(
                "INSERT INTO forum_roles (peer_id, priority, group_id) VALUES (?, ?, ?) " +
                "ON DUPLICATE KEY UPDATE group_id=?",
                peerId, priority, gid, gid);

            Vk.MessagesSend($"✅ {priority} → группа {gid}", 0, peerId);
            return true;
        }

        private static async Task<bool> HandleUnbindRole(vk Vk, Database db, long peerId, string priority)
        {
            if (string.IsNullOrEmpty(priority))
            {
                Vk.MessagesSend("⚠️ Использование: !фудалить [приоритет]", 0, peerId);
                return true;
            }

            db.executeQuery("DELETE FROM forum_roles WHERE peer_id=? AND priority=?", peerId, priority);
            Vk.MessagesSend("🗑 Удалено.", 0, peerId);
            return true;
        }

        private static async Task<bool> HandleConfig(vk Vk, Database db, long peerId)
        {
            var roles = db.fetchAll("SELECT priority, group_id FROM forum_roles WHERE peer_id=?", peerId);
            if (roles == null || roles.Count == 0)
            {
                Vk.MessagesSend("ℹ Нет ролей. Используйте !фсвязать", 0, peerId);
                return true;
            }

            var lines = new List<string> { "📋 Роли:" };
            foreach (var r in roles)
                lines.Add($"• {r["priority"]} → группа {r["group_id"]}");
            Vk.MessagesSend(string.Join("\n", lines), 0, peerId);
            return true;
        }

        private static async Task<bool> HandleStatus(vk Vk, Database db, long peerId, XenForoDbClient xf)
        {
            bool ok = false;
            try { ok = await xf.TestConnection(); } catch { }

            var conn = GetConnection(db, peerId);
            string hostInfo = conn != null ? conn["db_host"] + ":" + conn["db_port"] : "не настроено";

            var roles = db.fetchAll("SELECT priority FROM forum_roles WHERE peer_id=?", peerId);

            Vk.MessagesSend(
                $"🌐 XenForo БД\n\n" +
                $"Хост: {hostInfo}\n" +
                $"Соединение: {(ok ? "✅" : "❌")}\n" +
                $"Ролей: {roles?.Count ?? 0}", 0, peerId);
            return true;
        }

        public static Dictionary<string, string> GetConnection(Database db, long peerId)
        {
            var rows = db.fetchAll("SELECT api_url, api_key FROM forum_connections WHERE peer_id=? LIMIT 1", peerId);
            if (rows == null || rows.Count == 0) return null;

            var row = rows[0];
            string apiUrl = row["api_url"] ?? "";
            string apiKey = row["api_key"] ?? "";

            if (!apiUrl.Contains(":")) return null;

            string[] urlParts = apiUrl.Split(':');
            string[] keyParts = apiKey.Split(':');

            if (keyParts.Length < 3) return null;

            return new Dictionary<string, string>
            {
                { "db_host", urlParts[0] },
                { "db_port", urlParts.Length > 1 ? urlParts[1] : "3306" },
                { "db_user", keyParts[0] },
                { "db_pass", keyParts[1] },
                { "db_name", keyParts[2] },
                { "table_prefix", keyParts.Length > 3 ? keyParts[3] : "xf_" }
            };
        }

        public static Dictionary<string, string> GetLink(Database db, long peerId, long vkId)
        {
            var rows = db.fetchAll("SELECT forum_user_id FROM forum_links WHERE peer_id=? AND vk_id=? LIMIT 1", peerId, vkId);
            return rows != null && rows.Count > 0 ? rows[0] : null;
        }

        public static Dictionary<string, string> GetRole(Database db, long peerId, string priority)
        {
            var rows = db.fetchAll("SELECT group_id FROM forum_roles WHERE peer_id=? AND priority=? LIMIT 1", peerId, priority);
            return rows != null && rows.Count > 0 ? rows[0] : null;
        }

        public static void StartSetup(vk Vk, long peerId, long userId)
        {
            if (!settings.isPeer(peerId))
            {
                Vk.MessagesSend("⚠️ Только в беседах.", 0, peerId);
                return;
            }

            SetSession(userId, "enter_host", new Dictionary<string, string>());
            Vk.MessagesSend(
                "🌐 Подключение XenForo (через БД)\n\n" +
                "📡 Введите хост MySQL (например localhost):", 0, peerId);
        }
    }
}
