﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.cmds
{
    internal class game_cmds
    {
        public vk Vk;
        public settings settings;
        public Database db;
        private AntiFlood antiflood;
        private check_for_cmd cmdChecker;
        private Cache Cache;
        public string[] parames_cmd = { };
        public string[] parames_lowcmd = { };
        public string lowercase_text = "";

        public game_cmds(vk vks, Database dbs, settings set, Cache cache)
        {
            Vk = vks;
            settings = set;
            db = dbs;
            antiflood = new(vks);
            cmdChecker = new(db, vks);
            Cache = cache;
        }


        public async Task<bool> CheckCmd(string cmd)
        {
            if (cmd.Length >= 1)
            {
                cmd = cmd.Replace("'", "");
                cmd = cmd.Replace("\"", "");
            }

            //Vk.m_text = Vk.m_text.Replace("\n", "");
            //Vk.m_text = Vk.m_text.Replace("\r", "");
            //Vk.m_text = Vk.m_text.Replace("<br>", "");
            string? text = cmd;
            if (text == "")
            {
                return false;
            }
            string lowercase = text.ToLower();
            string[] parames = text.Split(" ");
            string[] parames_low = lowercase.Split(" ");

            var userInfoGlobal = db.usersGetUser(Vk.m_from_id);

            string command = "";
            if (settings.isUserChat(Vk.m_peer_id))
            {
                if (parames_low.Count() >= 1)
                {
                    // cmd уже без префикса — не нужно Substring(1)
                    command = parames_low[0];
                }
                else
                {
                    command = text;
                }
            }
            else
            {
                if (parames_low.Count() >= 1)
                {
                    command = parames_low[0];
                }
                else
                {
                    command = "";
                }
            }

            //СТРАНЫ - ПОКАЗ СТАТИСТИКИ И МЕНЮ
            /*
             страна/моястрана - показ информации о стране (краткая)
            страна экономика - показ информации о стране (экономика)
            страна транспорт - показ информации о стране (транспорт)
            страна 
             */
            
            switch (command)
            {
                
                default:
                    break;
            }

            // команды игровые
            switch (command)
            {
                default:
                    break;
            }

            // ----------- МАГАЗИНЫ

            switch (command)
            {
               
            }

            

            // ------------ АГЕНТЫ
            switch (command)
            {
                
                default:
                    return false;
            }
        }
    }
}
