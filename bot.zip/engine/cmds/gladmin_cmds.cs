﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace GrandManager.engine.cmds
{
    class gladmin_cmds
    {
        public vk Vk;
        public settings settings;
        public Database db;
        private AntiFlood antiflood;
        private check_for_cmd cmdChecker;

        public gladmin_cmds(vk vks, Database dbs, settings set)
        {
            Vk = vks;
            settings = set;
            db = dbs;
            antiflood = new(vks);
            cmdChecker = new(db, vks);
        }

        public void command_pin()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 80, "pin"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "pin", 5))
                {
                    return;
                }

                if (Vk.m_reply_message == null || Vk.m_reply_message["conversation_message_id"] == null || Vk.m_reply_message["conversation_message_id"].ToString() == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["pin"]);
                    return;
                }

                long id = ((int)Vk.m_reply_message["conversation_message_id"]);

                string method = "messages.pin";
                Dictionary<string, string> parames = new()
            {
                { "peer_id", Vk.m_peer_id.ToString() },
                { "conversation_message_id", id.ToString() }
            };

                Vk.VkAPI(method, parames);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_unpin()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 80, "unpin"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "unpin", 5))
                {
                    return;
                }

                string method = "messages.unpin";
                Dictionary<string, string> parames = new()
            {
                { "peer_id", Vk.m_peer_id.ToString() }
            };

                Vk.VkAPI(method, parames);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }

        }

        public async void command_addadmin()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 80, "addadmin"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "addadmin", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

                Dictionary<string, string>? Target_User = null;

                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["addadmin"]);
                    return;
                }

                string nickname;

                long target_id = long.Parse(args[0]);

                Target_User = db.peersGetMember(Vk.m_peer_id, target_id, false, true);

                if (Target_User == null)
                {
                    Vk.MessagesSend("Не удалось найти информацию про этого пользователя.");
                    return;
                }

                string nick_admin = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);

                if (Target_User["nick"] == "")
                {
                    Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(Target_User["user_id"]) });
                    if (user_vk.ContainsKey("id" + Target_User["user_id"]))
                    {
                        nickname = "[id" + args[0] + "|" +
                            user_vk["id" + Target_User["user_id"]].first_name + " " + user_vk["id" + Target_User["user_id"]].last_name + "]";
                    }
                    else
                    {
                        nickname = "[club" + args[0].Substring(1) + "|Сообщество]";
                    }
                }
                else
                {
                    if (target_id < 0)
                    {
                        nickname = "[club" + args[0].Substring(1) + "|" + Target_User["nick"] + "]";
                    }
                    else
                    {
                        nickname = "[id" + args[0] + "|" + Target_User["nick"] + "]";
                    }
                }

                string text;
                if (long.Parse(Target_User["priority"]) != 0)
                {
                    if (long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"]))
                    {
                        Vk.MessagesSend("Вы не можете изменять группу человека, роль которого выше или равна вашей.");
                        return;
                    }
                    if (long.Parse(Target_User["priority"]) >= 60)
                    {
                        Vk.MessagesSend(nickname + " уже имеет роль с большим, либо таким же приоритетом.");
                        return;
                    }
                    var old_name = db.rolesGetName(Vk.m_peer_id, Target_User["priority"]);
                    text = nickname + " получил права администратора." + "<br>" +
                    "Выдал: " + nick_admin + "<br>" +
                    "Предыдущая роль: " + old_name;
                }
                else
                {
                    text = nickname + " получил права администратора." + "<br>" +
                    "Выдал: " + nick_admin;
                }

                List<string> buttons_names = new List<string>()
                {
                    "Снять"
                };
                List<string> buttons_commands = new List<string>()
                {
                    "rr id" + args[0]
                };
                List<string> buttons_colors = new List<string>()
                {
                    Vk.BUTTON_RED
                };

                var buttons = Vk.GenerateKeyboard(buttons_names.ToArray(), buttons_commands.ToArray(), buttons_colors.ToArray());

                Vk.MessagesSend(text, 1, 0, buttons);
                db.peersMemberSetPriority(Vk.m_peer_id, target_id, 60);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_SETROLE, Vk.m_from_id, long.Parse(args[0]), "выдал роль", "60", Target_User["priority"]);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_gadmin()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 80, "gadmin"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "gadmin", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["gadmin"]);
                    return;
                }

                string nickname;

                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);
                if (Target_Peer["in_pool"] == "0")
                {
                    Vk.MessagesSend("Беседа не состоит в объединении. Используйте /addunity для включения конференции в объединение.");
                    return;
                }

                var ListPeers = db.unitesGetPeers(long.Parse(Target_Peer["in_pool"]));
                if (ListPeers == null || ListPeers.Count <= 1)
                {
                    Vk.MessagesSend("Данную команду можно применять в объединениях, у которых есть 2 и более бесед.");
                    return;
                }

                long target_id = long.Parse(args[0]);

                foreach (var peerid in ListPeers)
                {
                    UserInfo = db.peersGetMember(peerid, Vk.m_from_id);
                    if (!cmdChecker.CommandsCheck(UserInfo, 80, "gadmin"))
                    {
                        continue;
                    }

                    Target_User = db.peersGetMember(peerid, target_id, false, true);

                    if (Target_User == null)
                    {
                        Vk.MessagesSend("Не удалось найти информацию про этого пользователя.", 0, peerid);
                        continue;
                    }

                    string nick_admin = db.peersGetNickUrl(peerid, Vk.m_from_id);

                    if (Target_User["nick"] == "")
                    {
                        Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(Target_User["user_id"]) });
                        if (user_vk.ContainsKey("id" + Target_User["user_id"]))
                        {
                            nickname = "[id" + args[0] + "|" +
                                user_vk["id" + Target_User["user_id"]].first_name + " " + user_vk["id" + Target_User["user_id"]].last_name + "]";
                        }
                        else
                        {
                            nickname = "[club" + args[0].Substring(1) + "|Сообщество]";
                        }
                    }
                    else
                    {
                        if (target_id < 0)
                        {
                            nickname = "[club" + args[0].Substring(1) + "|" + Target_User["nick"] + "]";
                        }
                        else
                        {
                            nickname = "[id" + args[0] + "|" + Target_User["nick"] + "]";
                        }
                    }

                    string text;
                    if (long.Parse(Target_User["priority"]) != 0)
                    {
                        if (long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"]))
                        {
                            Vk.MessagesSend("Вы не можете изменять группу человека, роль которого выше или равна вашей.", 0, peerid);
                            continue;
                        }
                        if (long.Parse(Target_User["priority"]) >= 60)
                        {
                            Vk.MessagesSend(nickname + " уже имеет роль с большим, либо таким же приоритетом.", 0, peerid);
                            continue;
                        }
                        var old_name = db.rolesGetName(peerid, Target_User["priority"]);
                        text = nickname + " получил права администратора." + "<br>" +
                        "Выдал: " + nick_admin + "<br>" +
                        "Предыдущая роль: " + old_name;
                    }
                    else
                    {
                        text = nickname + " получил права администратора." + "<br>" +
                        "Выдал: " + nick_admin;
                    }

                    Vk.MessagesSend(text, 0, peerid);
                    db.peersMemberSetPriority(peerid, target_id, 60);
                    db.logsAddLog(peerid, Database.logsId.USER_SETROLE, Vk.m_from_id, target_id, "выдал роль (пулл)", "60", Target_User["priority"]);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_newrole()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 80, "newrole"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "newrole", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "int", "text" });

                if (args[0] == null || args[0] == "" || args[1] == null || args[1] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["newrole"]);
                    return;
                }

                long target_role = 0;
                try
                {
                    target_role = long.Parse(args[0]);
                }
                catch
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["newrole"]);
                    return;
                }

                if (target_role < 0 || target_role > 100)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["newrole"]);
                    return;
                }


                var peerInfo = db.peersGetPeer(Vk.m_peer_id);

                if (vk.EmojiCount(args[1]) >= 1)
                {
                    if (!db.PeerIsVip(peerInfo))
                    {
                        Vk.MessagesSend("Использовать смайлы в ролях можно только в VIP беседах.");
                        return;
                    }
                }

                if (args[1].Length >= 26)
                {
                    if (!db.PeerIsVip(peerInfo))
                    {
                        Vk.MessagesSend("Использовать больше 25 символов в ролях можно только в VIP беседах.");
                        return;
                    }
                    if (args[1].Length >= 51)
                    {
                        Vk.MessagesSend("Использовать больше 50 символов в ролях нельзя.");
                        return;
                    }
                }

                if (long.Parse(UserInfo["priority"]) < target_role)
                {
                    Vk.MessagesSend("Нельзя изменить роль, приоритет которой больше или равен вашему.");
                    return;
                }

                string nickname;

                if (UserInfo["nick"] == "")
                {
                    Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { Vk.m_from_id });
                    if (user_vk.ContainsKey("id" + Vk.m_from_id))
                    {
                        nickname = "[id" + Vk.m_from_id + "|" +
                            user_vk["id" + Vk.m_from_id].first_name + " " + user_vk["id" + Vk.m_from_id].last_name + "]";
                    }
                    else
                    {
                        nickname = "[club" + Vk.m_from_id.ToString().Substring(1) + "|Сообщество]";
                    }
                }
                else
                {
                    if (Vk.m_from_id < 0)
                    {
                        nickname = "[club" + Vk.m_from_id.ToString().Substring(1) + "|" + UserInfo["nick"] + "]";
                    }
                    else
                    {
                        nickname = "[id" + Vk.m_from_id + "|" + UserInfo["nick"] + "]";
                    }
                }

                string text = nickname + " изменил название роли с приоритетом " + target_role + ".<br><br>" +
                    "Новое название роли: " + args[1];
                Vk.MessagesSend(text);

                var role = db.peerGetRoles(Vk.m_peer_id, true);
                if (role.ContainsKey(target_role.ToString()))
                {
                    db.rolesSetName(Vk.m_peer_id, target_role, args[1], Vk.m_from_id);
                }
                else
                {
                    db.rolesAddName(Vk.m_peer_id, target_role, args[1], Vk.m_from_id);
                }
                db.peerGetMembersWhenRole(Vk.m_peer_id, true, 1000);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_gnewrole()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 80, "gnewrole"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "gnewrole", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "int", "text" });

                if (args[0] == null || args[0] == "" || args[1] == null || args[1] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["newrole"]);
                    return;
                }

                long target_role = 0;
                try
                {
                    target_role = long.Parse(args[0]);
                }
                catch
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["newrole"]);
                    return;
                }

                if (target_role < 0 || target_role > 100)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["newrole"]);
                    return;
                }

                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);
                if (Target_Peer["in_pool"] == "0")
                {
                    Vk.MessagesSend("Беседа не состоит в объединении. Используйте /addunity для включения конференции в объединение.");
                    return;
                }

                var ListPeers = db.unitesGetPeers(long.Parse(Target_Peer["in_pool"]));
                if (ListPeers == null || ListPeers.Count <= 1)
                {
                    Vk.MessagesSend("Данную команду можно применять в объединениях, у которых есть 2 и более бесед.");
                    return;
                }

                foreach (var peerid in ListPeers)
                {
                    UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                    if (!cmdChecker.CommandsCheck(UserInfo, 80, "gnewrole"))
                    {
                        return;
                    }

                    var peerInfo = db.peersGetPeer(peerid);

                    if (vk.EmojiCount(args[1]) >= 1)
                    {
                        if (!db.PeerIsVip(peerInfo))
                        {
                            Vk.MessagesSend("Использовать смайлы в ролях можно только в VIP беседах.");
                            return;
                        }
                    }

                    if (args[1].Length >= 26)
                    {
                        if (!db.PeerIsVip(peerInfo))
                        {
                            Vk.MessagesSend("Использовать больше 25 символов в ролях можно только в VIP беседах.");
                            return;
                        }
                        if (args[1].Length >= 51)
                        {
                            Vk.MessagesSend("Использовать больше 50 символов в ролях нельзя.");
                            return;
                        }
                    }

                    string nickname;

                    if (UserInfo["nick"] == "")
                    {
                        Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { Vk.m_from_id });
                        if (user_vk.ContainsKey("id" + Vk.m_from_id))
                        {
                            nickname = "[id" + Vk.m_from_id + "|" +
                                user_vk["id" + Vk.m_from_id].first_name + " " + user_vk["id" + Vk.m_from_id].last_name + "]";
                        }
                        else
                        {
                            nickname = "[club" + Vk.m_from_id.ToString().Substring(1) + "|Сообщество]";
                        }
                    }
                    else
                    {
                        if (Vk.m_from_id < 0)
                        {
                            nickname = "[club" + Vk.m_from_id.ToString().Substring(1) + "|" + UserInfo["nick"] + "]";
                        }
                        else
                        {
                            nickname = "[id" + Vk.m_from_id + "|" + UserInfo["nick"] + "]";
                        }
                    }

                    if (long.Parse(UserInfo["priority"]) < target_role)
                    {
                        Vk.MessagesSend("Нельзя изменить роль, приоритет которой больше или равен вашему.", 0, peerid);
                        return;
                    }

                    string text = nickname + " изменил название роли с приоритетом " + target_role + ".<br><br>" +
                        "Новое название роли: " + args[1];
                    Vk.MessagesSend(text, 0, peerid);

                    var role = db.peerGetRoles(peerid);
                    if (role.ContainsKey(target_role.ToString()))
                    {
                        db.rolesSetName(peerid, target_role, args[1], Vk.m_from_id);
                    }
                    else
                    {
                        db.rolesAddName(peerid, target_role, args[1], Vk.m_from_id);
                    }
                    db.peerGetMembersWhenRole(peerid, true, 1000);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_deleterole()
        {
            try
            {
                //rolesDelName
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 80, "deleterole"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "deleterole", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["deleterole"]);
                    return;
                }

                string nick_admin = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);


                string[] args_role = await cmdChecker.getArguments("/setrole " + args[0], new string[] { "int" });
                long target_role_priority = -1;
                if (args_role[0] == null || args_role[0] == "")
                {
                    string[] args_roletext = await cmdChecker.getArguments("/setrole " + args[0], new string[] { "text" });
                    if (args_roletext[0] == null || args_roletext[0] == "")
                    {
                        Vk.MessagesSend(CommandsList.CommandsHelp["setrole"]);
                        return;
                    }
                    var roles = db.peerGetRoles(Vk.m_peer_id);
                    args_roletext[0] = Regex.Replace(args_roletext[0], @"\p{Cs}", "").ToLower().Replace(" ", "");

                    foreach (var item in roles)
                    {
                        var name_role = Regex.Replace(item.Value.name, @"\p{Cs}", "").ToLower().Replace(" ", "");
                        if (args_roletext[0] == name_role)
                        {
                            target_role_priority = item.Value.priority;
                            break;
                        }
                    }
                    if (args_roletext[0] == "helper" || args_roletext[0] == "хелпер" || args_roletext[0] == "помощник" || args_roletext[0] == "help")
                    {
                        target_role_priority = 20;
                    }
                    else if (args_roletext[0] == "moder" || args_roletext[0] == "модер" || args_roletext[0] == "модератор" || args_roletext[0] == "moderator")
                    {
                        target_role_priority = 40;
                    }
                    else if (args_roletext[0] == "admin" || args_roletext[0] == "админ" || args_roletext[0] == "администратор" || args_roletext[0] == "administrator")
                    {
                        target_role_priority = 60;
                    }
                    else if (args_roletext[0] == "gadmin" || args_roletext[0] == "главныйадмин" || args_roletext[0] == "glavadmin" || args_roletext[0] == "gadmin" ||
                        args_roletext[0] == "gadministrator" || args_roletext[0] == "гадмин" || args_roletext[0] == "главныйадмин" || args_roletext[0] == "главныйадминистратор" ||
                        args_roletext[0] == "spec" || args_roletext[0] == "lead")
                    {
                        target_role_priority = 80;
                    }
                }
                else
                {
                    if (long.Parse(args_role[0]) > 100 || long.Parse(args_role[0]) <= -1)
                    {
                        Vk.MessagesSend("К сожалению, роль с таким приоритетом/названием не найдена.<br>Список доступных ролей: /roles");
                        return;
                    }
                    target_role_priority = long.Parse(args_role[0]);
                }

                if (target_role_priority <= -1)
                {

                    Vk.MessagesSend("К сожалению, роль с таким приоритетом/названием не найдена.<br>Список доступных ролей: /roles");
                    return;
                }
                if (long.Parse(UserInfo["priority"]) <= target_role_priority)
                {
                    Vk.MessagesSend("Вы не можете удалять роль, приоритет которой выше или равен вашему.");
                    return;
                }

                string text;
                text = nick_admin + " удалил роль с приоритетом " + target_role_priority;

                Vk.MessagesSend(text);
                db.rolesDelName(Vk.m_peer_id, target_role_priority);
                db.peerGetMembersWhenRole(Vk.m_peer_id, true, 1000);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_gdeleterole()
        {
            try
            {
                //rolesDelName
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 80, "gdeleterole"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "gdeleterole", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["deleterole"]);
                    return;
                }

                string nick_admin = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);


                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);
                if (Target_Peer["in_pool"] == "0")
                {
                    Vk.MessagesSend("Беседа не состоит в объединении. Используйте /addunity для включения конференции в объединение.");
                    return;
                }

                var ListPeers = db.unitesGetPeers(long.Parse(Target_Peer["in_pool"]));
                if (ListPeers == null || ListPeers.Count <= 1)
                {
                    Vk.MessagesSend("Данную команду можно применять в объединениях, у которых есть 2 и более бесед.");
                    return;
                }

                string[] args_role = await cmdChecker.getArguments("/setrole " + args[0], new string[] { "int" });
                

                foreach (var peerid in ListPeers)
                {
                    long target_role_priority = -1;
                    UserInfo = db.peersGetMember(peerid, Vk.m_from_id);
                    if (!cmdChecker.CommandsCheck(UserInfo, 80, "gdeleterole"))
                    {
                        continue;
                    }
                    if (args_role[0] == null || args_role[0] == "")
                    {
                        string[] args_roletext = await cmdChecker.getArguments("/setrole " + args[0], new string[] { "text" });
                        if (args_roletext[0] == null || args_roletext[0] == "")
                        {
                            Vk.MessagesSend(CommandsList.CommandsHelp["setrole"]);
                            return;
                        }
                        var roles = db.peerGetRoles(peerid);
                        args_roletext[0] = Regex.Replace(args_roletext[0], @"\p{Cs}", "").ToLower().Replace(" ", "");

                        foreach (var item in roles)
                        {
                            var name_role = Regex.Replace(item.Value.name, @"\p{Cs}", "").ToLower().Replace(" ", "");
                            if (args_roletext[0] == name_role)
                            {
                                target_role_priority = item.Value.priority;
                                break;
                            }
                        }
                        if (args_roletext[0] == "helper" || args_roletext[0] == "хелпер" || args_roletext[0] == "помощник" || args_roletext[0] == "help")
                        {
                            target_role_priority = 20;
                        }
                        else if (args_roletext[0] == "moder" || args_roletext[0] == "модер" || args_roletext[0] == "модератор" || args_roletext[0] == "moderator")
                        {
                            target_role_priority = 40;
                        }
                        else if (args_roletext[0] == "admin" || args_roletext[0] == "админ" || args_roletext[0] == "администратор" || args_roletext[0] == "administrator")
                        {
                            target_role_priority = 60;
                        }
                        else if (args_roletext[0] == "gadmin" || args_roletext[0] == "главныйадмин" || args_roletext[0] == "glavadmin" || args_roletext[0] == "gadmin" ||
                            args_roletext[0] == "gadministrator" || args_roletext[0] == "гадмин" || args_roletext[0] == "главныйадмин" || args_roletext[0] == "главныйадминистратор" ||
                            args_roletext[0] == "spec" || args_roletext[0] == "lead")
                        {
                            target_role_priority = 80;
                        }
                    }
                    else
                    {
                        if (long.Parse(args_role[0]) > 100 || long.Parse(args_role[0]) <= -1)
                        {
                            if (Vk.m_peer_id == peerid)
                            {
                                Vk.MessagesSend("К сожалению, роль с таким приоритетом/названием не найдена.<br>Список доступных ролей: /roles");
                            }
                            
                            continue;
                        }
                        target_role_priority = long.Parse(args_role[0]);
                    }

                    if (target_role_priority <= -1)
                    {

                        if (Vk.m_peer_id == peerid)
                        {
                            Vk.MessagesSend("К сожалению, роль с таким приоритетом/названием не найдена.<br>Список доступных ролей: /roles");
                        }
                        continue;
                    }
                    if (long.Parse(UserInfo["priority"]) <= target_role_priority)
                    {
                        if (Vk.m_peer_id == peerid)
                        {
                            Vk.MessagesSend("К сожалению, роль с таким приоритетом/названием не найдена.<br>Список доступных ролей: /roles");
                        }
                        continue;
                    }

                    string text;
                    text = nick_admin + " удалил роль с приоритетом " + target_role_priority;

                    Vk.MessagesSend(text, 0, peerid);
                    db.rolesDelName(peerid, target_role_priority);
                    db.peerGetMembersWhenRole(peerid, true, 1000);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_welcome()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 80, "welcome"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "welcome", 5))
                {
                    return;
                }
                string originalTextMarkdown = TextFormatter.ToMarkdown(Vk.m_text_origin, (JObject?)Vk.format_data);
                string[] args = await cmdChecker.getArguments(originalTextMarkdown, new string[] { "text" });

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (PeerInfo["welcome_text"] != "0")
                {
                    Vk.MessagesSend("Приветствие беседы было удалено. Для установки повторно отправьте команду с текстом.");
                    db.peerMembersSetWelcome(Vk.m_peer_id, "0");
                    return;
                }

                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["welcome"]);
                    return;
                }

                if (args[0].Length >= 1000)
                {
                    if (!db.PeerIsVip(PeerInfo))
                    {
                        Vk.MessagesSend("Использовать больше 1000 символов в приветствии можно только в VIP беседах.");
                        return;
                    }
                    if (args[0].Length >= 2000)
                    {
                        Vk.MessagesSend("Использовать больше 2000 символов в приветствии нельзя.");
                        return;
                    }
                }

                Vk.MessagesSend("Приветствие беседы было успешно установлено.");
               
                db.peerMembersSetWelcome(Vk.m_peer_id, args[0]);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_setrules()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 80, "setrules"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "setrules", 5))
                {
                    return;
                }

                string originalTextMarkdown = TextFormatter.ToMarkdown(Vk.m_text_origin, (JObject?)Vk.format_data);

                string[] args = await cmdChecker.getArguments(originalTextMarkdown, new string[] { "text" });

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (PeerInfo["rules_text"] != "0" || args[0] == "0" || args[0] == "удалить" || args[0] == "del")
                {
                    Vk.MessagesSend("Правила беседы были удалены. Для установки повторно отправьте команду с текстом.");
                    db.peersSetRules(Vk.m_peer_id, "0");
                    return;
                }

                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["setrules"]);
                    return;
                }

                if (args[0].Length >= 1000)
                {
                    if (!db.PeerIsVip(PeerInfo))
                    {
                        Vk.MessagesSend("Использовать больше 1000 символов в правилах можно только в VIP беседах.");
                        return;
                    }
                    if (args[0].Length >= 5000)
                    {
                        Vk.MessagesSend("Использовать больше 5000 символов в правилах нельзя.");
                        return;
                    }
                }

                Vk.MessagesSend("Правила беседы были успешно установлены.");
                //var textMarkDown = TextFormatter.ToMarkdown(args[0], (JObject?)Vk.format_data);
                db.peersSetRules(Vk.m_peer_id, args[0]);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_setpublic()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 80, "public"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "public", 5))
                {
                    return;
                }
                var nickname = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });
                string[] args2 = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args2[0] == "0")
                {
                    var Target_Peer2 = db.peersGetPeer(Vk.m_peer_id);
                    
                    Vk.MessagesSend(nickname[Vk.m_from_id.ToString()] + " отключил проверку на вступление в группу.");
                    db.peersSetGroup(Vk.m_peer_id, 0);
                    return;
                }
                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] == null || long.Parse(args[0]) >= 1)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["public"]);
                    return;
                }

                

                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);
                if (Target_Peer["group"] != "0" || args[0] == "0" || args[0] == "")
                {
                    Vk.MessagesSend(nickname[Vk.m_from_id.ToString()] + " отключил проверку на вступление в группу.");
                    db.peersSetGroup(Vk.m_peer_id, 0);
                    return;
                }

                Vk.MessagesSend(nickname[Vk.m_from_id.ToString()] + $" установил проверку на вступление в [club{args[0].Substring(1)}|паблик].");
                db.peersSetGroup(Vk.m_peer_id, long.Parse(args[0].Substring(1)));
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_kickgroup()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 80, "kickgroup"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "kickgroup", 5))
                {
                    return;
                }
                
                
                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);
                if (Target_Peer["group"] == "0" || Target_Peer["access_token"] == "")
                {
                    Vk.MessagesSend("У данной беседы нет привязанного сообщества, либо отсутствует привязанный токен.<br><br>" +
                        "Привязать токен: !peertoken<br>" +
                        "Привязать группу: !setpublic");
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                

                string method = "messages.getConversationMembers";
                Dictionary<string, string> paramesd = new()
                    {
                        { "peer_id", Vk.m_peer_id.ToString() }
                    };
                var membersPeers = await Vk.VkAPI(method, paramesd);

                if (membersPeers.ContainsKey("error") || !membersPeers.ContainsKey("response"))
                {
                    Vk.MessagesSend("Ошибка обработки команды — возможно, у бота нет прав администратора в беседе.");
                    return;
                }

                long[] userids = new long[membersPeers["response"]["items"].Count()];
                long i = 0;
                foreach (var upd in membersPeers["response"]["items"])
                {
                    var id = (int)upd["member_id"];
                    if (id < 0)
                    {
                        continue;
                    }
                    userids[i] = id;
                    i++;
                }

                if (userids.Length >= 150)
                {
                    Vk.MessagesSend("Команда не работает, если в конференции или в группе более 150 участников в целях безопасности.");
                    return;
                }

                method = "groups.getMembers";
                var parames = new Dictionary<string, string>()
                {
                    { "group_id", Target_Peer["group"] },
                    { "access_token", SysUtils.DecryptString(Target_Peer["access_token"]) }
                };
                var result = await Vk.VkAPIs(method, parames);
                if (result.ContainsKey("error")) 
                {
                    Vk.MessagesSend("Ошибка обработки команды — возможно, у бота нет прав администратора в беседе, либо введен неправильный ID группы.");
                    return;
                }

                var count = int.Parse(result["response"]["count"].ToString());
                if (count >= 150)
                {
                    Vk.MessagesSend("Команда не рабоатет, если в конференции или в группе более 150 участников в целях безопасности.");
                    return;
                }

                if (result["response"]["items"] == null)
                {
                    Vk.MessagesSend("Ошибка обработки команды — возможно, у бота нет прав администратора в беседе, либо введен неправильный ID группы.");
                    return;
                }

                var listUsersNotPeer = new List<long>();

                var itemsGroup = result["response"]["items"];
                foreach (var item in itemsGroup)
                {
                    if (!userids.Contains(long.Parse(item.ToString())) && long.Parse(item.ToString()) > 0)
                    {
                        listUsersNotPeer.Add(long.Parse(item.ToString()));
                    }
                }

                if (listUsersNotPeer.Count <= 0)
                {
                    Vk.MessagesSend("Все участники группы состоят в беседе.");
                    return;
                }

                var users_names_vk = await Vk.UsersGetVkInfo(listUsersNotPeer.ToArray());

                string text = "Список на исключение из группы участников:<br><br>";
                long isd = 1;
                foreach (var item in listUsersNotPeer)
                {
                    if (users_names_vk.ContainsKey("id" + item))
                    {
                        if (item < 0)
                        {
                            text = text + isd + ". [club" + item.ToString().Substring(1) + "|" + users_names_vk["id" + item.ToString()].first_name + " " +
                                users_names_vk["id" + item].last_name + "]<br>";
                        }
                        else
                        {
                            text = text + isd + ". [id" + item + "|" + users_names_vk["id" + item].first_name + " " +
                                users_names_vk["id" + item].last_name + "]<br>";
                        }
                    }
                    else
                    {
                        continue;
                    }
                    isd++;
                }

                int time_elaps = 2 * listUsersNotPeer.Count();
                string time_text = time_elaps.ToString() + " секунд.";

                if (args[0] != "kick")
                {
                    text += "<br>Примерное время ожидания: " + time_text;
                    var buttons = Vk.GenerateKeyboard(new string[] { "начать" }, new string[] { "kickgroup kick" }, new string[]
                        { Vk.BUTTON_RED });
                    Vk.MessagesSend(text, 1, 0, buttons);
                    return;
                }
                else
                {
                    text += "<br>Пожалуйста, подождите. По окончании работы бот оповестит вас об этом в конференцию." +
                    "<br>Примерное время ожидания: " + time_text;
                    Vk.MessagesSend(text);
                }
                


                method = "groups.removeUser";
                var parms = new Dictionary<string, string>()
                {
                    { "group_id", Target_Peer["group"] },
                    { "access_token", SysUtils.DecryptString(Target_Peer["access_token"]) }
                };

                List<long> listNotKicked = new();

                foreach (var item in listUsersNotPeer)
                {
                    parms["user_id"] = item.ToString();
                    var res = await Vk.VkAPIs(method, parms);
                    if (res.ContainsKey("error"))
                    {
                        if (res["error"]["error_code"] != null)
                        {
                            var code = res["error"]["error_code"];
                            if (code.ToString() == "5")
                            {
                                Vk.MessagesSend("Ошибка исключения участника из группы — токен доступа недействителен, " +
                                    "поэтому он был отвязан от беседы, удаление участников остановлено.");
                                return;
                            }
                        }
                        listNotKicked.Add(item);
                    }
                    Thread.Sleep(2000);
                }

                if (listNotKicked.Count <= 0)
                {
                    Vk.MessagesSend("Все вышеперечисленные участники были исключены из группы.");
                    return;
                }

                //users_names_vk = await Vk.UsersGetVkInfo(listNotKicked.ToArray());
                text = "Произошла ошибка и участники не были исключены:<br><br>";
                isd = 1;
                foreach (var item in listNotKicked)
                {
                    if (users_names_vk.ContainsKey("id" + item))
                    {
                        if (item < 0)
                        {
                            text = text + isd + ". [club" + item.ToString().Substring(1) + "|" + users_names_vk["id" + item.ToString()].first_name + " " +
                                users_names_vk["id" + item].last_name + "]<br>";
                        }
                        else
                        {
                            text = text + isd + ". [id" + item + "|" + users_names_vk["id" + item].first_name + " " +
                                users_names_vk["id" + item].last_name + "]<br>";
                        }
                    }
                    else
                    {
                        continue;
                    }
                    isd++;
                }
                Vk.MessagesSend(text, 0);

                //Vk.MessagesSend(nickname[Vk.m_from_id.ToString()] + $" установил проверку на вступление в [club{args[0].Substring(1)}|паблик].");
                //db.peersSetGroup(Vk.m_peer_id, long.Parse(args[0].Substring(1)));
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_inactive()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 80, "inactive"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "inactive", 5))
                {
                    return;
                }

                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("Необходимо указать, за какой период нужно показать/исключить неактивных пользователей.<br><br>" +
                        "Пример: !неактив 3");
                    return;
                }


                var type = "watch";

                int targetDays = 0;

                var splitArgs = args[0].Split(" ");
                if (splitArgs.Length > 1)
                {
                    if (splitArgs[1] != null && splitArgs[1] == "kick")
                    {
                        type = "kick";
                    }

                    try
                    {
                        targetDays = int.Parse(splitArgs[0]);
                    }
                    catch
                    {

                    }
                }
                else
                {
                    try
                    {
                        targetDays = int.Parse(args[0]);
                    }
                    catch
                    {

                    }
                }

                if (targetDays <= 1 || targetDays > 30)
                {
                    Vk.MessagesSend("Необходимо указать, за какой период нужно показать/исключить неактивных пользователей (от 2 до 30).<br><br>" +
                        "Пример: !неактив 3");
                    return;
                }

                string method = "messages.getConversationMembers";
                Dictionary<string, string> paramesd = new()
                    {
                        { "peer_id", Vk.m_peer_id.ToString() }
                    };
                var membersPeers = await Vk.VkAPI(method, paramesd);

                if (membersPeers.ContainsKey("error") || !membersPeers.ContainsKey("response"))
                {
                    Vk.MessagesSend("Ошибка обработки команды — возможно, у бота нет прав администратора в беседе.");
                    return;
                }

                long[] userids = new long[membersPeers["response"]["items"].Count()];
                long i = 0;
                foreach (var upd in membersPeers["response"]["items"])
                {
                    var id = (int)upd["member_id"];
                    if (id < 0)
                    {
                        continue;
                    }
                    userids[i] = id;
                    i++;
                }

                var dateMinimum = DateTimeOffset.Now.AddDays(targetDays * -1);

                List<long> usersForKick = new();
                foreach (var user in userids)
                {
                    if (user <= 0)
                    {
                        continue;
                    }
                    var userActiv = db.statsGetActiveUsers(Vk.m_peer_id, user);
                    var userPeer = db.peersGetMember(Vk.m_peer_id, user, false);

                    if (userPeer["priority"] != "0")
                    {
                        continue;
                    }

                    if (db.statsGetStatUserPeerCache(Vk.m_peer_id, user) != null)
                    {
                        continue;
                    }

                    if (db.timeGetForMysql(userPeer["date_reg"]) >= dateMinimum)
                    {
                        continue;
                    }

                    if (userActiv == null || userActiv.Count <= 0)
                    {
                        usersForKick.Add(user);
                        continue;
                    }
                    if (userActiv[0] == null)
                    {
                        
                        usersForKick.Add(user);
                        continue;
                    }

                    if (db.timeGetForMysql(userActiv[0]["auto_data"]) < dateMinimum)
                    {
                        usersForKick.Add(user);
                        continue;
                    }
                }

                if (type == "kick")
                {
                    if (usersForKick.Count > 30)
                    {
                        Vk.MessagesSend("Нельзя использовать команду, если обнаружено более чем 30 неактивных пользователей.");
                        return;
                    }

                    var nickAdmin = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });
                    Vk.MessagesSend($"{nickAdmin[Vk.m_from_id.ToString()]} инициировал исключение неактивных участников за '{targetDays}' дней.<br>" +
                        $"Бот начал исключение и автоматически оповестит вас по окончании работ.");
                    foreach (var user in usersForKick)
                    {
                        await Vk.KickUser(Vk.m_peer_id, user);
                        Thread.Sleep(100);
                    }
                    Vk.MessagesSend($"{nickAdmin[Vk.m_from_id.ToString()]} инициировал исключение неактивных участников за '{targetDays}' дней.<br>" +
                        $"Бот закончил исключение неактивных участников.");
                }
                else
                {
                    if (usersForKick.Count <= 0)
                    {
                        Vk.MessagesSend("Нет пользователей, не проявлявших активности за указанный период.");
                        return;
                    }
                    var users_names_vk = await Vk.UsersGetVkInfo(usersForKick.ToArray());

                    string text = "Список на исключение из беседы:<br><br>";
                    if (usersForKick.Count > 30)
                    {
                        text += "Обратите внимание, этот список более 30 человек, поэтому в целях безопасности команду нельзя использовать.<br><br>";
                    }

                    

                    long isd = 1;
                    foreach (var item in usersForKick)
                    {
                        if (users_names_vk.ContainsKey("id" + item))
                        {
                            if (item < 0)
                            {
                                text = text + isd + ". [club" + item.ToString().Substring(1) + "|" + users_names_vk["id" + item.ToString()].first_name + " " +
                                    users_names_vk["id" + item].last_name + "]<br>";
                            }
                            else
                            {
                                text = text + isd + ". [id" + item + "|" + users_names_vk["id" + item].first_name + " " +
                                    users_names_vk["id" + item].last_name + "]<br>";
                            }
                        }
                        else
                        {
                            continue;
                        }
                        isd++;
                    
                    }
                    var buttons = Vk.GenerateKeyboard(
                        new string[] { "исключить" }, new string[] { $"inactive {targetDays} kick" }, new string[] { Vk.BUTTON_RED });
                    Vk.MessagesSend(text, 1, 0, buttons);
                    return;

                }

                /*var dbhNonactiveUsers = null;

                var users_names_vk = await Vk.UsersGetVkInfo(listUsersNotPeer.ToArray());

                string text = "Список на исключение из группы участников:<br><br>";
                long isd = 1;
                foreach (var item in listUsersNotPeer)
                {
                    if (users_names_vk.ContainsKey("id" + item))
                    {
                        if (item < 0)
                        {
                            text = text + isd + ". [club" + item.ToString().Substring(1) + "|" + users_names_vk["id" + item.ToString()].first_name + " " +
                                users_names_vk["id" + item].last_name + "]<br>";
                        }
                        else
                        {
                            text = text + isd + ". [id" + item + "|" + users_names_vk["id" + item].first_name + " " +
                                users_names_vk["id" + item].last_name + "]<br>";
                        }
                    }
                    else
                    {
                        continue;
                    }
                    isd++;
                }

                int time_elaps = 2 * listUsersNotPeer.Count();
                string time_text = time_elaps.ToString() + " секунд.";

                if (args[0] != "kick")
                {
                    text += "<br>Примерное время ожидания: " + time_text;
                    var buttons = Vk.GenerateKeyboard(new string[] { "начать" }, new string[] { "kickgroup kick" }, new string[]
                        { Vk.BUTTON_RED });
                    Vk.MessagesSend(text, 1, 0, buttons);
                    return;
                }
                else
                {
                    text += "<br>Пожалуйста, подождите. По окончании работы бот оповестит вас об этом в конференцию." +
                    "<br>Примерное время ожидания: " + time_text;
                    Vk.MessagesSend(text);
                }



                method = "groups.removeUser";
                var parms = new Dictionary<string, string>()
                {
                    { "group_id", Target_Peer["group"] },
                    { "access_token", Target_Peer["access_token"] }
                };

                List<long> listNotKicked = new();

                foreach (var item in listUsersNotPeer)
                {
                    parms["user_id"] = item.ToString();
                    var res = await Vk.VkAPIs(method, parms);
                    if (res.ContainsKey("error"))
                    {
                        if (res["error"]["error_code"] != null)
                        {
                            var code = res["error"]["error_code"];
                            if (code.ToString() == "5")
                            {
                                Vk.MessagesSend("Ошибка исключения участника из группы — токен доступа недействителен, " +
                                    "поэтому он был отвязан от беседы, удаление участников остановлено.");
                                return;
                            }
                        }
                        listNotKicked.Add(item);
                    }
                    Thread.Sleep(2000);
                }

                if (listNotKicked.Count <= 0)
                {
                    Vk.MessagesSend("Все вышеперечисленные участники были исключены из группы.");
                    return;
                }

                //users_names_vk = await Vk.UsersGetVkInfo(listNotKicked.ToArray());
                text = "Произошла ошибка и участники не были исключены:<br><br>";
                isd = 1;
                foreach (var item in listNotKicked)
                {
                    if (users_names_vk.ContainsKey("id" + item))
                    {
                        if (item < 0)
                        {
                            text = text + isd + ". [club" + item.ToString().Substring(1) + "|" + users_names_vk["id" + item.ToString()].first_name + " " +
                                users_names_vk["id" + item].last_name + "]<br>";
                        }
                        else
                        {
                            text = text + isd + ". [id" + item + "|" + users_names_vk["id" + item].first_name + " " +
                                users_names_vk["id" + item].last_name + "]<br>";
                        }
                    }
                    else
                    {
                        continue;
                    }
                    isd++;
                }
                Vk.MessagesSend(text, 0);

                //Vk.MessagesSend(nickname[Vk.m_from_id.ToString()] + $" установил проверку на вступление в [club{args[0].Substring(1)}|паблик].");
                //db.peersSetGroup(Vk.m_peer_id, long.Parse(args[0].Substring(1)));*/
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }
    }
}
