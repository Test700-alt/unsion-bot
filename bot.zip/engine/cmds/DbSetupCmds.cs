using GrandManager.engine.dbtools;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace GrandManager.engine.cmds
{
    internal class DbSetupCmds
    {
        private static readonly ConcurrentDictionary<long, SetupSession> _sessions = new();

        private class SetupSession
        {
            public string Scene { get; set; } = "";
            public string Step { get; set; } = "";
            public Dictionary<string, string> Data { get; set; } = new();
            public long ExpiresAt { get; set; }
        }

        private static long NowMs() => DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

        private static SetupSession GetSession(long userId)
        {
            if (_sessions.TryGetValue(userId, out var s) && s.ExpiresAt > NowMs())
                return s;
            _sessions.TryRemove(userId, out _);
            return null;
        }

        private static void SetSession(long userId, string scene, string step, Dictionary<string, string> data)
        {
            _sessions[userId] = new SetupSession
            {
                Scene = scene,
                Step = step,
                Data = data,
                ExpiresAt = NowMs() + 300_000
            };
        }

        private static void ClearSession(long userId) => _sessions.TryRemove(userId, out _);

        public static void CancelDbSetup(vk Vk, long peerId, long userId)
        {
            if (GetSession(userId) != null)
            {
                ClearSession(userId);
                string kb = Vk.GenerateKeyboard(new string[] { }, new string[] { }, new string[] { }, new int[] { }, true, false);
                Vk.MessagesSend("❌ Настройка отменена.", 0, peerId, kb);
            }
        }

        public static void HandleDbSetupPeer(vk Vk, Database db, long peerId, long userId, long targetPeerId)
        {
            var session = GetSession(userId);
            if (session == null || session.Scene != "db_setup" || session.Step != "select_peer")
            {
                return;
            }

            var ownerId = db.peersGetOwner(targetPeerId);
            if (ownerId != userId)
            {
                Vk.MessagesSend("⚠️ Вы не являетесь владельцем этой беседы.", 0, peerId);
                return;
            }

            SetSession(userId, "db_setup", "enter_type", new Dictionary<string, string> { { "peer_id", targetPeerId.ToString() } });
            string kb = Vk.GenerateKeyboard(new string[] { "Отмена" }, new string[] { "dbsetup_cancel" }, new string[] { Vk.BUTTON_RED }, null, false, true, false);
            Vk.MessagesSend(
                "🔌 Настройка подключения к БД (Беседа " + targetPeerId + ")\n\n" +
                "Выберите тип базы данных:\n" +
                "• mysql — MySQL/MariaDB\n" +
                "• postgres — PostgreSQL\n\n" +
                "Введите тип: mysql или postgres", 0, peerId, kb);
        }

        public static bool HasActiveSession(long userId) => GetSession(userId) != null;

        public static async void StartDbSetup(vk Vk, Database db, long peerId, long userId)
        {
            if (!settings.isPeer(peerId))
            {
                var userPeers = db.peersGetForOwner(userId);
                if (userPeers == null || userPeers.Count == 0)
                {
                    Vk.MessagesSend("⚠️ У вас нет бесед, где вы являетесь владельцем.", 0, peerId);
                    return;
                }

                if (userPeers.Count == 1)
                {
                    long targetPeerId = userPeers[0];
                    StartDbSetupForPeer(Vk, db, targetPeerId, userId);
                    return;
                }

                SetSession(userId, "db_setup", "select_peer", new Dictionary<string, string>());

                string text = "🔌 Выберите беседу для настройки БД:\n\n";
                var btnNames = new List<string>();
                var btnCmds = new List<string>();
                var btnColors = new List<string>();
                var btnLines = new List<int>();

                for (int i = 0; i < userPeers.Count; i++)
                {
                    text += $"{i + 1}. Беседа ID: {userPeers[i]}\n";
                    btnNames.Add((i + 1).ToString());
                    btnCmds.Add("dbsetup_peer " + userPeers[i]);
                    btnColors.Add(Vk.BUTTON_WHITE);
                    btnLines.Add(i);
                }

                btnNames.Add("Отмена");
                btnCmds.Add("dbsetup_cancel");
                btnColors.Add(Vk.BUTTON_RED);
                btnLines.Add(userPeers.Count);

                string kb = Vk.GenerateKeyboard(btnNames.ToArray(), btnCmds.ToArray(), btnColors.ToArray(), btnLines.ToArray(), false, true, false);
                Vk.MessagesSend(text, 0, peerId, kb);
                return;
            }

            // В беседе — сразу настройка
            StartDbSetupForPeer(Vk, db, peerId, userId);
        }

        private static void StartDbSetupForPeer(vk Vk, Database db, long peerId, long userId)
        {
            var ownerId = db.peersGetOwner(peerId);
            if (ownerId != userId)
            {
                Vk.MessagesSend("🔒 Настройка БД доступна только владельцу беседы.", 0, peerId);
                return;
            }

            SetSession(userId, "db_setup", "enter_type", new Dictionary<string, string> { { "peer_id", peerId.ToString() } });

            string kb = Vk.GenerateKeyboard(new string[] { "Отмена" }, new string[] { "dbsetup_cancel" }, new string[] { Vk.BUTTON_RED }, null, false, true, false);
            Vk.MessagesSend(
                "🔌 Настройка подключения к БД\n\n" +
                "Выберите тип базы данных:\n" +
                "• mysql — MySQL/MariaDB\n" +
                "• postgres — PostgreSQL\n\n" +
                "Введите тип: mysql или postgres", 0, peerId, kb);
        }

        public static async Task<bool> HandleDbSetup(vk Vk, Database db, long peerId, long userId, string text)
        {
            var session = GetSession(userId);
            if (session == null || session.Scene != "db_setup") return false;

            var data = session.Data;

            switch (session.Step)
            {
                case "select_peer":
                    return HandleSelectPeer(Vk, db, peerId, userId, text, data);
                case "enter_type":
                    return await HandleEnterType(Vk, peerId, userId, text, data);
                case "enter_host":
                    return await HandleEnterHost(Vk, peerId, userId, text, data);
                case "enter_port":
                    return await HandleEnterPort(Vk, peerId, userId, text, data);
                case "enter_database":
                    return await HandleEnterDatabase(Vk, peerId, userId, text, data);
                case "enter_username":
                    return await HandleEnterUsername(Vk, peerId, userId, text, data);
                case "enter_password":
                    return await HandleEnterPassword(Vk, peerId, userId, text, data);
                case "confirm":
                    return await HandleConfirmDb(Vk, db, peerId, userId, text, data);
                default:
                    return false;
            }
        }

        private static bool HandleSelectPeer(vk Vk, Database db, long peerId, long userId, string text, Dictionary<string, string> data)
        {
            text = text.Trim();
            if (text == "отмена" || text == "cancel")
            {
                ClearSession(userId);
                string kbCancel = Vk.GenerateKeyboard(new string[] { }, new string[] { }, new string[] { }, new int[] { }, true, false);
                Vk.MessagesSend("❌ Настройка отменена.", 0, peerId, kbCancel);
                return true;
            }

            long targetPeerId = 0;
            if (long.TryParse(text, out targetPeerId))
            {
                var ownerId = db.peersGetOwner(targetPeerId);
                if (ownerId != userId)
                {
                    Vk.MessagesSend("⚠️ Вы не являетесь владельцем этой беседы. Введите другой ID:", 0, peerId);
                    return true;
                }
            }
            else
            {
                Vk.MessagesSend("⚠️ Введите числовой ID беседы:", 0, peerId);
                return true;
            }

            // Начинаем настройку для выбранной беседы
            SetSession(userId, "db_setup", "enter_type", new Dictionary<string, string> { { "peer_id", targetPeerId.ToString() } });
            string kb = Vk.GenerateKeyboard(new string[] { "Отмена" }, new string[] { "dbsetup_cancel" }, new string[] { Vk.BUTTON_RED }, null, false, true, false);
            Vk.MessagesSend(
                "🔌 Настройка подключения к БД (Беседа " + targetPeerId + ")\n\n" +
                "Выберите тип базы данных:\n" +
                "• mysql — MySQL/MariaDB\n" +
                "• postgres — PostgreSQL\n\n" +
                "Введите тип: mysql или postgres", 0, peerId, kb);
            return true;
        }

        private static async Task<bool> HandleEnterType(vk Vk, long peerId, long userId, string text, Dictionary<string, string> data)
        {
            text = text.Trim().ToLower();
            if (text != "mysql" && text != "postgres")
            {
                Vk.MessagesSend("⚠️ Введите mysql или postgres:", 0, peerId);
                return true;
            }

            data["db_type"] = text;
            data["default_port"] = text == "mysql" ? "3306" : "5432";
            SetSession(userId, "db_setup", "enter_host", data);

            string kb = Vk.GenerateKeyboard(new string[] { "Отмена" }, new string[] { "dbsetup_cancel" }, new string[] { Vk.BUTTON_RED }, null, false, true, false);
            Vk.MessagesSend($"✅ Тип: {text.ToUpper()}\n\n📡 Введите хост (IP или домен):\nПример: 127.0.0.1 или db.example.com", 0, peerId, kb);
            return true;
        }

        private static async Task<bool> HandleEnterHost(vk Vk, long peerId, long userId, string text, Dictionary<string, string> data)
        {
            text = text.Trim();
            if (string.IsNullOrEmpty(text) || text.Length > 255)
            {
                Vk.MessagesSend("⚠️ Некорректный хост. Попробуйте ещё:", 0, peerId);
                return true;
            }

            data["host"] = text;
            SetSession(userId, "db_setup", "enter_port", data);

            string kb = Vk.GenerateKeyboard(new string[] { "Отмена" }, new string[] { "dbsetup_cancel" }, new string[] { Vk.BUTTON_RED }, null, false, true, false);
            Vk.MessagesSend($"✅ Хост: {text}\n\n🔢 Введите порт (по умолчанию {data["default_port"]}):", 0, peerId, kb);
            return true;
        }

        private static async Task<bool> HandleEnterPort(vk Vk, long peerId, long userId, string text, Dictionary<string, string> data)
        {
            text = text.Trim();
            if (!int.TryParse(text, out int port) || port < 1 || port > 65535)
            {
                Vk.MessagesSend("⚠️ Некорректный порт. Введите число от 1 до 65535:", 0, peerId);
                return true;
            }

            data["port"] = port.ToString();
            SetSession(userId, "db_setup", "enter_database", data);

            string kb = Vk.GenerateKeyboard(new string[] { "Отмена" }, new string[] { "dbsetup_cancel" }, new string[] { Vk.BUTTON_RED }, null, false, true, false);
            Vk.MessagesSend($"✅ Порт: {port}\n\n🗄 Введите имя базы данных:", 0, peerId, kb);
            return true;
        }

        private static async Task<bool> HandleEnterDatabase(vk Vk, long peerId, long userId, string text, Dictionary<string, string> data)
        {
            text = text.Trim();
            if (!Regex.IsMatch(text, @"^[a-zA-Z_][a-zA-Z0-9_]{0,63}$"))
            {
                Vk.MessagesSend("⚠️ Некорректное имя БД (латиница, цифры, _):", 0, peerId);
                return true;
            }

            data["database"] = text;
            SetSession(userId, "db_setup", "enter_username", data);

            string kb = Vk.GenerateKeyboard(new string[] { "Отмена" }, new string[] { "dbsetup_cancel" }, new string[] { Vk.BUTTON_RED }, null, false, true, false);
            Vk.MessagesSend($"✅ База данных: {text}\n\n👤 Введите логин для подключения:", 0, peerId, kb);
            return true;
        }

        private static async Task<bool> HandleEnterUsername(vk Vk, long peerId, long userId, string text, Dictionary<string, string> data)
        {
            text = text.Trim();
            if (string.IsNullOrEmpty(text) || text.Length > 100)
            {
                Vk.MessagesSend("⚠️ Введите корректное имя пользователя:", 0, peerId);
                return true;
            }

            data["username"] = text;
            SetSession(userId, "db_setup", "enter_password", data);

            string kb = Vk.GenerateKeyboard(new string[] { "Отмена" }, new string[] { "dbsetup_cancel" }, new string[] { Vk.BUTTON_RED }, null, false, true, false);
            Vk.MessagesSend($"✅ Пользователь: {text}\n\n🔑 Введите пароль:", 0, peerId, kb);
            return true;
        }

        private static async Task<bool> HandleEnterPassword(vk Vk, long peerId, long userId, string text, Dictionary<string, string> data)
        {
            if (string.IsNullOrEmpty(text))
            {
                string kbErr = Vk.GenerateKeyboard(new string[] { "Отмена" }, new string[] { "dbsetup_cancel" }, new string[] { Vk.BUTTON_RED }, null, false, true, false);
                Vk.MessagesSend("⚠️ Пароль не может быть пустым:", 0, peerId, kbErr);
                return true;
            }

            data["password"] = text;
            SetSession(userId, "db_setup", "confirm", data);

            string kb = Vk.GenerateKeyboard(new string[] { "Отмена" }, new string[] { "dbsetup_cancel" }, new string[] { Vk.BUTTON_RED }, null, false, true, false);
            Vk.MessagesSend(
                "📋 Проверьте данные:\n\n" +
                $"🔹 Тип: {data["db_type"].ToUpper()}\n" +
                $"🔹 Хост: {data["host"]}:{data["port"]}\n" +
                $"🔹 БД: {data["database"]}\n" +
                $"🔹 Пользователь: {data["username"]}\n" +
                $"🔹 Пароль: {new string('*', Math.Min(text.Length, 8))}\n\n" +
                "Всё верно? Напишите «да» для проверки подключения или «отмена»:", 0, peerId, kb);
            return true;
        }

        private static async Task<bool> HandleConfirmDb(vk Vk, Database db, long peerId, long userId, string text, Dictionary<string, string> data)
        {
            string normalized = text.Trim().ToLower();

            // Убираем все кавычки и спецсимволы, которые VK может добавить
            normalized = normalized.Replace("\u00ab", "").Replace("\u00bb", ""); // «»
            normalized = normalized.Replace("\"", "").Replace("'", "");
            normalized = normalized.Trim();

            if (normalized == "отмена" || normalized == "cancel")
            {
                ClearSession(userId);
                string kbCancel = Vk.GenerateKeyboard(new string[] { }, new string[] { }, new string[] { }, new int[] { }, true, false);
                Vk.MessagesSend("❌ Настройка отменена.", 0, peerId, kbCancel);
                return true;
            }

            if (normalized != "да" && normalized != "yes" && normalized != "lf")
            {
                string kbErr = Vk.GenerateKeyboard(new string[] { "Отмена" }, new string[] { "dbsetup_cancel" }, new string[] { Vk.BUTTON_RED }, null, false, true, false);
                Vk.MessagesSend($"⚠️ Напишите «да» или «отмена» (получено: «{normalized}»):", 0, peerId, kbErr);
                return true;
            }

            Vk.MessagesSend("⏳ Проверяю подключение...", 0, peerId);

            var creds = new ExternalDbCredentials
            {
                DbType = data["db_type"],
                Host = data["host"],
                Port = int.Parse(data["port"]),
                Database = data["database"],
                Username = data["username"],
                Password = data["password"]
            };

            var (ok, error) = await ExternalDbManager.TestConnection(creds);
            if (!ok)
            {
                Vk.MessagesSend($"❌ Не удалось подключиться:\n{error}\n\nПроверьте данные.\nНапишите !подключить для повторной настройки.", 0, peerId);
                ClearSession(userId);
                return true;
            }

            try
            {
                long peerIdVal = long.Parse(data["peer_id"]);
                string passwordEnc = SysUtils.EncryptString(data["password"]);

                db.executeQuery(
                    "INSERT INTO external_db_connections (peer_id, db_type, host, port, database_name, username, password_enc) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?) " +
                    "ON DUPLICATE KEY UPDATE db_type=?, host=?, port=?, database_name=?, username=?, password_enc=?, date_updated=NOW()",
                    peerIdVal, data["db_type"], data["host"], int.Parse(data["port"]),
                    data["database"], data["username"], passwordEnc,
                    data["db_type"], data["host"], int.Parse(data["port"]),
                    data["database"], data["username"], passwordEnc);

                ClearSession(userId);

                Vk.MessagesSend(
                    "✅ База данных подключена!\n\n" +
                    "Теперь настройте таблицу — напишите:\n" +
                    "!маппинг\n\n" +
                    "Для справки: !db помощь", 0, peerId);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[DB_SETUP SAVE ERROR] {ex}");
                Vk.MessagesSend($"❌ Ошибка сохранения: {ex.Message}", 0, peerId);
                ClearSession(userId);
            }
            return true;
        }


        public static async void StartMappingSetup(vk Vk, Database db, long peerId, long userId)
        {
            if (!settings.isPeer(peerId))
            {
                Vk.MessagesSend("⚠️ Только в беседах.", 0, peerId);
                return;
            }

            var creds = LoadCreds(db, peerId);
            if (creds == null)
            {
                Vk.MessagesSend("⚠️ Сначала подключите БД командой !подключить", 0, peerId);
                return;
            }

            var ownerId = db.peersGetOwner(peerId);
            if (ownerId != userId)
            {
                Vk.MessagesSend("🔒 Только владелец беседы.", 0, peerId);
                return;
            }

            Vk.MessagesSend("⏳ Загружаю список таблиц...", 0, peerId);

            try
            {
                var tables = await QueryExecutor.GetTablesList(peerId, creds);
                if (tables.Count == 0)
                {
                    Vk.MessagesSend("⚠️ В БД нет таблиц.", 0, peerId);
                    return;
                }

                var tableNames = tables.Select(t => t["name"]?.ToString() ?? "").ToList();
                SetSession(userId, "mapping_setup", "enter_table", new Dictionary<string, string>
                {
                    { "peer_id", peerId.ToString() },
                    { "tables", string.Join(",", tableNames) }
                });

                var lines = new List<string> { $"📊 Найдено таблиц: {tables.Count}", "" };
                for (int i = 0; i < Math.Min(tableNames.Count, 30); i++)
                    lines.Add($"{i + 1}. {tableNames[i]}");
                if (tableNames.Count > 30)
                    lines.Add($"... и ещё {tableNames.Count - 30}");
                lines.Add("");
                lines.Add("Введите имя таблицы:");

                Vk.MessagesSend(string.Join("\n", lines), 0, peerId);
            }
            catch (Exception ex)
            {
                Vk.MessagesSend($"❌ Ошибка загрузки таблиц: {ex.Message}", 0, peerId);
            }
        }

        public static async Task<bool> HandleMappingSetup(vk Vk, Database db, long peerId, long userId, string text)
        {
            var session = GetSession(userId);
            if (session == null || session.Scene != "mapping_setup") return false;

            var data = session.Data;
            var creds = LoadCreds(db, peerId);

            switch (session.Step)
            {
                case "enter_table":
                    {
                        text = text.Trim();
                        if (!Regex.IsMatch(text, @"^[a-zA-Z_][a-zA-Z0-9_]{0,63}$"))
                        {
                            Vk.MessagesSend("⚠️ Некорректное имя таблицы:", 0, peerId);
                            return true;
                        }

                        bool exists = await QueryExecutor.TableExists(peerId, creds, text);
                        if (!exists)
                        {
                            Vk.MessagesSend($"⚠️ Таблица «{text}» не найдена:", 0, peerId);
                            return true;
                        }

                        var columns = await QueryExecutor.GetTableColumns(peerId, creds, text);
                        data["table_name"] = text;
                        data["columns"] = string.Join(",", columns.Select(c => c["name"]?.ToString()));

                        SetSession(userId, "mapping_setup", "enter_search_column", data);

                        var colLines = new List<string> { $"✅ Таблица: {text}", "", "Колонки:" };
                        foreach (var col in columns)
                            colLines.Add($"  • {col["name"]} ({col["type"]})");
                        colLines.Add("");
                        colLines.Add("🔍 Введите имя колонки для ПОИСКА (обычно никнейм):");

                        Vk.MessagesSend(string.Join("\n", colLines), 0, peerId);
                        return true;
                    }

                case "enter_search_column":
                    {
                        text = text.Trim();
                        if (!Regex.IsMatch(text, @"^[a-zA-Z_][a-zA-Z0-9_]{0,63}$"))
                        {
                            Vk.MessagesSend("⚠️ Некорректное имя колонки:", 0, peerId);
                            return true;
                        }

                        bool exists = await QueryExecutor.ColumnExists(peerId, creds, data["table_name"], text);
                        if (!exists)
                        {
                            Vk.MessagesSend($"⚠️ Колонка «{text}» не найдена:", 0, peerId);
                            return true;
                        }

                        data["search_column"] = text;
                        SetSession(userId, "mapping_setup", "enter_alias", data);

                        Vk.MessagesSend(
                            $"✅ Колонка поиска: {text}\n\n" +
                            "✏️ Придумайте короткое имя (алиас) для этой привязки.\n" +
                            "Пример: accounts, players, admins", 0, peerId);
                        return true;
                    }

                case "enter_alias":
                    {
                        text = text.Trim().ToLower();
                        if (!Regex.IsMatch(text, @"^[a-zA-Zа-яА-ЯёЁ0-9_-]{1,50}$"))
                        {
                            Vk.MessagesSend("⚠️ Алиас: 1-50 символов (буквы, цифры, _, -):", 0, peerId);
                            return true;
                        }

                        data["alias"] = text;

                        db.executeQuery(
                            "INSERT INTO table_mappings (peer_id, alias, table_name, search_column) VALUES (?, ?, ?, ?) " +
                            "ON DUPLICATE KEY UPDATE table_name=?, search_column=?",
                            peerId, data["alias"], data["table_name"], data["search_column"],
                            data["table_name"], data["search_column"]);

                        ClearSession(userId);

                        Vk.MessagesSend(
                            $"✅ Привязка «{data["alias"]}» создана!\n\n" +
                            $"Таблица: {data["table_name"]}\n" +
                            $"Поиск по: {data["search_column"]}\n\n" +
                            "Теперь создайте команду: !создать", 0, peerId);
                        return true;
                    }

                default:
                    return false;
            }
        }


        public static async void StartCommandSetup(vk Vk, Database db, long peerId, long userId)
        {
            if (!settings.isPeer(peerId))
            {
                Vk.MessagesSend("⚠️ Только в беседах.", 0, peerId);
                return;
            }

            var ownerId = db.peersGetOwner(peerId);
            if (ownerId != userId)
            {
                Vk.MessagesSend("🔒 Только владелец беседы.", 0, peerId);
                return;
            }

            var mappings = LoadMappings(db, peerId);
            if (mappings.Count == 0)
            {
                Vk.MessagesSend("⚠️ Сначала настройте таблицу: !маппинг", 0, peerId);
                return;
            }

            SetSession(userId, "cmd_setup", "select_mapping", new Dictionary<string, string> { { "peer_id", peerId.ToString() } });

            var lines = new List<string> { "🎮 Создание команды", "", "Выберите привязку таблицы:" };
            foreach (var m in mappings)
                lines.Add($"  • {m["alias"]} (таблица: {m["table_name"]})");
            lines.Add("");
            lines.Add("Введите алиас привязки:");

            Vk.MessagesSend(string.Join("\n", lines), 0, peerId);
        }

        public static async Task<bool> HandleCommandSetup(vk Vk, Database db, long peerId, long userId, string text)
        {
            var session = GetSession(userId);
            if (session == null || session.Scene != "cmd_setup") return false;

            var data = session.Data;
            var creds = LoadCreds(db, peerId);

            switch (session.Step)
            {
                case "select_mapping":
                    {
                        text = text.Trim().ToLower();
                        var mappings = LoadMappings(db, peerId);
                        var mapping = mappings.FirstOrDefault(m => m["alias"] == text);

                        if (mapping == null)
                        {
                            Vk.MessagesSend("⚠️ Привязка не найдена. Введите алиас из списка:", 0, peerId);
                            return true;
                        }

                        data["mapping_id"] = mapping["id"].ToString();
                        data["mapping_alias"] = mapping["alias"];
                        data["table_name"] = mapping["table_name"];
                        data["search_column"] = mapping["search_column"];

                        var columns = await QueryExecutor.GetTableColumns(peerId, creds, data["table_name"]);
                        data["available_columns"] = string.Join(",", columns.Select(c => c["name"]?.ToString()));

                        SetSession(userId, "cmd_setup", "select_column", data);

                        var colLines = new List<string> { $"✅ Привязка: {mapping["alias"]}", "", "Колонки таблицы:" };
                        foreach (var col in columns)
                            colLines.Add($"  • {col["name"]} ({col["type"]})");
                        colLines.Add("");
                        colLines.Add("🎯 Введите колонку, которую команда будет ИЗМЕНЯТЬ:");

                        Vk.MessagesSend(string.Join("\n", colLines), 0, peerId);
                        return true;
                    }

                case "select_column":
                    {
                        text = text.Trim();
                        if (!Regex.IsMatch(text, @"^[a-zA-Z_][a-zA-Z0-9_]{0,63}$"))
                        {
                            Vk.MessagesSend("⚠️ Некорректное имя колонки:", 0, peerId);
                            return true;
                        }

                        bool exists = await QueryExecutor.ColumnExists(peerId, creds, data["table_name"], text);
                        if (!exists)
                        {
                            Vk.MessagesSend($"⚠️ Колонка «{text}» не найдена:", 0, peerId);
                            return true;
                        }

                        data["target_column"] = text;
                        SetSession(userId, "cmd_setup", "enter_name", data);

                        Vk.MessagesSend(
                            $"✅ Целевая колонка: {text}\n\n" +
                            "✏️ Введите имя команды (как будут вызывать).\n" +
                            "Пример: админка, бан, деньги", 0, peerId);
                        return true;
                    }

                case "enter_name":
                    {
                        text = text.Trim().ToLower();
                        if (!Regex.IsMatch(text, @"^[a-zA-Zа-яА-ЯёЁ0-9_-]{1,50}$"))
                        {
                            Vk.MessagesSend("⚠️ Имя команды: 1-50 символов:", 0, peerId);
                            return true;
                        }

                        data["command_name"] = text;
                        SetSession(userId, "cmd_setup", "enter_description", data);

                        Vk.MessagesSend(
                            $"✅ Команда: {text}\n\n" +
                            "📝 Введите описание команды:", 0, peerId);
                        return true;
                    }

                case "enter_description":
                    {
                        if (string.IsNullOrEmpty(text) || text.Length > 500)
                        {
                            Vk.MessagesSend("⚠️ Описание: от 1 до 500 символов:", 0, peerId);
                            return true;
                        }

                        data["description"] = text;
                        SetSession(userId, "cmd_setup", "requires_value", data);

                        Vk.MessagesSend(
                            "🔢 Команда требует значение от пользователя?\n\n" +
                            $"Например, «!{data["command_name"]} Nick 5» — значение 5 указывается.\n" +
                            "Если нет — будет фиксированное значение.\n\n" +
                            "Введите «да» или «нет»:", 0, peerId);
                        return true;
                    }

                case "requires_value":
                    {
                        string reqNorm = text.Trim().ToLower()
                            .Replace("\u00ab", "").Replace("\u00bb", "")
                            .Replace("\"", "").Replace("'", "")
                            .Trim();

                        if (reqNorm != "да" && reqNorm != "нет" && reqNorm != "yes" && reqNorm != "no" && reqNorm != "lf" && reqNorm != "ytn")
                        {
                            Vk.MessagesSend("⚠️ Введите «да» или «нет»:", 0, peerId);
                            return true;
                        }

                        bool requiresValue = reqNorm == "да" || reqNorm == "yes" || reqNorm == "lf";
                        data["requires_value"] = requiresValue ? "1" : "0";
                        SetSession(userId, "cmd_setup", "confirm", data);

                        string usage = requiresValue
                            ? $"!{data["command_name"]} [ник] [значение]"
                            : $"!{data["command_name"]} [ник]";

                        Vk.MessagesSend(
                            "📋 Проверьте команду:\n\n" +
                            $"🔹 Команда: !{data["command_name"]}\n" +
                            $"🔹 Описание: {data["description"]}\n" +
                            $"🔹 Привязка: {data["mapping_alias"]}\n" +
                            $"🔹 Изменяет: {data["target_column"]}\n" +
                            $"🔹 Значение: {(requiresValue ? "от пользователя" : "фиксированное")}\n\n" +
                            $"Использование: {usage}\n\n" +
                            "Подтвердите — «да» или «отмена»:", 0, peerId);
                        return true;
                    }

                case "confirm":
                    {
                        string normalized = text.Trim().ToLower()
                            .Replace("\u00ab", "").Replace("\u00bb", "")
                            .Replace("\"", "").Replace("'", "")
                            .Trim();

                        if (normalized == "отмена" || normalized == "cancel")
                        {
                            ClearSession(userId);
                            Vk.MessagesSend("❌ Создание отменено.", 0, peerId);
                            return true;
                        }

                        if (normalized != "да" && normalized != "yes" && normalized != "lf")
                        {
                            Vk.MessagesSend($"⚠️ Напишите «да» или «отмена» (получено: «{normalized}»):", 0, peerId);
                            return true;
                        }

                        try
                        {
                            db.executeQuery(
                                "INSERT INTO custom_commands (peer_id, command_name, mapping_id, target_column, description, requires_value, created_by) " +
                                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                                peerId, data["command_name"], int.Parse(data["mapping_id"]),
                                data["target_column"], data["description"],
                                int.Parse(data["requires_value"]), userId);

                            ClearSession(userId);

                            bool rv = data["requires_value"] == "1";
                            string usage = rv ? $"!{data["command_name"]} [ник] [значение]" : $"!{data["command_name"]} [ник]";

                            Vk.MessagesSend(
                                $"✅ Команда «!{data["command_name"]}» создана!\n\n" +
                                $"Использование: {usage}", 0, peerId);
                        }
                        catch (MySqlException ex) when (ex.Number == 1062)
                        {
                            Vk.MessagesSend("⚠️ Команда с таким именем уже существует.", 0, peerId);
                            SetSession(userId, "cmd_setup", "enter_name", data);
                        }
                        catch (Exception ex)
                        {
                            Vk.MessagesSend($"❌ Ошибка: {ex.Message}", 0, peerId);
                            ClearSession(userId);
                        }
                        return true;
                    }

                default:
                    return false;
            }
        }


        public static async void DeleteCommand(vk Vk, Database db, long peerId, long userId, string cmdName)
        {
            if (!settings.isPeer(peerId)) return;

            var ownerId = db.peersGetOwner(peerId);
            if (ownerId != userId)
            {
                Vk.MessagesSend("🔒 Только владелец беседы.", 0, peerId);
                return;
            }

            int affected = db.executeQuery(
                "DELETE FROM custom_commands WHERE peer_id = ? AND command_name = ?",
                peerId, cmdName.ToLower());

            if (affected > 0)
                Vk.MessagesSend($"🗑 Команда «{cmdName}» удалена.", 0, peerId);
            else
                Vk.MessagesSend($"⚠️ Команда «{cmdName}» не найдена.", 0, peerId);
        }


        public static async void ShowDbStatus(vk Vk, Database db, long peerId)
        {
            if (!settings.isPeer(peerId)) return;

            var creds = LoadCreds(db, peerId);
            var mappings = LoadMappings(db, peerId);
            var commands = LoadCommands(db, peerId);

            if (creds == null)
            {
                Vk.MessagesSend("❌ БД не подключена.\nНапишите !подключить", 0, peerId);
                return;
            }

            var (connected, connError) = await ExternalDbManager.TestConnection(creds);

            Vk.MessagesSend(
                "🔌 Статус подключения\n\n" +
                $"Тип: {creds.DbType.ToUpper()}\n" +
                $"Хост: {creds.Host}:{creds.Port}\n" +
                $"БД: {creds.Database}\n" +
                $"Соединение: {(connected ? "✅ Активно" : "❌ " + connError)}\n\n" +
                $"Таблиц привязано: {mappings.Count}\n" +
                $"Команд создано: {commands.Count}", 0, peerId);
        }


        public static void ShowCommandsList(vk Vk, Database db, long peerId)
        {
            if (!settings.isPeer(peerId)) return;

            var commands = LoadCommands(db, peerId);
            if (commands.Count == 0)
            {
                Vk.MessagesSend("📋 Команды не настроены.\nСоздайте: !создать", 0, peerId);
                return;
            }

            var lines = new List<string> { "📋 Список команд:", "" };
            foreach (var cmd in commands)
            {
                bool rv = cmd["requires_value"]?.ToString() == "1";
                string usage = rv ? $"!{cmd["command_name"]} [ник] [значение]" : $"!{cmd["command_name"]} [ник]";
                lines.Add($"🔹 {usage}");
                lines.Add($"   {cmd["description"]}");
                lines.Add($"   Привязка: {cmd["alias"]}");
                lines.Add("");
            }

            Vk.MessagesSend(string.Join("\n", lines), 0, peerId);
        }

        // ========== ПОМОЩЬ ==========
        public static void ShowDbHelp(vk Vk, long peerId)
        {
            Vk.MessagesSend(
                "📖 Справка по БД командам\n\n" +
                "Настройка:\n" +
                "• !подключить / !connect — подключить БД\n" +
                "• !маппинг / !mapping — привязать таблицу\n" +
                "• !создать / !newcommand — создать команду\n" +
                "• !удалить_кмд / !delcmd [имя] — удалить команду\n\n" +
                "Информация:\n" +
                "• !dbстатус / !dbstatus — статус подключения\n" +
                "• !dbкоманды / !dbcommands — список команд\n" +
                "• !dbпомощь / !dbhelp — эта справка\n\n" +
                "Команды работают с префиксами ! и /\n" +
                "Пример: /connect, !dbstatus, /mapping\n\n" +
                "Использование настроенных команд:\n" +
                "!имя_команды [ник] [значение]", 0, peerId);
        }

        // ========== УТИЛИТЫ ==========
        public static ExternalDbCredentials LoadCreds(Database db, long peerId)
        {
            var rows = db.fetchAll("SELECT * FROM external_db_connections WHERE peer_id = ? LIMIT 1", peerId);
            if (rows == null || rows.Count == 0) return null;

            var row = rows[0];
            string passwordDec = SysUtils.DecryptString(row["password_enc"]?.ToString() ?? "");

            return new ExternalDbCredentials
            {
                DbType = row["db_type"]?.ToString() ?? "",
                Host = row["host"]?.ToString() ?? "",
                Port = int.TryParse(row["port"]?.ToString(), out int p) ? p : 3306,
                Database = row["database_name"]?.ToString() ?? "",
                Username = row["username"]?.ToString() ?? "",
                Password = passwordDec ?? ""
            };
        }

        public static List<Dictionary<string, string>> LoadMappings(Database db, long peerId)
        {
            var rows = db.fetchAll("SELECT * FROM table_mappings WHERE peer_id = ? ORDER BY alias", peerId);
            return rows ?? new List<Dictionary<string, string>>();
        }

        public static List<Dictionary<string, string>> LoadCommands(Database db, long peerId)
        {
            var rows = db.fetchAll(
                "SELECT c.*, m.alias FROM custom_commands c " +
                "LEFT JOIN table_mappings m ON c.mapping_id = m.id " +
                "WHERE c.peer_id = ? ORDER BY c.command_name", peerId);
            return rows ?? new List<Dictionary<string, string>>();
        }

        public static Dictionary<string, string> FindCommand(Database db, long peerId, string cmdName)
        {
            var rows = db.fetchAll(
                "SELECT c.*, m.alias, m.table_name, m.search_column " +
                "FROM custom_commands c " +
                "LEFT JOIN table_mappings m ON c.mapping_id = m.id " +
                "WHERE c.peer_id = ? AND c.command_name = ? LIMIT 1",
                peerId, cmdName.ToLower());
            return rows != null && rows.Count > 0 ? rows[0] : null;
        }
    }
}
