﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine
{
    internal class CpuMemoryMetrics4LinuxUtils
    {
        private const int DigitsInResult = 2;
        private static long totalMemoryInKb;

        [StructLayout(LayoutKind.Sequential)]
        private struct MEMORYSTATUSEX
        {
            public uint dwLength;
            public uint dwMemoryLoad;
            public ulong ullTotalPhys;
            public ulong ullAvailPhys;
            public ulong ullTotalPageFile;
            public ulong ullAvailPageFile;
            public ulong ullTotalVirtual;
            public ulong ullAvailVirtual;
            public ulong ullAvailExtendedVirtual;
        }

        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX lpBuffer);

        public async Task<double> GetOverallCpuUsagePercentage()
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                return await GetCpuUsageWindows();
            }

            var startTime = DateTime.UtcNow;
            var startCpuUsage = GetProcessesCpuTotal();

            await Task.Delay(500);

            var endTime = DateTime.UtcNow;
            var endCpuUsage = GetProcessesCpuTotal();

            var cpuUsedMs = endCpuUsage - startCpuUsage;
            var totalMsPassed = (endTime - startTime).TotalMilliseconds;
            var cpuUsageTotal = cpuUsedMs / (Environment.ProcessorCount * totalMsPassed);

            return Math.Round(cpuUsageTotal * 100, DigitsInResult);
        }

        private static double GetProcessesCpuTotal()
        {
            double total = 0;
            foreach (var proc in Process.GetProcesses())
            {
                try
                {
                    total += proc.TotalProcessorTime.TotalMilliseconds;
                }
                catch
                {
                }
                finally
                {
                    proc.Dispose();
                }
            }
            return total;
        }

        private static async Task<double> GetCpuUsageWindows()
        {
            var startTime = DateTime.UtcNow;
            var startCpuUsage = GetProcessesCpuTotal();

            await Task.Delay(500);

            var endTime = DateTime.UtcNow;
            var endCpuUsage = GetProcessesCpuTotal();

            var cpuUsedMs = endCpuUsage - startCpuUsage;
            var totalMsPassed = (endTime - startTime).TotalMilliseconds;

            if (totalMsPassed <= 0) return 0;

            var cpuUsageTotal = cpuUsedMs / (Environment.ProcessorCount * totalMsPassed);
            return Math.Round(cpuUsageTotal * 100, DigitsInResult);
        }

        public static double GetOccupiedMemoryPercentage()
        {
            var totalMemory = GetTotalMemoryInKb();
            if (totalMemory == 0)
            {
                return 0;
            }
            var usedMemory = GetUsedMemoryInKb();

            var percentage = (usedMemory * 100.0) / totalMemory;
            return Math.Round(percentage, DigitsInResult);
        }

        private static double GetUsedMemoryInKb()
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                long totalKb = GetTotalMemoryInKb();
                long availKb = GetAvailablePhysicalMemoryInKb();
                return totalKb - availKb;
            }

            var totalAllocatedMemoryInBytes = Process.GetProcesses().Sum(a => a.PrivateMemorySize64);
            return totalAllocatedMemoryInBytes / 1024.0;
        }

        private static long GetAvailablePhysicalMemoryInKb()
        {
            MEMORYSTATUSEX memStatus = new();
            memStatus.dwLength = (uint)Marshal.SizeOf(typeof(MEMORYSTATUSEX));

            if (GlobalMemoryStatusEx(ref memStatus))
            {
                return (long)(memStatus.ullAvailPhys / 1024);
            }
            throw new InvalidOperationException("GlobalMemoryStatusEx failed");
        }

        private static long GetTotalMemoryInKb()
        {
            if (totalMemoryInKb > 0)
            {
                return totalMemoryInKb;
            }

            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                MEMORYSTATUSEX memStatus = new();
                memStatus.dwLength = (uint)Marshal.SizeOf(typeof(MEMORYSTATUSEX));

                if (GlobalMemoryStatusEx(ref memStatus))
                {
                    totalMemoryInKb = (long)(memStatus.ullTotalPhys / 1024);
                    return totalMemoryInKb;
                }
                throw new InvalidOperationException("GlobalMemoryStatusEx failed");
            }

            string path = "/proc/meminfo";
            if (!System.IO.File.Exists(path))
            {
                throw new FileNotFoundException($"File not found: {path}");
            }

            using (var reader = new StreamReader(path))
            {
                string line = string.Empty;
                while (!string.IsNullOrWhiteSpace(line = reader.ReadLine()))
                {
                    if (line.Contains("MemTotal", StringComparison.OrdinalIgnoreCase))
                    {
                        var parts = line.Split(':');
                        var valuePart = parts[1].Trim();
                        parts = valuePart.Split(' ');
                        var numberString = parts[0].Trim();

                        var result = long.TryParse(numberString, out totalMemoryInKb);
                        return result ? totalMemoryInKb : 0;
                    }
                }

                return 0;
            }
        }
    }
}
