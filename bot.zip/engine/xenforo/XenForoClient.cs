using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace GrandManager.engine.xenforo
{
    internal class XenForoClient
    {
        private readonly string _url;
        private readonly string _apiKey;
        private readonly long _adminUserId;
        private readonly HttpClient _http;

        public XenForoClient(string url, string apiKey, long adminUserId)
        {
            _url = url.TrimEnd('/');
            _apiKey = apiKey;
            _adminUserId = adminUserId;
            _http = new HttpClient { Timeout = TimeSpan.FromSeconds(15) };
        }

        private Dictionary<string, string> GetHeaders()
        {
            return new Dictionary<string, string>
            {
                { "XF-Api-Key", _apiKey },
                { "XF-Api-User", _adminUserId.ToString() }
            };
        }

        public async Task<(bool success, string error)> TestConnection()
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, $"{_url}/users/{_adminUserId}");
                foreach (var h in GetHeaders())
                    request.Headers.TryAddWithoutValidation(h.Key, h.Value);

                var resp = await _http.SendAsync(request);
                if (resp.IsSuccessStatusCode)
                    return (true, "");

                return (false, $"HTTP {resp.StatusCode}");
            }
            catch (Exception ex)
            {
                return (false, ex.Message);
            }
        }

        public async Task<Dictionary<string, object>> GetUserById(long userId)
        {
            try
            {
                var url = $"{_url}/users/{userId}";
                Console.WriteLine($"[XF] GetUserById request: {url}");
                var request = new HttpRequestMessage(HttpMethod.Get, url);
                foreach (var h in GetHeaders())
                    request.Headers.TryAddWithoutValidation(h.Key, h.Value);

                var resp = await _http.SendAsync(request);
                var body = await resp.Content.ReadAsStringAsync();
                Console.WriteLine($"[XF] GetUserById response ({resp.StatusCode}): {body}");

                if (resp.StatusCode == System.Net.HttpStatusCode.NotFound)
                    return null;

                if (!resp.IsSuccessStatusCode)
                    return null;

                var json = JObject.Parse(body);
                var user = json["user"];
                if (user == null) return null;

                return new Dictionary<string, object>
                {
                    { "user_id", (long)user["user_id"] },
                    { "username", (string)user["username"] },
                    { "user_title", (string)user["user_title"] ?? "Пользователь" },
                    { "message_count", (int)user["message_count"] },
                    { "reaction_score", (int)user["reaction_score"] },
                    { "view_url", (string)user["view_url"] ?? "" },
                    { "user_group_id", (int)user["user_group_id"] },
                    { "secondary_group_ids", user["secondary_group_ids"]?.ToString() ?? "" }
                };
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[XF] GetUserById error: {ex.Message}");
                return null;
            }
        }

        public async Task<Dictionary<string, object>> GetUserByName(string username)
        {
            try
            {
                var url = $"{_url}/users/find?name={Uri.EscapeDataString(username)}";
                Console.WriteLine($"[XF] GetUserByName request: {url}");
                var request = new HttpRequestMessage(HttpMethod.Get, url);
                foreach (var h in GetHeaders())
                    request.Headers.TryAddWithoutValidation(h.Key, h.Value);

                var resp = await _http.SendAsync(request);
                var body = await resp.Content.ReadAsStringAsync();
                Console.WriteLine($"[XF] GetUserByName response ({resp.StatusCode}): {body}");

                if (!resp.IsSuccessStatusCode)
                    return null;

                var json = JObject.Parse(body);
                var user = json["user"];
                if (user == null) return null;

                return new Dictionary<string, object>
                {
                    { "user_id", (long)user["user_id"] },
                    { "username", (string)user["username"] },
                    { "user_title", (string)user["user_title"] ?? "Пользователь" },
                    { "message_count", (int)user["message_count"] },
                    { "reaction_score", (int)user["reaction_score"] },
                    { "view_url", (string)user["view_url"] ?? "" },
                    { "user_group_id", (int)user["user_group_id"] },
                    { "secondary_group_ids", user["secondary_group_ids"]?.ToString() ?? "" }
                };
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[XF] GetUserByName error: {ex.Message}");
                return null;
            }
        }

        public async Task<string> AddGroup(long userId, int groupId)
        {
            try
            {
                var user = await GetUserById(userId);
                if (user == null) return "USER_NOT_FOUND";

                int primary = (int)user["user_group_id"];
                var secondaryStr = user["secondary_group_ids"]?.ToString() ?? "";
                var secondary = new List<int>();
                if (!string.IsNullOrEmpty(secondaryStr))
                {
                    foreach (var s in secondaryStr.Split(','))
                        if (int.TryParse(s.Trim(), out int g)) secondary.Add(g);
                }

                if (primary == groupId) return "ALREADY_PRIMARY";
                if (secondary.Contains(groupId)) return "ALREADY_EXISTS";

                secondary.Add(groupId);

                var form = new FormUrlEncodedContent(new Dictionary<string, string>());
                var content = new MultipartFormDataContent();
                foreach (var g in secondary)
                    content.Add(new StringContent(g.ToString()), "secondary_group_ids[]");

                var request = new HttpRequestMessage(HttpMethod.Post, $"{_url}/users/{userId}")
                {
                    Content = content
                };
                foreach (var h in GetHeaders())
                    request.Headers.TryAddWithoutValidation(h.Key, h.Value);

                var resp = await _http.SendAsync(request);
                return resp.IsSuccessStatusCode ? "OK" : "ERROR";
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[XF] AddGroup error: {ex.Message}");
                return "ERROR";
            }
        }

        public async Task<string> RemoveGroup(long userId, int groupId)
        {
            try
            {
                var user = await GetUserById(userId);
                if (user == null) return "USER_NOT_FOUND";

                int primary = (int)user["user_group_id"];
                var secondaryStr = user["secondary_group_ids"]?.ToString() ?? "";
                var secondary = new List<int>();
                if (!string.IsNullOrEmpty(secondaryStr))
                {
                    foreach (var s in secondaryStr.Split(','))
                        if (int.TryParse(s.Trim(), out int g)) secondary.Add(g);
                }

                if (primary == groupId) return "IS_PRIMARY";
                if (!secondary.Contains(groupId)) return "NOT_IN_GROUP";

                secondary.Remove(groupId);

                var content = new MultipartFormDataContent();
                if (secondary.Count > 0)
                {
                    foreach (var g in secondary)
                        content.Add(new StringContent(g.ToString()), "secondary_group_ids[]");
                }
                else
                {
                    content.Add(new StringContent(""), "secondary_group_ids[]");
                }

                var request = new HttpRequestMessage(HttpMethod.Post, $"{_url}/users/{userId}")
                {
                    Content = content
                };
                foreach (var h in GetHeaders())
                    request.Headers.TryAddWithoutValidation(h.Key, h.Value);

                var resp = await _http.SendAsync(request);
                return resp.IsSuccessStatusCode ? "OK" : "ERROR";
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[XF] RemoveGroup error: {ex.Message}");
                return "ERROR";
            }
        }

        public async Task<List<Dictionary<string, object>>> GetNewThreads(List<int> nodeIds, int lastCheckTs)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, 
                    $"{_url}/threads?order=post_date&direction=desc&limit=10");
                foreach (var h in GetHeaders())
                    request.Headers.TryAddWithoutValidation(h.Key, h.Value);

                var resp = await _http.SendAsync(request);
                if (!resp.IsSuccessStatusCode) return new List<Dictionary<string, object>>();

                var json = JObject.Parse(await resp.Content.ReadAsStringAsync());
                var threads = json["threads"];
                if (threads == null) return new List<Dictionary<string, object>>();

                var result = new List<Dictionary<string, object>>();
                foreach (var t in threads)
                {
                    int postDate = (int)t["post_date"];
                    int nodeId = (int)t["node_id"];

                    if (postDate > lastCheckTs && nodeIds.Contains(nodeId))
                    {
                        result.Add(new Dictionary<string, object>
                        {
                            { "node_id", nodeId },
                            { "title", (string)t["title"] },
                            { "username", (string)t["username"] },
                            { "view_url", (string)t["view_url"] },
                            { "post_date", postDate }
                        });
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[XF] GetNewThreads error: {ex.Message}");
                return new List<Dictionary<string, object>>();
            }
        }

        public async Task<bool> SendPost(int threadId, string message, long specificUserId = 0)
        {
            try
            {
                var headers = GetHeaders();
                if (specificUserId > 0)
                    headers["XF-Api-User"] = specificUserId.ToString();

                var content = new FormUrlEncodedContent(new Dictionary<string, string>
                {
                    { "thread_id", threadId.ToString() },
                    { "message", message }
                });

                var request = new HttpRequestMessage(HttpMethod.Post, $"{_url}/posts") { Content = content };
                foreach (var h in headers)
                    request.Headers.TryAddWithoutValidation(h.Key, h.Value);

                var resp = await _http.SendAsync(request);
                return resp.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[XF] SendPost error: {ex.Message}");
                return false;
            }
        }
    }
}