﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace GrandManager.engine
{
    internal class Games
    {
        public Cache cache;
        public vk Vk;

        public Database dbh;

        public Games(Cache cach, vk Vks, Database dbhs) 
        {
            cache = cach;
            Vk = Vks;
            dbh = dbhs;
        }

        public string buttons_don = "";
        public string buttons_komissar = "";
        public string buttons_doctor = "";
        public string buttons_peoples = "";

        public async Task<string> MafiaGetNotDeadPlayers(Dictionary<long, Dictionary<string, string>> targetUsers)
        {
            
            long[] nicks_get = new long[targetUsers.Count];
            long i = 0;
            foreach (KeyValuePair<long, Dictionary<string, string>> item in targetUsers)
            {
                nicks_get[i] = item.Key;
                i++;
            }

            var nicks = await Vk.UsersGetVkInfo(nicks_get);

            List<string> buttons_live = new();

            List<string> buttons_colors = new();

            List<int> buttonsLines = new();

            int i_button_string = 0;
            int i_button_line = 0;

            List<string> commands_don = new();
            List<string> commands_doctor = new();
            List<string> commands_commisar = new();

            List<string> commands_peoples = new();

            string status_nicks = "";
            foreach (KeyValuePair<long, Dictionary<string, string>> item in targetUsers)
            {
                if (nicks.ContainsKey("id" + item.Key))
                {
                    if (item.Value["role"] != "dead")
                    {
                        status_nicks = status_nicks + "— " + nicks["id" + item.Key.ToString()].first_name + " " +
                            nicks["id" + item.Key.ToString()].last_name + "<br>";
                        buttons_live.Add(nicks["id" + item.Key.ToString()].first_name.Substring(0, 1) + ". " + nicks["id" + item.Key.ToString()].last_name);
                        i_button_string++;
                        if (i_button_string > 3)
                        {
                            i_button_line++;
                            i_button_string = 0;
                        }
                        buttonsLines.Add(i_button_line);
                    }
                }
                else
                {
                    if (item.Value["role"] != "dead")
                    {
                        status_nicks = status_nicks + $"— [id{item.Key}|пользователь]<br>";
                        buttons_live.Add($"[id{item.Key}|пользователь]");
                        i_button_string++;
                        if (i_button_string > 3)
                        {
                            i_button_line++;
                            i_button_string = 0;
                        }
                        buttonsLines.Add(i_button_line);
                    }
                }

                if (item.Value["role"] != "dead")
                {
                    commands_don.Add($"mafia_don id{item.Key}");
                    buttons_colors.Add(Vk.BUTTON_WHITE);
                    commands_doctor.Add($"mafia_doc id{item.Key}");
                    commands_commisar.Add($"mafia_com id{item.Key}");
                    commands_peoples.Add($"mafia_peo id{item.Key}");
                }
            }

            buttons_don = Vk.GenerateKeyboard(buttons_live.ToArray(), commands_don.ToArray(), buttons_colors.ToArray(), buttonsLines.ToArray(), true, false);
            buttons_peoples = Vk.GenerateKeyboard(buttons_live.ToArray(), commands_peoples.ToArray(), buttons_colors.ToArray(), buttonsLines.ToArray(), true, false);
            buttons_doctor = Vk.GenerateKeyboard(buttons_live.ToArray(), commands_doctor.ToArray(), buttons_colors.ToArray(), buttonsLines.ToArray(), true, false);
            buttons_komissar = Vk.GenerateKeyboard(buttons_live.ToArray(), commands_commisar.ToArray(), buttons_colors.ToArray(), buttonsLines.ToArray(), true, false);
            return status_nicks;
        }

        public async Task<List<long>> MafiaGetNotDeadPlayersList(Dictionary<long, Dictionary<string, string>> targetUsers)
        {

            List<long> result = new List<long>();
            
            foreach (KeyValuePair<long, Dictionary<string, string>> item in targetUsers)
            {
                if (item.Value["role"] != "dead")
                {
                    result.Add(item.Key);
                }
            }

            return result;
        }

        public async Task<string> MafiaGetDeadPlayers(Dictionary<long, Dictionary<string, string>> targetUsers)
        {

            long[] nicks_get = new long[targetUsers.Count];
            long i = 0;
            foreach (KeyValuePair<long, Dictionary<string, string>> item in targetUsers)
            {
                nicks_get[i] = item.Key;
                i++;
            }

            var nicks = await Vk.UsersGetVkInfo(nicks_get);

            string status_nicks = "";
            foreach (KeyValuePair<long, Dictionary<string, string>> item in targetUsers)
            {
                if (nicks.ContainsKey("id" + item.Key))
                {
                    if (item.Value["role"] == "dead")
                    {
                        status_nicks = status_nicks + "— " + nicks["id" + item.Key.ToString()].first_name + " " +
                            nicks["id" + item.Key.ToString()].last_name + "<br>";
                    }
                }
                else
                {
                    if (item.Value["role"] == "dead")
                    {
                        status_nicks = status_nicks + $"— [id{item.Key}|пользователь]<br>";
                    }
                }
            }

            return status_nicks;
        }

        public static void DeleteMafia(Cache Cache, long peer_id, Dictionary<long, Dictionary<string, string>> targetUsers)
        {
            try
            {
                if (targetUsers.Count >= 1)
                {
                    foreach (var item in targetUsers)
                    {
                        Cache.Delete("mafiauser_" + item.Key.ToString());
                    }
                }
                Cache.Delete("mafiaplayers_" + peer_id);
                Cache.Delete("mafia_" + peer_id);
                ClearSelectedMafia(Cache, peer_id);
                Cache.Delete("skipped_hods_komissar_" + peer_id);
                Cache.Delete("skipped_hods_done_" + peer_id);
            }
            catch
            {

            }
            
        }

        public static void ClearSelectedMafia(Cache Cache, long peer_id)
        {
            try
            {
                Cache.Delete("mafia_don_selected_" + peer_id);
                Cache.Delete("komissar_maf_selected_" + peer_id);
                Cache.Delete("doctor_don_selected_" + peer_id);
                Cache.Delete("peoples_mafia_selected_" + peer_id);
                Cache.Delete("komissarCheck_maf_selected_" + peer_id);
            }
            catch
            {

            }
            
        }


        public static void ClearAllMafios(Cache Cache)
        {
            if (vk.mafios.Count >= 1)
            {
                vk Vk = new(Cache);
                foreach (var item in vk.mafios)
                {
                    long peer_id = long.Parse(item.Key);
                    var targetUsers = Cache.Get<Dictionary<long, Dictionary<string, string>>>("mafiaplayers_" + peer_id);
                    if (targetUsers != null)
                    {
                        DeleteMafia(Cache, peer_id, targetUsers);
                    }
                    else
                    {
                        ClearSelectedMafia(Cache, peer_id);
                    }

                    
                    Vk.MessagesSend("К сожалению, произошло случайное событие и Мафия была остановлена. На этот раз: сервера VK API упали)", 0, peer_id);

                    vk.mafios.Remove(item.Key, out _);
                    
                }
            }
        }
        public async Task<bool> MafiaGetWinners(Dictionary<long, Dictionary<string, string>> targetUsers, long peer_id, KeyValuePair<string, Dictionary<string, string>>entry)
        {
            
            string text = "";

            var countLives = await MafiaGetNotDeadPlayersList(targetUsers);
            bool done_live = false;
            bool komissar_live = false;
            bool mafia_live = false;
            foreach (var item in countLives)
            {
                if (targetUsers[item]["role"] == "done")
                {
                    done_live = true;
                    continue;
                }
                if (targetUsers[item]["role"] == "komissar")
                {
                    komissar_live = true;
                    continue;
                }
                if (targetUsers[item]["role"] == "mafia")
                {
                    mafia_live = true;
                    continue;
                }
            }

            Games.ClearSelectedMafia(cache, peer_id);


            if (countLives.Count <= 2 || !komissar_live || !done_live)
            {
                string winners = "peoples";
                

                if (done_live || (mafia_live && !komissar_live))
                {
                    winners = "mafia";
                }

                string string_win = "[grand_manager|мирные жители]";
                if (winners == "mafia")
                {
                    string_win = "[grand_manager|мафиози]";
                }

                string text_list_winners = "🏆 Победители:<br>";

                var nicks = await Vk.UsersGetVkInfo(countLives.ToArray());

                List<long> winners_list = new();

                foreach (var item in countLives)
                {
                    string target_nicks = $"— [id{item}|пользователь]";
                    if (nicks.ContainsKey("id" + item))
                    {
                        target_nicks = "— " + nicks["id" + item.ToString()].first_name + " " +
                            nicks["id" + item.ToString()].last_name + "";
                    }

                    if (winners == "mafia")
                    {
                        if (targetUsers[item]["role"] == "mafia")
                        {
                            text_list_winners = text_list_winners + target_nicks + " (мафиози)<br>";
                            winners_list.Add(item);
                        }
                        else if (targetUsers[item]["role"] == "done")
                        {
                            text_list_winners = text_list_winners + target_nicks + " (дон мафии)<br>";
                            winners_list.Add(item);
                        }
                    }
                    else
                    {
                        if (targetUsers[item]["role"] == "komissar")
                        {
                            text_list_winners = text_list_winners + target_nicks + " (комиссар)<br>";
                            winners_list.Add(item);
                        }
                        else if (targetUsers[item]["role"] == "people")
                        {
                            text_list_winners = text_list_winners + target_nicks + " (мирный житель)<br>";
                            winners_list.Add(item);
                        }
                        else if (targetUsers[item]["role"] == "doctor")
                        {
                            text_list_winners = text_list_winners + target_nicks + " (доктор)<br>";
                            winners_list.Add(item);
                        }
                    }
                }

                string text_list_loose = "👥 Проигравшие:<br>";

                List<long> looses = new();
                foreach (var item in targetUsers)
                {
                    if (winners_list.Contains(item.Key))
                    {
                        continue;
                    }
                    looses.Add(item.Key);
                }
                nicks = await Vk.UsersGetVkInfo(looses.ToArray());
                foreach (var item in targetUsers)
                {
                    if (winners_list.Contains(item.Key))
                    {
                        continue;
                    }
                    string target_nicks = $"— [id{item.Key}|пользователь]";
                    if (nicks.ContainsKey("id" + item.Key))
                    {
                        target_nicks = "— " + nicks["id" + item.Key.ToString()].first_name + " " +
                            nicks["id" + item.Key.ToString()].last_name + "";
                    }

                    string lastRole = "неизвестно";
                    if (item.Value.ContainsKey("last_role"))
                    {
                        if (item.Value["last_role"] == "people")
                        {
                            lastRole = "мирный житель";
                        }
                        else if (item.Value["last_role"] == "done")
                        {
                            lastRole = "дон мафии";
                        }
                        else if (item.Value["last_role"] == "mafia")
                        {
                            lastRole = "мафиози";
                        }
                        else if (item.Value["last_role"] == "doctor")
                        {
                            lastRole = "доктор";
                        }
                        else if (item.Value["last_role"] == "komissar")
                        {
                            lastRole = "комиссар";
                        }
                        else
                        {
                            lastRole = item.Value["last_role"];
                        }
                    }
                    else if (item.Value["role"] != "dead")
                    {
                        if (item.Value["role"] == "people")
                        {
                            lastRole = "мирный житель";
                        }
                        else if (item.Value["role"] == "done")
                        {
                            lastRole = "дон мафии";
                        }
                        else if (item.Value["role"] == "mafia")
                        {
                            lastRole = "мафиози";
                        }
                        else if (item.Value["role"] == "doctor")
                        {
                            lastRole = "доктор";
                        }
                        else if (item.Value["role"] == "komissar")
                        {
                            lastRole = "комиссар";
                        }
                        else
                        {
                            lastRole = item.Value["role"];
                        }
                    }
                    target_nicks = target_nicks + " (" + lastRole + ")<br>";
                    text_list_loose += target_nicks;
                }

                text = $"🏁 Игра завершена. Победили — {string_win}<br>Они получают по 20 тысяч рублей!<br><br>{text_list_winners}<br><br>{text_list_loose}";
                
                Vk.MessagesSend(text, 0, peer_id);
                Games.DeleteMafia(cache, peer_id, targetUsers);
                vk.mafios.TryRemove(entry);
                foreach (var item in winners_list)
                {
                    var account = dbh.usersGetUser(item);

                    string rub = (getUlongMoney(account["rubs"]) + 20000).ToString();
                    dbh.gameSetUserRub(item, rub);
                }
                return true;
                //return text;
                // mafia_don_selected_peerid
                // komissar_maf_selected_peerid
                // doctor_don_selected_peerid
            }
            else
            {
                return false;
            }
        }

        public System.Numerics.BigInteger getUlongMoney(string money)
        {
            //decimal temp = 0;
            System.Numerics.BigInteger temp = 0;
            try
            {
                temp = System.Numerics.BigInteger.Parse(money);
            }
            catch
            {

            }
            return temp;
        }
    }
}
