-- MySQL dump 10.13  Distrib 8.4.8, for Win64 (x86_64)
--
-- Host: localhost    Database: vk_test_beta
-- ------------------------------------------------------
-- Server version	8.4.8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `userid` bigint NOT NULL DEFAULT '0' COMMENT 'ID',
  `owner_count` int NOT NULL DEFAULT '0' COMMENT 'Кол-во созданных конференций',
  `rubs` varchar(1200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '10000' COMMENT 'Кол-во рублей',
  `dollars` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'Кол-во долларов',
  `euros` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'Кол-во евро',
  `rating` int NOT NULL DEFAULT '0' COMMENT 'Рейтинг',
  `energy` tinyint NOT NULL DEFAULT '10' COMMENT 'Энергия',
  `level` smallint NOT NULL DEFAULT '1' COMMENT 'Уровень',
  `vip_type` smallint NOT NULL DEFAULT '0' COMMENT 'VIP тип',
  `chanse_kazino` tinyint NOT NULL DEFAULT '1' COMMENT 'Шанс выпадения x5 (%)',
  `vip` timestamp NULL DEFAULT NULL COMMENT 'Дата окончания действия VIP',
  `job` int NOT NULL DEFAULT '0' COMMENT 'Работа',
  `country` int NOT NULL DEFAULT '1' COMMENT 'Страна',
  `ban_report` bigint NOT NULL DEFAULT '0' COMMENT 'Блокировка тикетов',
  `accept_ls` tinyint NOT NULL DEFAULT '0' COMMENT 'Разрешение писать в личные сообщения',
  `date_last` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Последняя активность',
  `date_reg` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата регистрации в боте',
  `date_reg_vk` timestamp NULL DEFAULT NULL COMMENT 'Дата регистрации VK',
  `date_bonus_last` timestamp NULL DEFAULT NULL COMMENT 'Дата последнего бонуса',
  `date_job` timestamp NULL DEFAULT NULL COMMENT 'Дата последней зарплаты',
  `access_token` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT 'Токен доступа',
  `8march` int NOT NULL DEFAULT '0',
  `7march` int NOT NULL DEFAULT '0',
  `opros` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`),
  KEY `dollars` (`dollars`),
  KEY `rating` (`rating`),
  KEY `job` (`job`),
  KEY `country` (`country`),
  FULLTEXT KEY `euros` (`euros`),
  FULLTEXT KEY `rubs` (`rubs`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `achievements`
--

DROP TABLE IF EXISTS `achievements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `achievements` (
  `achievement_id` int NOT NULL AUTO_INCREMENT COMMENT 'ID достижения',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'Название достижения',
  `description` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'Описание',
  `members` bigint NOT NULL DEFAULT '0' COMMENT 'Сколько человек имеет',
  PRIMARY KEY (`achievement_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Достижения, названия и ID.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admins` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` bigint NOT NULL DEFAULT '0' COMMENT 'ID VK',
  `expire` datetime DEFAULT NULL COMMENT 'Дата окончания',
  `access_give` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'Доступ к выдаче админок',
  `access_reports` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'Доступ к просмотру тикетов',
  `access_sysinfo` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'Доступ к просмотру полной информации о человеке',
  `access_closed` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'Доступ к закрытым тикетам',
  `access_answer` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'Доступ к ответам на тикеты',
  `access_banreport` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'Доступ к блокировке тикетов',
  `access_unbanreport` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'Доступ к разблокировке тикетов',
  `access_sysban` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'Доступ к блокировке в боте',
  `access_sysunban` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'Доступ к разблокировке в боте',
  `access_sysrole` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'Доступ к выдаче ролей',
  `access_givevip` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'Доступ к выдаче VIP',
  `access_getbotstats` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'Доступ к статистике бота',
  `access_spam` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'Доступ к рассылке',
  `access_givemoney` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'Доступ к выдаче денег',
  `access_getquest` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'Доступ к просмотру неактивных бесед',
  `access_fakecmd` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'Доступ к фейковым кмд',
  `admin` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'ID выдавшего админку',
  `answers` int NOT NULL DEFAULT '0' COMMENT 'Тикетов рассмотрено',
  `marks` int unsigned NOT NULL DEFAULT '0' COMMENT 'Общий рейтинг',
  `date_reg` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'NULL',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `token` (`token`)
) ENGINE=InnoDB AUTO_INCREMENT=395 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `banreports`
--

DROP TABLE IF EXISTS `banreports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `banreports` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL COMMENT 'ID пользователя',
  `active` tinyint NOT NULL DEFAULT '1' COMMENT 'Активна ли блокировка',
  `admin_id` bigint NOT NULL COMMENT 'ID администратора',
  `reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'не указана' COMMENT 'Причина',
  `date_unban` datetime NOT NULL COMMENT 'Дата разблокировки',
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=771 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bans`
--

DROP TABLE IF EXISTS `bans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bans` (
  `peer_id` bigint DEFAULT NULL COMMENT 'ID беседы',
  `group_id` bigint NOT NULL DEFAULT '188905432',
  `user_id` bigint DEFAULT NULL COMMENT 'ID пользователя',
  `admin_id` bigint DEFAULT NULL COMMENT 'ID заблокировавшего',
  `reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'Причина',
  `date_ban` timestamp NULL DEFAULT NULL COMMENT 'Дата выдачи блокировки',
  `date_unban` timestamp NULL DEFAULT NULL COMMENT 'Дата снятия блокировки',
  UNIQUE KEY `peer_id_user_id` (`peer_id`,`user_id`,`group_id`) USING BTREE,
  KEY `peer_id` (`peer_id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `admin_id` (`admin_id`) USING BTREE,
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `blacklist_words`
--

DROP TABLE IF EXISTS `blacklist_words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blacklist_words` (
  `group_id` bigint NOT NULL DEFAULT '188905432',
  `peer_id` bigint NOT NULL COMMENT 'ID беседы',
  `word` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'Слово',
  `admin_id` bigint NOT NULL DEFAULT '0' COMMENT 'ID создателя',
  `type` tinyint NOT NULL DEFAULT '0' COMMENT 'Тип (1 - удалять, 2 - кикать, 3 - предупреждать, 4 - банить)',
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата создания',
  PRIMARY KEY (`peer_id`,`word`,`group_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `botbans`
--

DROP TABLE IF EXISTS `botbans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `botbans` (
  `user_id` bigint NOT NULL DEFAULT '0' COMMENT 'ID',
  `type_ban` int NOT NULL DEFAULT '1' COMMENT '1 — исключать из КФ без возможности разблокировки\r\n2 — исключать из КФ с возможностью блокировки\r\n3 — не исключать из КФ, предупреждать\r\n4 — не исключать из КФ, игнорировать команды',
  `banned_by` bigint NOT NULL DEFAULT '0' COMMENT 'Кем заблокирован',
  `reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'Причина блокировки',
  `comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'Комментарий блокировки пользователю',
  `mention` int NOT NULL DEFAULT '0' COMMENT 'Уведомлен',
  `date_unban` timestamp NULL DEFAULT NULL COMMENT 'Время разблокировки',
  `date_ban` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Время блокировки',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `botflooders`
--

DROP TABLE IF EXISTS `botflooders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `botflooders` (
  `id` int NOT NULL COMMENT 'ID пользователя',
  `priority` int NOT NULL COMMENT 'Приоритет системы',
  `date_last` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Последнее обновление',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `closepeer_attachments`
--

DROP TABLE IF EXISTS `closepeer_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `closepeer_attachments` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID вложения',
  `group_id` bigint NOT NULL DEFAULT '188905432',
  `peer_id` bigint NOT NULL DEFAULT '0' COMMENT 'ID беседы',
  `from_id` bigint NOT NULL DEFAULT '0' COMMENT 'ID отправителя',
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'photo' COMMENT 'Тип',
  `access_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'Ключ доступа',
  `photo_id` int NOT NULL DEFAULT '0' COMMENT 'ID photo',
  `photo_album_id` int NOT NULL DEFAULT '0' COMMENT 'ID альбома',
  `photo_owner_id` int NOT NULL DEFAULT '0' COMMENT 'ID владельца',
  `photo_user_id` int NOT NULL DEFAULT '0' COMMENT 'ID пользователя',
  `photo_text` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'Текст фотографии',
  `text` varchar(3000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `peer_id` (`peer_id`) USING BTREE,
  KEY `from_id` (`from_id`) USING BTREE,
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28563 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `countries` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID страны',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'Название',
  `short_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'Короткое название',
  `owner` bigint DEFAULT NULL COMMENT 'Глава государства',
  `rubles` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'Рублей в казне',
  `dollars` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'Долларов в казне',
  `euros` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'Евро в казне',
  `members` bigint DEFAULT NULL COMMENT 'Граждан',
  `soc_rating` bigint DEFAULT '1' COMMENT 'Социальный рейтинг',
  `transport_minibuses` int DEFAULT '1' COMMENT 'ТР | Маршрутки',
  `transport_buses` int DEFAULT '0' COMMENT 'ТР | Автобусы',
  `transport_trolleybuses` int DEFAULT '0' COMMENT 'ТР | Троллейбусы',
  `transport_trans` int DEFAULT '0' COMMENT 'ТР | Трамваи',
  `transport_metro` int DEFAULT '0' COMMENT 'ТР | Метро',
  `tax_income` tinyint DEFAULT '15' COMMENT 'Налог на доход',
  `tax_vat` tinyint DEFAULT '20' COMMENT 'Налог НДС',
  `tax_services` tinyint DEFAULT '21' COMMENT 'Налог ЖКХ',
  `tax_kazino` tinyint DEFAULT '30' COMMENT 'Налог на казино',
  `average_zp` int DEFAULT '15000' COMMENT 'Средняя зп',
  `area` int DEFAULT '1' COMMENT 'Территория, кв км',
  `date_create` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата создания',
  `date_tax` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата собрания налогов',
  PRIMARY KEY (`id`),
  KEY `rubles` (`rubles`),
  KEY `dollars` (`dollars`),
  KEY `euros` (`euros`),
  KEY `owner` (`owner`),
  KEY `members` (`members`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_cmds`
--

DROP TABLE IF EXISTS `custom_cmds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_cmds` (
  `group_id` bigint NOT NULL DEFAULT '188905432',
  `peer_id` bigint NOT NULL,
  `command` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `target_cmd` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `type_cmd` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `owner` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`peer_id`,`command`,`group_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deletedfilter`
--

DROP TABLE IF EXISTS `deletedfilter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deletedfilter` (
  `group_id` bigint NOT NULL DEFAULT '188905432',
  `peer_id` bigint NOT NULL,
  `message_id` bigint NOT NULL,
  `text` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `from_id` bigint NOT NULL DEFAULT '0',
  `attachments` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `date_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `peer_id` (`peer_id`) USING BTREE,
  KEY `message_id` (`message_id`) USING BTREE,
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `country` int NOT NULL DEFAULT '0' COMMENT 'Страна (0 - для всех)',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'Название',
  `pay` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '5000' COMMENT 'Зарплата (в час)',
  `level` int NOT NULL DEFAULT '1' COMMENT 'Требуемый уровень',
  `created_by` int NOT NULL DEFAULT '0' COMMENT 'Кем создана',
  PRIMARY KEY (`id`),
  KEY `country` (`country`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'Порядковый ID',
  `group_id` bigint NOT NULL DEFAULT '188905432',
  `peer_id` bigint NOT NULL DEFAULT '0' COMMENT 'ID конференции',
  `user_id` bigint NOT NULL DEFAULT '0' COMMENT 'ID пользователя',
  `target_id` bigint NOT NULL DEFAULT '0' COMMENT 'ID пользователя',
  `type` int NOT NULL DEFAULT '0' COMMENT 'Тип события',
  `text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'Текст события',
  `data1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'Аргумент события',
  `data2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'Аргумент события',
  `date_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `peer_id` (`peer_id`),
  KEY `user_id` (`user_id`),
  KEY `target_id` (`target_id`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=391742 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marriages`
--

DROP TABLE IF EXISTS `marriages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marriages` (
  `group_id` bigint NOT NULL DEFAULT '188905432',
  `peer_id` bigint DEFAULT NULL COMMENT 'ID беседы',
  `husband` bigint DEFAULT NULL COMMENT 'Муж',
  `wife` bigint DEFAULT NULL COMMENT 'Жена',
  `date_create` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата свадьбы',
  UNIQUE KEY `peer_id_husband_wife` (`peer_id`,`husband`,`wife`,`group_id`) USING BTREE,
  KEY `peer_id` (`peer_id`) USING BTREE,
  KEY `husband` (`husband`) USING BTREE,
  KEY `wife` (`wife`) USING BTREE,
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID в базе',
  `group_id` bigint NOT NULL DEFAULT '188905432',
  `peer_id` bigint NOT NULL DEFAULT '0' COMMENT 'ID беседы',
  `from_id` bigint NOT NULL DEFAULT '0' COMMENT 'От кого',
  `text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'Текст',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата отправки',
  PRIMARY KEY (`id`),
  KEY `peer_id` (`peer_id`),
  KEY `group_id` (`group_id`),
  FULLTEXT KEY `text` (`text`)
) ENGINE=MyISAM AUTO_INCREMENT=123625 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `names_roles`
--

DROP TABLE IF EXISTS `names_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `names_roles` (
  `peer_id` bigint DEFAULT NULL COMMENT 'ID беседы',
  `priority` int DEFAULT NULL COMMENT 'Приоритет',
  `name` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'Название роли',
  `date_create` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата создания',
  `admin` bigint DEFAULT NULL COMMENT 'Кто создал',
  UNIQUE KEY `peer_id_priority` (`peer_id`,`priority`),
  KEY `peer_id` (`peer_id`) USING BTREE,
  KEY `priority` (`priority`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nsfw`
--

DROP TABLE IF EXISTS `nsfw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nsfw` (
  `id` int NOT NULL,
  `peer_id` bigint DEFAULT NULL,
  `from_id` bigint DEFAULT NULL,
  `link` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `peer_id` (`peer_id`) USING BTREE,
  KEY `from_id` (`from_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` int NOT NULL COMMENT 'ID заказа',
  `from_id` int NOT NULL DEFAULT '0' COMMENT 'ID пользователя',
  `payed` int NOT NULL DEFAULT '0' COMMENT 'Оплачен?',
  `amount` int NOT NULL DEFAULT '0' COMMENT 'Сумма',
  `intid` int NOT NULL DEFAULT '0' COMMENT 'Номер операции Free-Kassa',
  `p_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'Email плательщика',
  `p_phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'Телефон плательщика',
  `cur_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'ID валюты',
  `sign` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'Подпись запроса',
  `payer_account` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'Номер счета',
  `commission` int NOT NULL DEFAULT '0' COMMENT 'Комиссия',
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `peer_members`
--

DROP TABLE IF EXISTS `peer_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `peer_members` (
  `peer_id` bigint NOT NULL DEFAULT '0' COMMENT 'ID беседы',
  `user_id` bigint NOT NULL DEFAULT '0' COMMENT 'ID пользователя',
  `invited_by` bigint NOT NULL DEFAULT '0',
  `nick` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'Ник пользователя',
  `priority` int DEFAULT '0' COMMENT 'Роль',
  `mute` timestamp NULL DEFAULT NULL COMMENT 'Блокировка чата',
  `mute_by` int DEFAULT NULL COMMENT 'Кто выдал блокировку чата',
  `warns` int DEFAULT '0' COMMENT 'Предупреждений',
  `warn_history` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'История предупреждений',
  `no_mention` tinyint DEFAULT '0' COMMENT 'Не упоминать',
  `date_reg` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата регистрации',
  `leave_peer` int DEFAULT '0' COMMENT 'Состоит ли в беседе',
  `gamemode` int DEFAULT '0' COMMENT 'Иммунитет',
  `gamemode_by` bigint DEFAULT NULL COMMENT 'Иммунитет выдан',
  `last_messages` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  UNIQUE KEY `peer_id_user_id` (`peer_id`,`user_id`),
  KEY `nick` (`nick`) USING BTREE,
  KEY `peer_id` (`peer_id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `priority` (`priority`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `peers`
--

DROP TABLE IF EXISTS `peers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `peers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `peer_id` bigint DEFAULT '0',
  `active` int DEFAULT '0',
  `date_reg` varchar(50) DEFAULT '',
  `owner` bigint DEFAULT '0',
  `inviter` bigint DEFAULT '0',
  `silence` int DEFAULT '0',
  `set_kickphotos` int DEFAULT '0',
  `set_kickposts` int DEFAULT '0',
  `set_kicknsfw` int DEFAULT '0',
  `set_kicklinks` int DEFAULT '0',
  `set_kickobscen` int DEFAULT '0',
  `set_action_activity` int DEFAULT '0',
  `set_kickexit` int DEFAULT '0',
  `set_kickinviter` int DEFAULT '0',
  `set_mentions` int DEFAULT '0',
  `set_games` int DEFAULT '0',
  `set_systemhelp` int DEFAULT '0',
  `protect` int DEFAULT '0',
  `antiflood` int DEFAULT '0',
  `vip` varchar(50) DEFAULT '',
  `title` varchar(255) DEFAULT '',
  `welcome_text` text,
  `current_members` bigint DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pools`
--

DROP TABLE IF EXISTS `pools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pools` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `owner_id` bigint DEFAULT '0',
  `in_pool` bigint DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `questions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT '0',
  `from_id` bigint DEFAULT '0',
  `text` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `from_id` bigint DEFAULT '0',
  `closed` int DEFAULT '0',
  `last_activity` varchar(50) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reports_messages`
--

DROP TABLE IF EXISTS `reports_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports_messages` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `report_id` bigint DEFAULT '0',
  `date_created` varchar(50) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `rules_cmds`
--

DROP TABLE IF EXISTS `rules_cmds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rules_cmds` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `peer_id` bigint DEFAULT '0',
  `command` varchar(255) DEFAULT '',
  `priority` int DEFAULT '0',
  `admin` bigint DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `settings_airplanes`
--

DROP TABLE IF EXISTS `settings_airplanes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings_airplanes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT '',
  `price` bigint DEFAULT '0',
  `income` bigint DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `settings_boats`
--

DROP TABLE IF EXISTS `settings_boats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings_boats` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT '',
  `price` bigint DEFAULT '0',
  `income` bigint DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `settings_cars`
--

DROP TABLE IF EXISTS `settings_cars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings_cars` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT '',
  `price` bigint DEFAULT '0',
  `income` bigint DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `settings_computers`
--

DROP TABLE IF EXISTS `settings_computers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings_computers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT '',
  `price` bigint DEFAULT '0',
  `income` bigint DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `settings_helicopters`
--

DROP TABLE IF EXISTS `settings_helicopters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings_helicopters` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT '',
  `price` bigint DEFAULT '0',
  `income` bigint DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `settings_houses`
--

DROP TABLE IF EXISTS `settings_houses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings_houses` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT '',
  `price` bigint DEFAULT '0',
  `income` bigint DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `settings_smartphones`
--

DROP TABLE IF EXISTS `settings_smartphones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings_smartphones` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT '',
  `price` bigint DEFAULT '0',
  `income` bigint DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `slaves`
--

DROP TABLE IF EXISTS `slaves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `slaves` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `owner` bigint DEFAULT '0',
  `slave_id` bigint DEFAULT '0',
  `job_pay` bigint DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `token` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warns_list`
--

DROP TABLE IF EXISTS `warns_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `warns_list` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `peer_id` bigint DEFAULT '0',
  `user_id` bigint DEFAULT '0',
  `admin_id` bigint DEFAULT '0',
  `reason` text,
  `deleted` int DEFAULT '0',
  `date_created` varchar(50) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `whitelist_links`
--

DROP TABLE IF EXISTS `whitelist_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `whitelist_links` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `peer_id` bigint DEFAULT '0',
  `domain` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-23 10:11:50
