CREATE TABLE IF NOT EXISTS `external_db_connections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `peer_id` bigint NOT NULL,
  `db_type` varchar(20) NOT NULL DEFAULT 'mysql',
  `host` varchar(255) NOT NULL DEFAULT '',
  `port` int NOT NULL DEFAULT 3306,
  `database_name` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password_enc` text NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `peer_id` (`peer_id`),
  KEY `db_type` (`db_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `table_mappings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `peer_id` bigint NOT NULL,
  `alias` varchar(50) NOT NULL,
  `table_name` varchar(255) NOT NULL,
  `search_column` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `peer_id_alias` (`peer_id`, `alias`),
  KEY `peer_id` (`peer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `custom_commands` (
  `id` int NOT NULL AUTO_INCREMENT,
  `peer_id` bigint NOT NULL,
  `command_name` varchar(50) NOT NULL,
  `mapping_id` int NOT NULL,
  `target_column` varchar(255) NOT NULL,
  `description` varchar(500) NOT NULL DEFAULT '',
  `requires_value` tinyint NOT NULL DEFAULT 1,
  `created_by` bigint NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `peer_id_command` (`peer_id`, `command_name`),
  KEY `peer_id` (`peer_id`),
  KEY `mapping_id` (`mapping_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `command_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `peer_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `command_name` varchar(50) NOT NULL,
  `search_value` varchar(255) NOT NULL DEFAULT '',
  `target_value` varchar(255) NOT NULL DEFAULT '',
  `affected_rows` int NOT NULL DEFAULT 0,
  `source` varchar(20) NOT NULL DEFAULT 'vk',
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `peer_id` (`peer_id`),
  KEY `user_id` (`user_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
